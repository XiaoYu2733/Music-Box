-------------------------------------------------------------------------------
-- Notes:  Lists all the resources that are loaded at program startup and
--         remain loaded until program termination.
--
-- Author: John Edwards
-- Date C: 5-25-2012
-------------------------------------------------------------------------------

if _G["SKY_ENABLE_RETAIL_DEMO"] == nil then
	SKY_ENABLE_RETAIL_DEMO = os.getenv("SKY_ENABLE_RETAIL_DEMO")
end

-------------------------------------------------------------------------------
-- SCRIPTS
-------------------------------------------------------------------------------

resource "Script" "Account"			{ source = "Scripts/Account.lua", stripDebug = false }

-------------------------------------------------------------------------------
-- FILES
-------------------------------------------------------------------------------
resource "AllLevelList" "AllLevels" {}

-- @HACK: For FluffyClouds
file "Data/Tex3D/CloudNoise.vol"
file "Data/Tex3D/CloudFluffy.vol"
file "Data/Tex3D/PerlinNoise.vol"

if _G["CONFIG"] ~= "Gold" then
file "Data/Vars/Vars.lua"
file "Data/Vars/Vars_Live.lua"
file "Data/Vars/Vars_Stabilization.lua"
file "Data/Vars/Vars_Test.lua"
file "Data/Vars/Vars_AppleRetailDemo.lua"
file "Data/Vars/Vars_SwitchRC2.lua"
end

-- @HACK: These are only here because precompiled lua doesn't work for 64-bit platforms
--        (which is all of our platforms). Once we fix the compile pipeline these should be removed
file "Data/Scripts/LoadLevel.lua"
file "Data/Scripts/DebugFunctions.lua"
file "Data/Scripts/Account.lua"
--file "Data/Scripts/AllocatorTest.lua"

file "Data/Resources/AudienceEventDefs.json"
file "Data/Resources/CameraQuestDefs.json"
file "Data/Resources/CollectibleDefs.json"
file "Data/Resources/Constellations.json"
file "Data/Resources/DailyQuestDefs.json"
file "Data/Resources/NpcDefs.json"
file "Data/Resources/OutfitDefs.json"
file "Data/Resources/PlaceableDefs.json"
file "Data/Resources/MapDefs.json"
file "Data/Resources/QuestDefs.json"
file "Data/Resources/MessageTypes.json"
file "Data/Resources/SeasonTemplate.json"
file "Data/Resources/WorldQuestDefs.json"
file "Data/Resources/CreatureQuestDefs.json"
file "Data/Resources/CreatureQuestWaveDefs.json"
file "Data/Resources/RadianceSpawnDefs.json"
file "Data/Resources/StormSpawnerDefs.json"
file "Data/Resources/DarknessSpawnWaveDefs.json"
file "Data/Resources/DyeColorDefs.json"
file "Data/Resources/DynamicMenuGroupDefs.json"
file "Data/Resources/DynamicMenuIODefs.json"
file "Data/Resources/SocialFeedPrompts.json"
file "Data/Resources/TrustActivities.json"
file "Data/Resources/TrustGroups.json"
file "Data/Resources/TrustTiers.json"
file "Data/Resources/BehaviorTrees/NPC_TeaOwnerTimeline.json"


if _G["CONFIG"] ~= "Gold" then
file "Data/Debug/sample_video_defs.json"
file "Data/Debug/sample_video_schedule.json"

-- For testing resource sync
file "Data/Debug/resource_sync_automated_test_file.dat"
end

remote_file "Data/Debug/build_number.txt"

-- Replays
-- file "Data/Replays/DayHub2Stitched.v2.replay"
if SKY_ENABLE_RETAIL_DEMO then
	file "Data/Replays/RetailDemoDawn.v2.replay"
	file "Data/Replays/RetailDemoSunset.v2.replay"
	file "Data/Replays/RetailDemoSunsetDownhill.v2.replay"
end

-- Machine Learning file, currently in use with ggml on Windows for Whisper speech recognition
if PLATFORM == "win" then
	file "Data/ML/ggml-base.bin"
end

-------------------------------------------------------------------------------
-- FONTS
-------------------------------------------------------------------------------

-- We are now using Slug to render all localized strings for these supported languages on all platforms
resource "SlugFont" "Latin"							{ source = "Lato/Lato-Light.ttf"  , type = "regular", outline = 0.1, inlineImages = true }
resource "SlugFont" "Latin-Bold"					{ source = "Lato/Lato-Regular.ttf", type = "bold"   , outline = 0.1, inlineImages = true }
resource "SlugFont" "Thai"							{ source = "NotoSans/NotoSansThai-Regular.ttf", type = "regular" }
resource "SlugFont" "Thai-Bold"						{ source = "NotoSans/NotoSansThai-Bold.ttf"   , type = "bold"    }
-- Earlier fonts take precedence over later fonts when rendering
-- Here we're using 'MarugameHonmaruGothic-R' for Japanese as a stylistic choice
resource "SlugFont" "Japanese-Common"				{ source = "Marugame/MarugameHonmaruGothic-R.otf", include = { "0x3000,0x337F", "0xFF01,0xFF9F" } }
-- Chinese and Korean, as well as any missing Japanese glyphs, will be rendered as 'NotoSansCJKjp-Regular'
-- This font is 87mb of uncompressed textures stored in a 47mb file.  Largest resource is 6mb for comparison.
-- see if this can be split, since we currently need 47 + 87x2 = 221 memory to load this.
-- CJK Unified Ideograph ranges referenced from https://en.wikipedia.org/wiki/CJK_Unified_Ideographs
resource "SlugFont" "CJK-Uni-1"						{ source = "NotoSans/NotoSansCJKjp-Regular.otf", include = { "0x4E00,0x62FF" } }
resource "SlugFont" "CJK-Uni-2"						{ source = "NotoSans/NotoSansCJKjp-Regular.otf", include = { "0x6300,0x77FF" } }
resource "SlugFont" "CJK-Uni-3"						{ source = "NotoSans/NotoSansCJKjp-Regular.otf", include = { "0x7800,0x8CFF" } }
resource "SlugFont" "CJK-Uni-4"						{ source = "NotoSans/NotoSansCJKjp-Regular.otf", include = { "0x8D00,0x9FFF" } }
resource "SlugFont" "CJK-Ext-A"						{ source = "NotoSans/NotoSansCJKjp-Regular.otf", include = { "0x3400,0x4DBF" } }
resource "SlugFont" "CJK-Ext-B-I"					{ source = "NotoSans/NotoSansCJKjp-Regular.otf", include = { "0x20000,0x2EE5F", "0x30000,0x323AF" } }
-- This is just whatever was not included above for coverage
resource "SlugFont" "CJK-Remaining"					{ source = "NotoSans/NotoSansCJKjp-Regular.otf", exclude = { "0x4E00,0x9FFF", "0x3400,0x4DBF", "0x20000,0x2EE5F", "0x30000,0x323AF" } }

resource "SlugFont" "Special"						{ source = "Thatgamefont/thatgamefont.ttf", include = { "0x2726,0x2726" } }
resource "SlugFont" "Emoji"							{ source = "Twemoji/TwemojiMozilla.ttf", color = true }

-- Certain languages on non-mobile platforms are only used for user input, so we include them here
if PLATFORM ~= "iphoneos" and PLATFORM ~= "android" then
	resource "SlugFont" "Arabic"					{ source = "NotoSans/NotoSansArabic-Regular.ttf", type = "regular" }
	resource "SlugFont" "Arabic-Bold"				{ source = "NotoSans/NotoSansArabic-Bold.ttf"   , type = "bold"    }
end

-------------------------------------------------------------------------------
-- SHADERS
-------------------------------------------------------------------------------

resource "Shader" "SkyboxCloud"						{ group = "Skybox", vs = "Skybox.vert", fs = "Skybox.frag", toolExport = true, neverCastShadows = true, defines="CLOUD" }

-- Avatar.frag (and a Ref variant if reflected in the final scene)
resource "Shader" "Avatar"							{ group = "Opaque", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="" }
resource "Shader" "AvatarTranslucent"				{ group = "Opaque", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="TRANSLUCENT" }
resource "Shader" "AvatarGem"						{ group = "Opaque", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="GEM TRANSLUCENT" }
resource "Shader" "AvatarAlpha"						{ group = "Blended", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="ALPHA" }
resource "Shader" "AvatarAlphaTest"					{ group = "AlphaTestOpaque", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines=" ALPHA_TEST" }
resource "Shader" "AvatarCham"						{ group = "Opaque", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="CHAM CAPE_INTEGRITY" }
resource "Shader" "AvatarChamGlitter"				{ group = "Opaque", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="CHAM CAPE_INTEGRITY GLITTER_RAMP" }
resource "Shader" "AvatarChamAlpha"					{ group = "Blended", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="CHAM CAPE_INTEGRITY ALPHA" }
resource "Shader" "AvatarChamElderMask"			    { group = "Blended", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="CHAM ELDER_MASK ALPHA" }
resource "Shader" "AvatarChamGlitterAlpha"			{ group = "Blended", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="CHAM CAPE_INTEGRITY ALPHA GLITTER" }
resource "Shader" "AvatarChamButterfly"				{ group = "Blended", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="CHAM CAPE_INTEGRITY ALPHA GLITTER BUTTERFLY" }
resource "Shader" "AvatarChamDyeHotwire"			{ group = "Opaque", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="CHAM CAPE_INTEGRITY DYE_HOTWIRE" }
resource "Shader" "AvatarChamOceanCaustics"			{ group = "BlendedDepth", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="CHAM CAPE_INTEGRITY ALPHA OCEAN_CAUSTICS" }
resource "Shader" "AvatarOceanCaustics"				{ group = "BlendedDepth", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="ALPHA OCEAN_CAUSTICS" }
resource "Shader" "AvatarHair"						{ group = "Opaque", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="HAIR" }
resource "Shader" "SpiritBody"						{ group = "Opaque", vs = "Avatar.vert", fs = "Spirit.frag", toolExport = false, defines="SPIRIT COLOR_UNIFORM" }
resource "Shader" "SpiritBodyAlphaTest"				{ group = "AlphaTestOpaque", vs = "Avatar.vert", fs = "Spirit.frag", toolExport = false, defines="SPIRIT COLOR_UNIFORM ALPHA_TEST" }
resource "Shader" "SpiritBodyAlpha"					{ group = "Blended", vs = "Avatar.vert", fs = "Spirit.frag", toolExport = false, defines="SPIRIT MEMORY_REVEAL ALPHA COLOR_UNIFORM MUSICAL_STARS MUSICAL_INFLATE" }
resource "Shader" "SpiritBodyMemoryOpaque"			{ group = "Opaque", vs = "Avatar.vert", fs = "Spirit.frag", toolExport = false, defines="SPIRIT MEMORY_REVEAL COLOR_UNIFORM MEMORY_OPAQUE" }
resource "Shader" "SpiritFrozen"					{ group = "Opaque", vs = "Avatar.vert", fs = "SpiritFrozen.frag", toolExport = false, defines="SPIRIT FROZEN COLOR_UNIFORM" }
resource "Shader" "SpiritCore"						{ group = "Ghostly", vs = "SpiritCore.vert", fs = "SpiritCore.frag", toolExport = false, defines="" }
resource "Shader" "SpiritParticle"					{ group = "Blended", vs = "SpiritParticle.vert", fs = "SpiritParticle.frag", toolExport = false, defines="" }
resource "Shader" "SpiritBodyDepthPrepass"			{ group = "DepthPrepass", vs = "Avatar.vert", fs = "Black.frag", toolExport = false, defines="SPIRIT MEMORY_REVEAL BLACK" }
resource "Shader" "AvatarDepthPrepass"				{ group = "DepthPrepass", vs = "Avatar.vert", fs = "Black.frag", toolExport = false, defines="BLACK" }
resource "Shader" "AvatarDiamond"					{ group = "Sprites", vs = "AvatarDiamond.vert", fs = "AvatarDiamond.frag", toolExport = false, defines="" }
resource "Shader" "AvatarDiamondReflect"			{ group = "AlphaTestOpaque", vs = "AvatarDiamond.vert", fs = "AvatarDiamond.frag", toolExport = false, defines="REFLECTED" }
resource "Shader" "AvatarFur" 						{ group = "OpaqueTwoFace", vs = "AvatarFur.vert", fs = "Avatar.frag", toolExport = false, defines="CHAM CAPE_INTEGRITY FUR FUR_STRAND" }
resource "Shader" "AvatarFurRaven"					{ group = "OpaqueTwoFace", vs = "AvatarFur.vert", fs = "Avatar.frag", toolExport = false, defines="CHAM CAPE_INTEGRITY FUR FUR_STRAND ALPHA_TEST RAVEN" }
resource "Shader" "AvatarChamFurBase" 				{ group = "Opaque", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="CHAM CAPE_INTEGRITY FUR" }
resource "Shader" "AvatarFurMotion" 				{ group = "MotionTwoFace", vs = "AvatarFur.vert", fs = "MotionGen.frag", toolExport = false, defines="CHAM CAPE_INTEGRITY MOTION_VEC MESH FUR" }

resource "Shader" "VideoTextureArtGallery"	 		{ group = "Blended", vs = "VideoTextureRender.vert", fs = "VideoTextureRender.frag", toolExport = true, defines="VIDEO_BLENDED VIDEO_CHROMA_CUTOUT" }
resource "Shader" "VideoTextureChromaCutout"		{ group = "OpaqueTwoFace", vs = "VideoTextureRender.vert", fs = "VideoTextureRender.frag", toolExport = true, defines="VIDEO_CHROMA_CUTOUT" }
resource "Shader" "VideoTextureRender"				{ group = "OpaqueTwoFace", vs = "VideoTextureRender.vert", fs = "VideoTextureRender.frag", toolExport = true, defines="" }


if PLATFORM == "macosx" or PLATFORM == "win"  then
	resource "Shader" "AvatarWireframe" 				{ group = "Opaque", vs = "AvatarWireframe.vert", fs = "AvatarWireframe.frag", toolExport = false, defines="" }
end

-- Mesh.frag - @NOTE: All meshes in the game currently use the "Mesh" shader when baking, so we need the instance limit to be fairly high
resource "Shader" "MeshAlpha"						{ group = "Decal", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="DECAL" }
resource "Shader" "MeshShAlpha"						{ group = "Decal", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="BAKED DECAL" }
resource "Shader" "MeshShDecal"						{ group = "Decal", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines="BAKED DECAL" }
resource "Shader" "MeshShSl"						{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="BAKED SELF_LIT COLOR_UNIFORM" }
resource "Shader" "MeshGem"             			{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, neverCastShadows = true, defines="COLOR_UNIFORM NO_SHADOWS ETHEREAL GEM" }
resource "Shader" "MeshRainSh"						{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="BAKED RAIN" }
resource "Shader" "MeshRainShAlpha"					{ group = "Decal", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="BAKED RAIN DECAL" }
resource "Shader" "MeshCham"						{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines = "CHAM SELF_LIT COLOR_UNIFORM" }
resource "Shader" "MeshDualCham"					{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines = "CHAM DUAL_CHAM SELF_LIT COLOR_UNIFORM" }
resource "Shader" "MeshHeightChamSh"				{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines = "CHAM HEIGHT_CHAM SELF_LIT COLOR_UNIFORM BAKED" }
resource "Shader" "MeshHeightChamSl"				{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines = "CHAM HEIGHT_CHAM SELF_LIT COLOR_UNIFORM" }
resource "Shader" "CreatureSl"						{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="SH_UNIFORM CREATURE SELF_LIT" }
resource "Shader" "AncestorEngine"					{ group = "Decal", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="BAKED SELF_LIT DECAL COLOR_UNIFORM" }
resource "Shader" "DarkStone"						{ group = "Opaque", vs = "DarkStone.vert", fs = "DarkStone.frag", toolExport = true, neverCastShadows = true, defines="BAKED" }
resource "Shader" "DarkStoneNoBake"					{ group = "Opaque", vs = "DarkStone.vert", fs = "DarkStone.frag", toolExport = true, neverCastShadows = true, defines="" }
resource "Shader" "InstancedDarkStone"				{ group = "Opaque", vs = "DarkStone.vert", fs = "DarkStone.frag", toolExport = true, neverCastShadows = true, defines="INSTANCED" }
resource "Shader" "MeshSlDarkvine"					{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="SELF_LIT COLOR_UNIFORM DARKVINE" }
resource "Shader" "MeteorDarkStoneNoBake"			{ group = "Opaque", vs = "DarkStone.vert", fs = "DarkStone.frag", toolExport = true, neverCastShadows = true, defines="METEOR" }
resource "Shader" "LightShroom"						{ group = "Opaque", vs = "LightShroom.vert", fs = "LightShroom.frag", toolExport = true, neverCastShadows = true, defines="" }
resource "Shader" "Spirit"							{ group = "Opaque", vs = "Spirit.vert", fs = "Spirit.frag", toolExport = true, neverCastShadows = true, defines="MESH SPIRIT" }
-- This shader is designed for compatibility with older outfit props that are now using the placeable system
resource "Shader" "MeshPlaceableProp"       		{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="SELF_LIT COLOR_UNIFORM PLACEABLE_PROP NO_SHADOWS ETHEREAL" }
resource "Shader" "MeshPlaceablePropAlpha"       	{ group = "Blended", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="SELF_LIT COLOR_UNIFORM PLACEABLE_PROP ALPHA NO_SHADOWS ETHEREAL" }
resource "Shader" "MeshFoliageAlphaTest"       		{ group = "OpaqueTwoFace", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="COLOR_UNIFORM PLACEABLE_PROP ALPHA_TEST FOLIAGE NO_SHADOWS" }
resource "Shader" "MeshFoliageAlphaTestGlow"       	{ group = "OpaqueTwoFace", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="COLOR_UNIFORM PLACEABLE_PROP ALPHA_TEST FOLIAGE NO_SHADOWS LIGHT_NOISE" }
resource "Shader" "MeshWindCloth"					{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="COLOR_UNIFORM WIND_CLOTH" }
resource "Shader" "MeshShSlWindCloth"			    { group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="BAKED SELF_LIT COLOR_UNIFORM WIND_CLOTH" }

-- Shader for MeshFlag
resource "Shader" "MeshFlag"                        { group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="FLAG"}

resource "Shader" "DazzleCham"						{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines = "DAZZLECHAM SELF_LIT" }
resource "Shader" "DazzleChamAlpha"					{ group = "Decal", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines = "DAZZLECHAM DECAL SELF_LIT" }
resource "Shader" "ChamShAlpha"						{ group = "Decal", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines = "DAZZLECHAM SELF_LIT CHAMTIME DECAL BAKED" }
resource "Shader" "ChamAlphaDepth"					{ group = "BlendedWithBackfaces", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines = "DAZZLECHAM SELF_LIT CHAMTIME ALPHA" }
resource "Shader" "ChamAlphaDepthColor"				{ group = "BlendedWithBackfaces", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines = "DAZZLECHAM SELF_LIT CHAMTIME ALPHA COLOR_UNIFORM" }
resource "Shader" "MeshMagicGlow"					{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines="COLOR_UNIFORM MAGIC_GLOW" }
resource "Shader" "Constellation"					{ group = "Decal", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = true, defines = "DAZZLECHAM PULSE CONSTELLATION SELF_LIT CHAMTIME DECAL" }

-- Shader for LevelInstanceModel
resource "Shader" "LevelInstanceModel"				{ group = "Opaque", vs = "LevelInstanceModel.vert", fs = "LevelInstanceModel.frag", toolExport = true, defines="" }
-- Shader for Anni4TGCOffice DanceFloor
resource "Shader" "AnniversaryDanceLamp"			{ group = "Opaque", vs = "AnniversaryDanceLamp.vert", fs = "AnniversaryDanceLamp.frag", toolExport = true, defines="" }
-- Shader for Anni4TGCOffice DanceTriangle
resource "Shader" "AnniversaryTriangle"				{ group = "Opaque", vs = "AnniversaryTriangle.vert", fs = "AnniversaryTriangle.frag", toolExport = true, defines="" }
-- Shader for Anni4 Light
resource "Shader" "Anni4Light"						{ group = "Blended", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, defines="ALPHA SOFT_ALPHA SELF_LIT COLOR_UNIFORM UVSCALE UVSOFT" }

-- Ocean
resource "Shader" "OceanCinema"						{ group = "Ocean", vs = "Ocean.vert", fs = "Ocean.frag", toolExport = true, neverCastShadows = true, defines="CINEMA" }
resource "Shader" "OceanOrbit"						{ group = "Ocean", vs = "Ocean.vert", fs = "Ocean.frag", defines="ORBIT" }
resource "Shader" "OceanDark"						{ group = "Ocean", vs = "Ocean.vert", fs = "Ocean.frag", defines="DARK" }
resource "Shader" "OceanDarkTess"					{ group = "Ocean", vs = "Ocean.vert", fs = "Ocean.frag", tc = "Ocean.tesc", te = "Ocean.tese", toolExport = false, defines="DARK TESSELLATION", neverCastShadows = true }
resource "Shader" "OceanMeshWet"					{ group = "OceanModel", vs = "Ocean.vert", fs = "Ocean.frag", toolExport = true, neverCastShadows = true, defines="MODEL RAIN" }
resource "Shader" "OceanDarkMesh"					{ group = "OceanModel", vs = "Ocean.vert", fs = "Ocean.frag", toolExport = true, neverCastShadows = true, defines="MODEL DARK" }
resource "Shader" "OceanDarkMeshWet"				{ group = "OceanModel", vs = "Ocean.vert", fs = "Ocean.frag", toolExport = true, neverCastShadows = true, defines="MODEL DARK RAIN" }

-- Mote
resource "Shader" "MoteAnim"						{ group = "Opaque", vs = "Mote.vert", fs = "Mote.frag", toolExport = false }
resource "Shader" "MoteMotion"						{ group = "Motion", vs = "Mote.vert", fs = "MotionGen.frag", toolExport = false, defines="MOTION_VEC MESH" }

-- DarkstoneRain
resource "Shader" "DarkstoneRain"					{ group = "Opaque", vs = "DarkstoneRain.vert", fs = "DarkstoneRain.frag", toolExport = false }
resource "Shader" "DarkstoneRainMotion"				{ group = "Motion", vs = "DarkstoneRain.vert", fs = "MotionGen.frag", toolExport = false, defines="MOTION_VEC MESH" }

-- Fish School / Audience
resource "Shader" "InstancedFish"					{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED FISH" }
resource "Shader" "InstancedFishNoShadows"			{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED FISH NO_SHADOWS" }
resource "Shader" "InstancedFishSh"					{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED FISH BAKED" }
resource "Shader" "InstancedFishSl"					{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED FISH SELF_LIT COLOR_UNIFORM" }
resource "Shader" "InstancedBirds"					{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED BIRD" }
resource "Shader" "InstancedBirdsSh"				{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED BIRD BAKED" }
resource "Shader" "InstancedMantas"					{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED MANTA" }
resource "Shader" "InstancedGhostMantas"			{ group = "Blended", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED MANTA ALPHA SELF_LIT" }
resource "Shader" "InstancedButterflies"			{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED BUTTERFLY" }
resource "Shader" "InstancedJellyfish"				{ group = "Blended", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED JELLYFISH ALPHA SELF_LIT" }
resource "Shader" "InstancedSkyKidFlying"			{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED SKY_KID_FLYING" }
resource "Shader" "InstancedSkyKidAbstract"			{ group = "Opaque", vs = "Mesh.vert", fs = "PaperLantern.frag", toolExport = false, defines = "INSTANCED SKY_KID_ABSTRACT" }
resource "Shader" "SnakeGameBody"                   { group = "Opaque", vs = "Mesh.vert", fs = "PaperLantern.frag", toolExport = false, defines = "SNAKE_GAME_BODY" }
resource "Shader" "InstancedSkyKidAP18Masked" 		{ group = "Opaque", vs = "Mesh.vert", fs = "PaperLantern.frag", toolExport = false, defines = "INSTANCED SKY_KID_ABSTRACT AP18_MASKED" }
resource "Shader" "InstancedCrabs" 					{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED CRAB" }
resource "Shader" "InstancedDragonDance" 			{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED DRAGON_DANCE" }
resource "Shader" "InstancedGlowkelp"				{ group = "Blended", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED NO_CAM_SCALE ALPHA SELF_LIT" }
resource "Shader" "InstancedFoliage"				{ group = "OpaqueTwoFace", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED COLOR_UNIFORM PLACEABLE_PROP ALPHA_TEST FOLIAGE NO_CAM_SCALE NO_SHADOWS" }
resource "Shader" "InstancedFoliageGlow"				{ group = "OpaqueTwoFace", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED COLOR_UNIFORM PLACEABLE_PROP ALPHA_TEST FOLIAGE NO_CAM_SCALE NO_SHADOWS LIGHT_NOISE" }
resource "Shader" "InstancedAP24Arms"				{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED NO_CAM_SCALE NO_SHADOWS AP24ARMS SELF_LIT" }
resource "Shader" "InstancedBroomsticks"			{ group = "Opaque", vs = "Mesh.vert", fs = "PaperLantern.frag", toolExport = false, defines = "INSTANCED SKY_KID_ABSTRACT BROOMSTICK" }
resource "Shader" "InstancedBasic"					{ group = "Opaque", vs = "Mesh.vert", fs = "Mesh.frag", toolExport = false, defines = "INSTANCED NO_CAM_SCALE NO_SHADOWS" }

resource "Shader" "InstancedJellyfishMotion"		{ group = "Motion", vs = "Mesh.vert", fs = "MotionGen.frag", toolExport = false, defines = "INSTANCED JELLYFISH MESH MOTION_VEC" }
resource "Shader" "InstancedSkyKidAbstractMotion"	{ group = "Motion", vs = "Mesh.vert", fs = "MotionGen.frag", toolExport = false, defines = "INSTANCED SKY_KID_ABSTRACT MESH MOTION_VEC" }
resource "Shader" "InstancedSkyKidAP18MaskedMotion"	{ group = "Motion", vs = "Mesh.vert", fs = "MotionGen.frag", toolExport = false, defines = "INSTANCED SKY_KID_ABSTRACT AP18_MASKED MESH MOTION_VEC" }
resource "Shader" "InstancedSkyKidFlyingMotion"		{ group = "Motion", vs = "Mesh.vert", fs = "MotionGen.frag", toolExport = false, defines = "INSTANCED SKY_KID_FLYING MESH MOTION_VEC" }
resource "Shader" "InstancedBirdsMotion"			{ group = "Motion", vs = "Mesh.vert", fs = "MotionGen.frag", toolExport = false, defines = "INSTANCED BIRD MESH MOTION_VEC" }
resource "Shader" "InstancedMantasMotion"			{ group = "Motion", vs = "Mesh.vert", fs = "MotionGen.frag", toolExport = false, defines = "INSTANCED MANTA MESH MOTION_VEC" }
resource "Shader" "InstancedButterfliesMotion"		{ group = "Motion", vs = "Mesh.vert", fs = "MotionGen.frag", toolExport = false, defines = "INSTANCED BUTTERFLY MESH MOTION_VEC" }
resource "Shader" "InstancedCrabsMotion"			{ group = "Motion", vs = "Mesh.vert", fs = "MotionGen.frag", toolExport = false, defines = "INSTANCED CRAB MESH MOTION_VEC" }
resource "Shader" "InstancedDragonDanceMotion"		{ group = "Motion", vs = "Mesh.vert", fs = "MotionGen.frag", toolExport = false, defines = "INSTANCED DRAGON_DANCE MESH MOTION_VEC" }

resource "Shader" "InstancedSprites" 				{ group = "Opaque", vs = "InstancedSprites.vert", fs = "InstancedSprites.frag", toolExport = false }
resource "Shader" "InstancedSpritesMotion" 			{ group = "Motion", vs = "InstancedSprites.vert", fs = "InstancedSprites.frag", toolExport = false, defines = "MOTION_VEC" }
resource "Shader" "InstancedSpritesShout" 			{ group = "LensFlare", vs = "InstancedSprites.vert", fs = "InstancedSprites.frag", toolExport = false, defines = "SHOUT" }

resource "Shader" "AuroraEthereal"					{ group = "Blended", vs = "Mesh.vert", fs = "AuroraEthereal.frag", toolExport = true, defines = "AURORA ALPHA" }

resource "Shader" "BirdFlock"						{ group = "OpaqueTwoFace", vs = "Bird.vert", fs = "Bird.frag", toolExport = false }
resource "Shader" "Trail"							{ group = "Trails", vs = "Trail.vert", fs = "Trail.frag" }
resource "Shader" "Bub"								{ group = "Blended", vs = "Bub.vert", fs = "Bub.frag" }
resource "Shader" "Shout"							{ group = "BlendedWithBackfacesForeground", vs = "Shout.vert", fs = "Shout.frag" , toolExport = true }
resource "Shader" "ProjectedCircleZone"				{ group = "BlendedBackfacesNoDepth", vs = "Shout.vert", fs = "ProjectedCircleZone.frag", toolExport = true, defines="PROJECTED" }
resource "Shader" "DiscoLightGround"        		{ group = "BlendedBackfacesNoDepth", vs = "Shout.vert", fs = "DiscoLightGround.frag", defines="PROJECTED" }
resource "Shader" "LensFlareStar"					{ group = "LensFlare", vs = "LensFlare.vert", fs = "LensFlare.frag" }
resource "Shader" "LensFlareSunDog"					{ group = "LensFlare", vs = "LensFlareSunDog.vert", fs = "LensFlareSunDog.frag" }
resource "Shader" "LensFlareDot"					{ group = "LensFlare", vs = "LensFlareDot.vert", fs = "LensFlareDot.frag" }
resource "Shader" "Portal"							{ group = "BlendedWithBackfaces", vs = "Portal.vert", fs = "Portal.frag", toolExport = false, defines="" }
resource "Shader" "PortalGeo"						{ group = "BlendedWithBackfaces", vs = "Portal.vert", fs = "Portal.frag", toolExport = true, neverCastShadows = true, defines="MODEL FROM_PORTAL_INDEX" }
resource "Shader" "RepulsionField"					{ group = "BlendedWithBackfaces", vs = "RepulsionField.vert", fs = "RepulsionField.frag", toolExport = true, neverCastShadows = true, defines="" }
resource "Shader" "RepulsionFieldSphere"			{ group = "BlendedWithBackfaces", vs = "RepulsionField.vert", fs = "RepulsionField.frag", toolExport = true, neverCastShadows = true, defines="SPHERE" }
resource "Shader" "ShrineFence"						{ group = "BlendedWithBackfaces", vs = "ShrineFence.vert", fs = "ShrineFence.frag", toolExport = false }

-- DirectionalLighting.frag
resource "Shader" "LitAlphaFading"					{ group = "Blended", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, neverCastShadows = true, defines="ALPHA SELF_LIT LIT FADING" }
resource "Shader" "LitAlphaDual"					{ group = "Blended", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, neverCastShadows = true, defines="ALPHA SELF_LIT LIT DUAL" }
resource "Shader" "LitAlphaColorSoft"				{ group = "Blended", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, neverCastShadows = true, defines="ALPHA SOFT_ALPHA SELF_LIT LIT COLOR_UNIFORM UVSCALE" }
resource "Shader" "LitAlphaProjected"				{ group = "BlendedBackfacesNoDepth", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, defines="ALPHA SELF_LIT LIT PROJECTED" }

resource "Shader" "UnlitAlphaProjected"				{ group = "BlendedBackfacesNoDepth", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, defines="ALPHA SELF_LIT PROJECTED" }
resource "Shader" "UnlitAlphaProjectedTint"			{ group = "BlendedBackfacesNoDepth", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, defines="ALPHA COLOR_UNIFORM SELF_LIT PROJECTED" }
resource "Shader" "UnlitColor"						{ group = "Opaque", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, defines="COLOR_UNIFORM" }
resource "Shader" "UnlitPoint"						{ group = "Blended", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", defines="POINT" }
resource "Shader" "UnlitCloudPoint"					{ group = "Blended", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", defines="POINT CLOUD_POINT" }
resource "Shader" "UnlitAlphaDual"					{ group = "Blended", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, defines="ALPHA SELF_LIT DUAL" }
resource "Shader" "UnlitAlphaPoint"					{ group = "Blended", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", defines="ALPHA SELF_LIT POINT" }
resource "Shader" "UnlitAlphaSolid"					{ group = "Blended", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", defines="ALPHA SELF_LIT SOLID" }
resource "Shader" "UnlitAlphaColorSoft"				{ group = "Blended", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, defines="ALPHA SOFT_ALPHA SELF_LIT COLOR_UNIFORM UVSCALE" }
resource "Shader" "UnlitAlphaCloudPoint"			{ group = "Blended", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", defines="ALPHA SELF_LIT POINT CLOUD_POINT" }
resource "Shader" "UnlitAlphaTestDual"				{ group = "Opaque", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, defines="SELF_LIT ALPHA_TEST COLOR_UNIFORM DUAL DUAL_ADD" }
resource "Shader" "DirectionalLighting"				{ group = "Opaque", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, defines="COLOR_UNIFORM SELF_LIT LIT" }
resource "Shader" "DirectionalLightingRail"			{ group = "Opaque", vs = "DirectionalLighting.vert", fs = "DirectionalLighting.frag", toolExport = true, defines="LIT RAIL_SKIN" }
resource "Shader" "DepthPrepass"					{ group = "DepthPrepass", vs = "DepthPrepass.vert", fs = "Black.frag", toolExport = true }
resource "Shader" "CloudQuadFast"					{ group = "Blended", vs = "FlatCloud.vert", fs = "FlatCloud.frag" }
resource "Shader" "CloudQuadDiamond"				{ group = "Opaque", vs = "FlatCloud.vert", fs = "FlatCloud.frag", defines="DIAMOND" }
resource "Shader" "CloudQuadDiamondMotion"			{ group = "Motion", vs = "FlatCloud.vert", fs = "MotionGen.frag", defines="DIAMOND MESH MOTION" }
resource "Shader" "CloudQuadSoftFast"				{ group = "Blended", vs = "FlatCloud.vert", fs = "FlatCloud.frag", defines="SOFT_PARTICLES" }
resource "Shader" "CloudQuadFluffy"					{ group = "Blended", vs = "FlatCloud.vert", fs = "FlatCloud.frag", defines="SOFT_PARTICLES FLUFFY MINIMAL" }
resource "Shader" "CloudQuadParticleFluffy"			{ group = "Cloud", vs = "FlatCloud.vert", fs = "FlatCloud.frag", defines="SOFT_PARTICLES FLUFFY" }

resource "Shader" "Tail"							{ group = "BlendedWithBackfaces", vs = "Trail.vert", fs = "Trail.frag", defines="TAIL" }
resource "Shader" "TailMotion"						{ group = "Motion", vs = "Trail.vert", fs = "Trail.frag", defines="TAIL MOTION" }

-------------------------------------------------------------------------------
-- MESHES
-------------------------------------------------------------------------------

-- Notes
-- loadLazy will load into memory when worn
-- stripNormals will remove normals???
-- compueteOcclusions will calculate shadows
-- stripUv13 will remove tgc_uv1 and tgc_uv3

resource "Mesh" "ChestCore"								{ source = "Sphere_01.fbx", stripAnimation = false, computeOcclusions = true, computeEdges = false } -- Heart

-- Wing / Cape Diamonds
resource "Mesh" "AvatarStarDiamondInner"				{ source = "CapeStar.fbx" } -- Cape star (lower level version)
resource "Mesh" "AvatarStarDiamondOuter"				{ source = "CapeStarFrame.fbx" } -- Cape star (higher level outer frame)
resource "Mesh" "AvatarStarDiamondExtra"				{ source = "CapeStarExtra.fbx" } -- Cape star (higher level extra frame)
resource "Mesh" "AvatarBatDiamondInner"					{ source = "CapeBat.fbx" }
resource "Mesh" "AvatarBatDiamondOuter"					{ source = "CapeBatFrame.fbx" }
resource "Mesh" "AvatarBatDiamondExtra"					{ source = "CapeBatExtra.fbx" }
resource "Mesh" "AvatarBloomDiamondInner"				{ source = "CapeBloom.fbx" }
resource "Mesh" "AvatarBloomDiamondOuter"				{ source = "CapeBloomFrame.fbx" }
resource "Mesh" "AvatarBloomDiamondExtra"				{ source = "CapeBloomExtra.fbx" }
resource "Mesh" "AvatarClothDiamondInner"				{ source = "CapeCloth.fbx" }
resource "Mesh" "AvatarClothDiamondOuter"				{ source = "CapeClothFrame.fbx" }
resource "Mesh" "AvatarClothDiamondExtra"				{ source = "CapeClothExtra.fbx" }
resource "Mesh" "AvatarDiamondDiamondInner"				{ source = "CapeDiamond.fbx" }
resource "Mesh" "AvatarDiamondDiamondOuter"				{ source = "CapeDiamondFrame.fbx" }
resource "Mesh" "AvatarDiamondDiamondExtra"				{ source = "CapeDiamondExtra.fbx" }
resource "Mesh" "AvatarDuetDiamondInner"				{ source = "CapeDuet.fbx" }
resource "Mesh" "AvatarDuetDiamondOuter"				{ source = "CapeDuetFrame.fbx" }
resource "Mesh" "AvatarDuetDiamondExtra"				{ source = "CapeDuetExtra.fbx" }
resource "Mesh" "AvatarSproutDiamondInner"				{ source = "CapeSprout.fbx" }
resource "Mesh" "AvatarSproutDiamondOuter"				{ source = "CapeSproutFrame.fbx" }
resource "Mesh" "AvatarSproutDiamondExtra"				{ source = "CapeSproutExtra.fbx" }
resource "Mesh" "AvatarSpiderDiamondInner"				{ source = "CapeSpider.fbx" }
resource "Mesh" "AvatarSpiderDiamondOuter"				{ source = "CapeSpiderFrame.fbx" }
resource "Mesh" "AvatarSpiderDiamondExtra"				{ source = "CapeSpiderExtra.fbx" }
resource "Mesh" "AvatarOceanDiamondInner"				{ source = "CapeOcean.fbx" }
resource "Mesh" "AvatarOceanDiamondOuter"				{ source = "CapeOceanFrame.fbx" }
resource "Mesh" "AvatarOceanDiamondExtra"				{ source = "CapeOceanExtra.fbx" }
resource "Mesh" "AvatarFlowDiamondInner"				{ source = "CapeFlow.fbx" }
resource "Mesh" "AvatarFlowDiamondOuter"				{ source = "CapeFlowFrame.fbx" }
resource "Mesh" "AvatarFlowDiamondExtra"				{ source = "CapeFlowExtra.fbx" }
resource "Mesh" "AvatarWitheredDiamondInner"			{ source = "CapeWithered.fbx" }
resource "Mesh" "AvatarWitheredDiamondOuter"			{ source = "CapeWitheredFrame.fbx" }
resource "Mesh" "AvatarWitheredDiamondExtra"			{ source = "CapeWitheredExtra.fbx" }
resource "Mesh" "AvatarRoseDiamondInner"				{ source = "CapeRose.fbx" }
resource "Mesh" "AvatarRoseDiamondOuter"				{ source = "CapeRoseFrame.fbx" }
resource "Mesh" "AvatarRoseDiamondExtra"				{ source = "CapeRoseExtra.fbx" }
resource "Mesh" "AvatarFiveStarDiamondInner"			{ source = "CapeFiveStar.fbx" }
resource "Mesh" "AvatarFiveStarDiamondOuter"			{ source = "CapeFiveStarFrame.fbx" }
resource "Mesh" "AvatarFiveStarDiamondExtra"			{ source = "CapeFiveStarExtra.fbx" }
resource "Mesh" "AvatarSnowDiamondInner"				{ source = "CapeSnow.fbx" }
resource "Mesh" "AvatarSnowDiamondOuter"				{ source = "CapeSnowFrame.fbx" }
resource "Mesh" "AvatarSnowDiamondExtra"				{ source = "CapeSnowExtra.fbx" }
resource "Mesh" "AvatarHexagonDiamondInner"				{ source = "CapeHexagon.fbx" }
resource "Mesh" "AvatarHexagonDiamondOuter"				{ source = "CapeHexagonFrame.fbx" }
resource "Mesh" "AvatarHexagonDiamondExtra"				{ source = "CapeHexagonExtra.fbx" }
resource "Mesh" "AvatarSphereDiamondInner"				{ source = "CapeSphere.fbx" }
resource "Mesh" "AvatarSphereDiamondOuter"				{ source = "CapeSphereFrame.fbx" }
resource "Mesh" "AvatarSphereDiamondExtra"				{ source = "CapeSphereExtra.fbx" }
resource "Mesh" "AvatarCoinDiamondInner"				{ source = "CapeCoin.fbx" }
resource "Mesh" "AvatarCoinDiamondOuter"				{ source = "CapeCoinFrame.fbx" }
resource "Mesh" "AvatarCoinDiamondExtra"				{ source = "CapeCoinExtra.fbx" }
resource "Mesh" "AvatarPlusDiamondInner"				{ source = "CapePlus.fbx" }
resource "Mesh" "AvatarPlusDiamondOuter"				{ source = "CapePlusFrame.fbx" }
resource "Mesh" "AvatarPlusDiamondExtra"				{ source = "CapePlusExtra.fbx" }
resource "Mesh" "AvatarMinusDiamondInner"				{ source = "CapeMinus.fbx" }
resource "Mesh" "AvatarMinusDiamondOuter"				{ source = "CapeMinusFrame.fbx" }
resource "Mesh" "AvatarMinusDiamondExtra"				{ source = "CapeMinusExtra.fbx" }
resource "Mesh" "AvatarRainbowDiamondInner"				{ source = "CapeRainbow.fbx" }
resource "Mesh" "AvatarRainbowDiamondOuter"				{ source = "CapeRainbowFrame.fbx" }
resource "Mesh" "AvatarRainbowDiamondExtra"				{ source = "CapeRainbowExtra.fbx" }
resource "Mesh" "AvatarTravelerDiamondInner"			{ source = "CapeTraveler.fbx" }
resource "Mesh" "AvatarTravelerDiamondOuter"			{ source = "CapeTravelerFrame.fbx" }
resource "Mesh" "AvatarTravelerDiamondExtra"			{ source = "CapeTravelerExtra.fbx" }
resource "Mesh" "AvatarAbyssDiamondInner"				{ source = "CapeAbyss.fbx" }
resource "Mesh" "AvatarAbyssDiamondOuter"				{ source = "CapeAbyssFrame.fbx" }
resource "Mesh" "AvatarAbyssDiamondExtra"				{ source = "CapeAbyssExtra.fbx" }
resource "Mesh" "AvatarHeartDiamondInner"				{ source = "CapeHeart.fbx" }
resource "Mesh" "AvatarHeartDiamondOuter"				{ source = "CapeHeartFrame.fbx" }
resource "Mesh" "AvatarHeartDiamondExtra"				{ source = "CapeHeartExtra.fbx" }
resource "Mesh" "AvatarCatDiamondInner"					{ source = "CapeCat.fbx" }
resource "Mesh" "AvatarCatDiamondOuter"					{ source = "CapeCatFrame.fbx" }
resource "Mesh" "AvatarCatDiamondExtra"					{ source = "CapeCatExtra.fbx" }
resource "Mesh" "AvatarCrabDiamondInner"				{ source = "CapeCrab.fbx" }
resource "Mesh" "AvatarCrabDiamondOuter"				{ source = "CapeCrabFrame.fbx" }
resource "Mesh" "AvatarCrabDiamondExtra"				{ source = "CapeCrabExtra.fbx" }
resource "Mesh" "AvatarDraculaDiamondInner"				{ source = "CapeDracula.fbx" }
resource "Mesh" "AvatarDraculaDiamondOuter"				{ source = "CapeDraculaFrame.fbx" }
resource "Mesh" "AvatarDraculaDiamondExtra"				{ source = "CapeDraculaExtra.fbx" }
resource "Mesh" "AvatarFireworksDiamondInner"		    { source = "CapeFireworks.fbx" }
resource "Mesh" "AvatarFireworksDiamondOuter"			{ source = "CapeFireworksFrame.fbx" }
resource "Mesh" "AvatarFireworksDiamondExtra"			{ source = "CapeFireworksExtra.fbx" }
resource "Mesh" "AvatarCrescentDiamondInner"            { source = "CapeCrescent.fbx" }
resource "Mesh" "AvatarCrescentDiamondOuter"            { source = "CapeCrescentFrame.fbx" }
resource "Mesh" "AvatarCrescentDiamondExtra"            { source = "CapeCrescentExtra.fbx" }
resource "Mesh" "AvatarFortuneDragonDiamondInner"		{ source = "CapeFortuneDragon.fbx" }
resource "Mesh" "AvatarFortuneDragonDiamondOuter"		{ source = "CapeFortuneDragonFrame.fbx" }
resource "Mesh" "AvatarFortuneDragonDiamondExtra"		{ source = "CapeFortuneDragonExtra.fbx" }
resource "Mesh" "AvatarTGCWireframeDiamondInner"        { source = "CapeStar.fbx" }
resource "Mesh" "AvatarTGCWireframeDiamondOuter"        { source = "CapeStarFrame.fbx" }
resource "Mesh" "AvatarTGCWireframeDiamondExtra"        { source = "CapeStarExtra.fbx" }
resource "Mesh" "AvatarRavenDiamondInner"        		{ source = "CapeRaven.fbx" }
resource "Mesh" "AvatarRavenDiamondOuter"        		{ source = "CapeRavenFrame.fbx" }
resource "Mesh" "AvatarRavenDiamondExtra"        		{ source = "CapeRavenExtra.fbx" }
resource "Mesh" "AvatarBellDiamondInner"        		{ source = "CapeBell.fbx" }
resource "Mesh" "AvatarBellDiamondOuter"        		{ source = "CapeBellFrame.fbx" }
resource "Mesh" "AvatarBellDiamondExtra"        		{ source = "CapeBellExtra.fbx" }
resource "Mesh" "AvatarDetachedDiamondInner"			{ source = "CapeDetached.fbx" }
resource "Mesh" "AvatarDetachedDiamondOuter"			{ source = "CapeDetachedFrame.fbx" }
resource "Mesh" "AvatarDetachedDiamondExtra"			{ source = "CapeDetachedExtra.fbx" }

------------------
--     BODY     --
------------------
resource "Mesh" "Outfit_None"					{ source = "Outfit_None.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Body_Ghost"					{ source = "Body_Ghost.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Body_ClassicPants"				{ source = "Body_ClassicPants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Body_ClassicDress"				{ source = "Body_ClassicDress.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Body_ClassicCivilian"			{ source = "Body_ClassicCivilian.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Body_ShortPants"				{ source = "Body_ShortPants.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Body_LongPants"				{ source = "Body_LongPants.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Body_SkinnyPants"				{ source = "Body_SkinnyPants.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Body_FlarePants"				{ source = "Body_FlarePants.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Body_PuffyShorts"				{ source = "Body_PuffyShorts.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Body_PuffyPants"				{ source = "Body_PuffyPants.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Body_WarriorPants"				{ source = "Body_WarriorPants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Fortune
resource "Mesh" "Body_FortuneMuralist"			{ source = "Body_FortuneMuralist.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_FortuneDragonRobe"		{ source = "Body_FortuneDragonRobe.fbx",	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Bloom
resource "Mesh" "Body_Gardener"					{ source = "Body_Gardener.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Nature
resource "Mesh" "Body_OceanWaves"				{ source = "Body_OceanWaves.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Music
resource "Mesh" "Body_BandUniform"				{ source = "Body_BandUniform.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Color
resource "Mesh" "Body_RainbowLight"				{ source = "Body_RainbowLight.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_RainbowDark"            	{ source = "Body_RainbowDark.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Sky Anniversary
resource "Mesh" "Body_BirthdayShirt_05" 		{ source = "Body_BirthdayShirt_05.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Tournament of Triumph
resource "Mesh" "Body_GreekRobe"        		{ source = "Body_GreekRobe.fbx",     		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Sunlight
resource "Mesh" "Body_SwimTrunks"      	 	 	{ source = "Body_SwimTrunks.fbx",     		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Moonlight
resource "Mesh" "Body_MoonlightDress"        	{ source = "Body_MoonlightDress.fbx",     	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Style
resource "Mesh" "Body_FashionJeans"			    { source = "Body_FashionJeans.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true } --uv1 used for normals
resource "Mesh" "Body_CrystalDress"            	{ source = "Body_CrystalDress.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_CrystalSuit"            	{ source = "Body_CrystalSuit.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Mischief
resource "Mesh" "Body_Witch"					{ source = "Body_Witch.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, }
resource "Mesh" "Body_Goth"					    { source = "Body_Goth.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Feast
resource "Mesh" "Body_Snowman"            		{ source = "Body_Snowman.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Body_YellowPinafore"           { source = "Body_YellowPinafore.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Fortune 2025
resource "Mesh" "SnakeSkeleton2"                { source = "SnakeSkeleton2.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }


-- Days of Treasure
resource "Mesh" "Body_TreasurePants"			{ source = "Body_TreasurePants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv3 = true }



-- Special


------------------
--     FEET     --
------------------
resource "Mesh" "Feet_ClassicSocks"            	{ source = "Feet_ClassicSocks.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Fortune
-- Days of Bloom
-- Days of Nature
resource "Mesh" "Feet_SeaFoam"            	{ source = "Feet_SeaFoam.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv3 = true }
-- Days of Color
resource "Mesh" "Feet_RainbowDarkLoafers"       { source = "Feet_RainbowDarkLoafers.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Sunlight
resource "Mesh" "Feet_SunlightSandals"          { source = "Feet_SunlightSandals.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Moonlight
-- Days of Style
resource "Mesh" "Feet_BalletFlats"              { source = "Feet_BalletFlats.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Feet_BunnySlippers"			{ source = "Feet_BunnySlippers.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Mischief
resource "Mesh" "Feet_Witch"            		{ source = "Feet_Witch.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Feet_GothBoots"            	{ source = "Feet_GothBoots.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Feast
resource "Mesh" "Feet_SnowBoots"            	{ source = "Feet_SnowBoots.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Feet_YetiBoots"            	{ source = "Feet_YetiBoots.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }

-- Days of Treasure
resource "Mesh" "Feet_TreasureBoots"            	{ source = "Feet_TreasureBoots.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv3 = true }

-- Special
resource "Mesh" "Feet_AuroraSneakers"        	{ source = "Feet_AuroraSneakers.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }


------------------
--     WING     --
------------------
resource "Mesh" "Wing_Classic"					{ source = "Wing_Classic.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_ClassicTrim"				{ source = "Wing_ClassicTrim.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_ClassicDiamonds"			{ source = "Wing_ClassicDiamonds.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_ClassicRey"				{ source = "Wing_ClassicRey.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Fortune
resource "Mesh" "Wing_Fortune"					{ source = "Wing_Fortune.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_FortuneFish"				{ source = "Wing_FortuneFish.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_FortuneDragon"            { source = "Wing_FortuneDragon.fbx",        sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Love
resource "Mesh" "Wing_Meteor"            		{ source = "Wing_Meteor.fbx",        		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Bloom
resource "Mesh" "Wing_CherryBlossom"			{ source = "Wing_CherryBlossom.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_Wisteria"					{ source = "Wing_Wisteria.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_Tulip"					{ source = "Wing_Tulip.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_CallaLily"				{ source = "Wing_CallaLily.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_RosePattern"				{ source = "Wing_RosePattern.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Music
resource "Mesh" "Wing_BandJacket"				{ source = "Wing_BandJacket.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Nature
resource "Mesh" "Wing_OceanWaves"				{ source = "Wing_OceanWaves.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_SeaTurtle"				{ source = "Wing_SeaTurtle.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_FishPattern"				{ source = "Wing_FishPattern.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_WaterWave"				{ source = "Wing_WaterWave.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_SeaFoam"					{ source = "Wing_SeaFoam.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Color
resource "Mesh" "Wing_RainbowLight"				{ source = "Wing_RainbowLight.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_RainbowDark"				{ source = "Wing_RainbowDark.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_ColorShawl"				{ source = "Wing_ColorShawl.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Sky Anniversary
resource "Mesh" "Wing_TGCHoodie"         		{ source = "Wing_TGCHoodie.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Tournament of Triumph
resource "Mesh" "Wing_TeamDusk"           		{ source = "Wing_TeamDusk.fbx",         	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_TeamPrairie"            	{ source = "Wing_TeamPrairie.fbx",         	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_TeamRain"            		{ source = "Wing_TeamRain.fbx",         	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_TeamSunset"            	{ source = "Wing_TeamSunset.fbx",        	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Sunlight
resource "Mesh" "Wing_SunlightTowelBlue"		{ source = "Wing_SunlightTowelBlue.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_SunlightTowelYellow"		{ source = "Wing_SunlightTowelYellow.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_SunlightTowelPink"		{ source = "Wing_SunlightTowelPink.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_LinenCover"				{ source = "Wing_LinenCover.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Moonlight
-- Days of Style
-- Days of Mischief
resource "Mesh" "Wing_MischiefBat"				{ source = "Wing_MischiefBat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_SpiderWeb"				{ source = "Wing_SpiderWeb.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_Withered"					{ source = "Wing_Withered.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_MischiefCat"				{ source = "Wing_MischiefCat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_Crabula"				    { source = "Wing_Crabula.fbx", 			    sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_Cobweb"					{ source = "Wing_Cobweb.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Feast
resource "Mesh" "Wing_Santa"					{ source = "Wing_Santa.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_Snowflake"				{ source = "Wing_Snowflake.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_WinterElder"				{ source = "Wing_WinterElder.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_WinterPuffer"				{ source = "Wing_WinterPuffer.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_YetiFur"					{ source = "Wing_YetiFur.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Special
resource "Mesh" "Wing_Switch"					{ source = "Wing_Switch.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_TravelerRed"				{ source = "Wing_TravelerRed.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_TGCWireframe"             { source = "Wing_TGCWireframe.fbx",         sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_TGCWireframeEvergreen"    { source = "Wing_TGCWireframeEvergreen.fbx",         	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_TravelerWhite"			{ source = "Wing_TravelerWhite.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = false, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_Flow"						{ source = "Wing_Flow.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_Moth"			    		{ source = "Wing_Moth.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_Sparrow"			    	{ source = "Wing_Sparrow.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_Raven"			    	{ source = "Wing_Raven.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }


------------------
--     HAIR     --
------------------
resource "Mesh" "Hair_SideBraid"				{ source = "Hair_SideBraid.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Afro"						{ source = "Hair_Afro.fbx",					sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_BackLong"					{ source = "Hair_BackLong.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Beard"					{ source = "Hair_Beard.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Bun"						{ source = "Hair_Bun.fbx", 					sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Buzz"						{ source = "Hair_Buzz.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_CurlyBun"					{ source = "Hair_CurlyBun.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_CurlyBunTwo"				{ source = "Hair_CurlyBunTwo.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_TightCurls"				{ source = "Hair_TightCurls.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Dreads"					{ source = "Hair_Dreads.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ElderDawn"				{ source = "Hair_ElderDawn.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ElderDay"					{ source = "Hair_ElderDay.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ElderRain"				{ source = "Hair_ElderRain.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ElderBro"					{ source = "Hair_ElderBro.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ElderSis"					{ source = "Hair_ElderSis.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ElderDusk"				{ source = "Hair_ElderDusk.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ElderNight"				{ source = "Hair_ElderNight.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Lion"						{ source = "Hair_Lion.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_LongBob"					{ source = "Hair_LongBob.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Mohawk"					{ source = "Hair_Mohawk.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Ponytail"					{ source = "Hair_Ponytail.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_PonytailSide"				{ source = "Hair_PonytailSide.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_PonytailShort"			{ source = "Hair_PonytailShort.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_PonytailShaggy"			{ source = "Hair_PonytailShaggy.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ShaggyShort"				{ source = "Hair_ShaggyShort.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Puff"						{ source = "Hair_Puff.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Punk"						{ source = "Hair_Punk.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_OneSideS"					{ source = "Hair_OneSideS.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_OneSideM"					{ source = "Hair_OneSideM.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_OneSideL"					{ source = "Hair_OneSideL.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ShortBob"					{ source = "Hair_ShortBob.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ShortBobRound"			{ source = "Hair_ShortBobRound.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ShoulderLong"				{ source = "Hair_ShoulderLong.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_SideBraidLong"			{ source = "Hair_SideBraidLong.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_TopSharp"					{ source = "Hair_TopSharp.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Pigtail"					{ source = "Hair_Pigtail.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_BraidedPigtail"			{ source = "Hair_BraidedPigtail.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_PigtailSmall"				{ source = "Hair_PigtailSmall.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_PigtailPuffy"				{ source = "Hair_PigtailPuffy.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_PigtailLow"				{ source = "Hair_PigtailLow.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- Days of Fortune
resource "Mesh" "Hair_DoubleBun"				{ source = "Hair_DoubleBun.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_WoolHat"					{ source = "Hair_WoolHat.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_LionDance"				{ source = "Hair_LionDance.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Fish"						{ source = "Hair_Fish.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Love
resource "Mesh" "Hair_MeteorPigtails"			{ source = "Hair_MeteorPigtails.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_PurpleBraids"			{ source = "Hair_PurpleBraids.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Bloom
resource "Mesh" "Hair_BlossomPigtail"			{ source = "Hair_BlossomPigtail.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_CallaLily"				{ source = "Hair_CallaLily.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_BloomSpiky"				{ source = "Hair_BloomSpiky.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_RoseBraid"				{ source = "Hair_RoseBraid.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Nature
resource "Mesh" "Hair_NatureWater"				{ source = "Hair_NatureWater.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ElderManta"				{ source = "Hair_ElderManta.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Color
resource "Mesh" "Hair_RainbowBeanie"			{ source = "Hair_RainbowBeanie.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_RockStar"					{ source = "Hair_RockStar.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_ColorHeadBand"			{ source = "Hair_ColorHeadband.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Music
resource "Mesh" "Hair_MarchingBand"				{ source = "Hair_MarchingBand.fbx",			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Sky Anniversary
-- Tournament of Triumph
resource "Mesh" "Hair_Greek"                    { source = "Hair_Greek.fbx",             	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Sunlight
-- Days of Moonlight
resource "Mesh" "Hair_MoonlightUpdo"            { source = "Hair_MoonlightUpdo.fbx",        sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Style
-- Days of Mischief
resource "Mesh" "Hair_Pumpkin"					{ source = "Hair_Pumpkin.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_WitchHat"					{ source = "Hair_WitchHat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Spider"					{ source = "Hair_Spider.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_MessyWitch"				{ source = "Hair_MessyWitch.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_MischiefCat"				{ source = "Hair_MischiefCat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_MischiefSmoked"			{ source = "Hair_MischiefSmoked.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_SpiderBun"				{ source = "Hair_SpiderBun.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Feast
resource "Mesh" "Hair_SantaHat"					{ source = "Hair_SantaHat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_WinterBeanie"				{ source = "Hair_WinterBeanie.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_SnowmanHead"				{ source = "Hair_SnowmanHead.fbx",			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_BlueHare"					{ source = "Hair_BlueHare.fbx",			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Frantic"					{ source = "Hair_Frantic.fbx",			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Special
resource "Mesh" "Hair_KizunaAiRed"				{ source = "Hair_KizunaAiRed.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_KizunaAiPink"				{ source = "Hair_KizunaAiPink.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_Elf"						{ source = "Hair_Elf.fbx", 					sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_TravelerRed"				{ source = "Hair_TravelerRed.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_TravelerWhite"			{ source = "Hair_TravelerWhite.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = false, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_PastryShort"				{ source = "Hair_PastryShort.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

------------------
--     HAT      --
------------------

-- Days of Fortune
resource "Mesh" "Hat_FortuneOrange"				{ source = "Hat_FortuneOrange.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_FortuneFish"				{ source = "Hat_FortuneFish.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Love
resource "Mesh" "Hat_FlowerCrownPink"			{ source = "Hat_FlowerCrownPink.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_HeartBeret"				{ source = "Hat_HeartBeret.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Bloom
-- Days of Nature
resource "Mesh" "Hat_Coral"						{ source = "Hat_Coral.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = false }
-- Days of Color
resource "Mesh" "Hat_PoppyRainbow"				{ source = "Hat_PoppyRainbow.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_PoppyRainbowSmall"			{ source = "Hat_PoppyRainbowSmall.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Sky Anniversary
resource "Mesh" "Hat_BirthdayHat_01"			{ source = "Hat_BirthdayHat_01.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_BirthdayHat_02"			{ source = "Hat_BirthdayHat_02.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_BirthdayHat_03"			{ source = "Hat_BirthdayHat_03.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_BirthdayHat_04"			{ source = "Hat_BirthdayHat_04.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_BirthdayHat_05"  			{ source = "Hat_BirthdayHat_05.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_BirthdayHat_06"  			{ source = "Hat_BirthdayHat_06.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_BalloonCrown" 				{ source = "Hat_BalloonCrown.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_BalloonCrab"				{ source = "Hat_BalloonCrab.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_BalloonJellyfish"			{ source = "Hat_BalloonJellyfish.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_BalloonKrill"				{ source = "Hat_BalloonKrill.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_BalloonManta"				{ source = "Hat_BalloonManta.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_OreoHeadband"         		{ source = "Hat_OreoHeadband.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Sunlight
-- Days of Love
resource "Mesh" "Hat_CrystalHearts"				{ source = "Hat_CrystalHearts.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Tournament of Triumph
resource "Mesh" "Hat_Laurel"    			    { source = "Hat_Laurel.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Moonlight
resource "Mesh" "Hat_MoonlightFlower"			{ source = "Hat_MoonlightFlower.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Style
resource "Mesh" "Hat_TopHat"					{ source = "Hat_TopHat.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_Fascinator"				{ source = "Hat_Fascinator.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Mischief
resource "Mesh" "Hat_WitchHat"					{ source = "Hat_WitchHat.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_PumpkinCrab"				{ source = "Hat_PumpkinCrab.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Feast
resource "Mesh" "Hat_SnowflakeGold"				{ source = "Hat_SnowflakeGold.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_Pinecone"			    	{ source = "Hat_Pinecone.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_StackedHat"			    { source = "Hat_StackedHat.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_BlueBow"			    	{ source = "Hat_BlueBow.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Special
resource "Mesh" "Hat_PoppyWhite"				{ source = "Hat_PoppyWhite.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_PoppyRed"					{ source = "Hat_PoppyRed.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_KizunaAi"					{ source = "Hat_KizunaAi.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_MusicNoteGold"				{ source = "Hat_MusicNoteGold.fbx",			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_MusicNoteBlue"				{ source = "Hat_MusicNoteBlue.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_Qixi"						{ source = "Hat_Qixi.fbx", 					sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_FlowerPS"					{ source = "Hat_FlowerPS.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_MothAntenna"			    { source = "Hat_MothAntenna.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_PastryEars"				{ source = "Hat_PastryEars.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true, copyFrameDelay = true }
resource "Mesh" "Hat_PastryTea"					{ source = "Hat_PastryTea.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_PastryMini"				{ source = "Hat_PastryMini.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_Bunny"						{ source = "Hat_Bunny.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_Shell"						{ source = "Hat_Shell.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_SummerHat"					{ source = "Hat_SummerHat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }


------------------
--     MASK     --
------------------
resource "Mesh" "Mask_BasicA"					{ source = "Mask_BasicA.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_BasicQ"					{ source = "Mask_BasicQ.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_BasicSleepy"				{ source = "Mask_BasicSleepy.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_Bandana"					{ source = "Mask_Bandana.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_Smoke"					{ source = "Mask_Smoke.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- Days of Fortune
resource "Mesh" "Mask_RedCheeks"				{ source = "Mask_RedCheeks.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_FortuneOx"				{ source = "Mask_FortuneOx.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_FortuneTiger"				{ source = "Mask_FortuneTiger.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_FortuneRabbit"			{ source = "Mask_FortuneRabbit.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_FortuneDragon"			{ source = "Mask_FortuneDragon.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Love
resource "Mesh" "Mask_Rose"						{ source = "Mask_Rose.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Bloom
resource "Mesh" "Mask_RosePetals"				{ source = "Mask_RosePetals.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Nature
resource "Mesh" "Mask_Ocean"					{ source = "Mask_Ocean.fbx",				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_OceanWaves"            	{ source = "Mask_OceanWaves.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv3 = true }

-- Days of Color
resource "Mesh" "Mask_RainbowDark"				{ source = "Mask_RainbowDark.fbx",			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_ColorFacepaint"				{ source = "Mask_ColorFacepaint.fbx",			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Sky Anniversary
-- Tournament of Triumph
-- Days of Sunlight
-- Days of Moonlight
-- Days of Mischief
resource "Mesh" "Mask_MischiefCat"				{ source = "Mask_MischiefCat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_Crabula"					{ source = "Mask_Crabula.fbx",				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Feast
-- Days of Style
resource "Mesh" "Mask_RunwayMakeup"				{ source = "Mask_RunwayMakeup.fbx",			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Special
resource "Mesh" "Mask_TravelerRed"				{ source = "Mask_TravelerRed.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_TravelerWhite"			{ source = "Mask_TravelerWhite.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_SparrowCheeks"			{ source = "Mask_SparrowCheeks.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- Days of Treasure
resource "Mesh" "Mask_TreasureEyePatch"			{ source = "Mask_TreasureEyePatch.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv3 = true }

------------------
--     FACE     --
------------------

resource "Mesh" "Face_ElderDawn"				{ source = "Face_ElderDawn.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_ElderDay"					{ source = "Face_ElderDay.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_ElderRain"				{ source = "Face_ElderRain.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_ElderSunsetA"				{ source = "Face_ElderSunsetA.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_ElderSunsetB"				{ source = "Face_ElderSunsetB.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_ElderDusk"				{ source = "Face_ElderDusk.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_ElderNight"				{ source = "Face_ElderNight.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_ElderDawn_02"				{ source = "Face_ElderDawn_02.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_ElderDay_02"				{ source = "Face_ElderDay_02.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_ElderRain_02"				{ source = "Face_ElderRain_02.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Sky Anniversary
resource "Mesh" "Face_Anniversary3DGlasses"		{ source = "Face_Anniversary3DGlasses.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }-- Days of Fortune
-- Days of Love
-- Days of Bloom
-- Days of Nature
-- Days of Color
-- Days of Sunlight
-- Days of Moonlight
-- Days of Style
resource "Mesh" "Face_StarSunglasses"			{ source = "Face_StarSunglasses.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_FlameSunglasses"			{ source = "Face_FlameSunglasses.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_HeartSunglasses"			{ source = "Face_HeartSunglasses.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_Monocle"					{ source = "Face_Monocle.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Mischief
resource "Mesh" "Face_HeadCrab"					{ source = "Face_HeadCrab.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_CurseSticker"				{ source = "Face_CurseSticker.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Feast
resource "Mesh" "Face_YetiGoggles"				{ source = "Face_YetiGoggles.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Special
resource "Mesh" "Face_BlueSunglasses"			{ source = "Face_BlueSunglasses.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

------------------
--     HORN     --
------------------
resource "Mesh" "Horn_TuneBand"					{ source = "Horn_TuneBand.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- Days of Fortune
resource "Mesh" "Horn_DragonEarring"        	{ source = "Horn_DragonEarring.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Love
-- Days of Bloom
-- Days of Nature
-- Days of Color
resource "Mesh" "Horn_RainbowTassel"			{ source = "Horn_RainbowTassel.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_RainbowEarring"			{ source = "Horn_RainbowEarring.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_RainbowHeadphones"		{ source = "Horn_RainbowHeadphones.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_DarkRainbowEarring"		{ source = "Horn_DarkRainbowEarring.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Sky Anniversary
-- Tournament of Triumph
-- Days of Sunlight
resource "Mesh" "Horn_SunnyEarring"     	   	{ source = "Horn_SunnyEarring.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Moonlight
resource "Mesh" "Horn_MoonEarring"     	  	 	{ source = "Horn_MoonEarring.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Style
-- Days of Mischief
resource "Mesh" "Horn_Withered"					{ source = "Horn_Withered.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Feast
resource "Mesh" "Horn_Elk"						{ source = "Horn_Elk.fbx", 					sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Special
resource "Mesh" "Horn_FireworkEarring"			{ source = "Horn_FireworkEarring.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

------------------
--     NECK     --
------------------
resource "Mesh" "Neck_Bow"						{ source = "Neck_Bow.fbx", 					sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_SeaTurtle"				{ source = "Neck_SeaTurtle.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_BlueConch"				{ source = "Neck_BlueConch.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_RibbonBib"				{ source = "Neck_RibbonBib.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_Jellyfish"				{ source = "Neck_Jellyfish.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_Holly"					{ source = "Neck_Holly.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_WinterScarf"				{ source = "Neck_WinterScarf.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_Crab"						{ source = "Neck_Crab.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_CrabBow"					{ source = "Neck_CrabBow.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_MedalGold"				{ source = "Neck_MedalGold.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_MedalSilver"				{ source = "Neck_MedalSilver.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_MedalBronze"				{ source = "Neck_MedalBronze.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_ShoulderButterfly"		{ source = "Neck_ShoulderButterfly.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Fortune
resource "Mesh" "Neck_DragonBodyBlack"			{ source = "Neck_DragonBodyBlack.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_DragonHeadBlack"			{ source = "Neck_DragonHeadBlack.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_DragonTailBlack"			{ source = "Neck_DragonTailBlack.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_DragonBodyWhite"			{ source = "Neck_DragonBodyWhite.fbx",  	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_DragonHeadWhite"			{ source = "Neck_DragonHeadWhite.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Neck_DragonTailWhite"			{ source = "Neck_DragonTailWhite.fbx",  	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Bloom
-- Days of Nature
resource "Mesh" "Neck_OceanScarf"				{ source = "Neck_OceanScarf.fbx",  			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Color
-- Sky Anniversary

-- Days of Sunlight
-- Days of Moonlight
-- Days of Style
resource "Mesh" "Neck_KrillTie"					{ source = "Neck_KrillTie.fbx",  			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
-- Days of Mischief
-- Days of Feast

-- Special
resource "Mesh" "Neck_PastryBow"				{ source = "Neck_PastryBow.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }

------------------
--     PROPS    --
------------------

-- Backpacks
resource "Mesh" "Prop_Backpack"					{ source = "Prop_Backpack.fbx", 			computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, copyFrameDelay = true }
resource "Mesh" "Prop_BackpackDefault"			{ source = "Prop_BackpackDefault.fbx", 		computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, copyFrameDelay = true }
resource "Mesh" "Prop_BackpackFabric"			{ source = "Prop_BackpackFabric.fbx", 		computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, copyFrameDelay = true }

------------------
-- Utility Props
resource "Mesh" "Prop_FireworkStaff"			{ source = "Prop_FireworkStaff.fbx", 		computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_Umbrella"					{ source = "Prop_Umbrella.fbx", 			computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = true, stripNormals = true, loadLazy = true } -- Note: compressPositions turned off due to overlapping positions in bind pose
resource "Mesh" "Prop_Broom"					{ source = "Prop_Broom.fbx", 				computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_Wrench"         			{ source = "Prop_Wrench.fbx", 				computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- resource "Mesh" "CharSkyKid_Prop_ScepterStaff"			{ source = "CharSkyKid_Prop_ScepterStaff.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- Days of Fortune
resource "Mesh" "Prop_FortuneUmbrella"			{ source = "Prop_FortuneUmbrella.fbx",		computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = true, stripNormals = true, loadLazy = true } -- Note: compressPositions turned off due to overlapping positions in bind pose
-- Days of Love
resource "Mesh" "Prop_HeartStaff"				{ source = "Prop_HeartStaff.fbx", 			computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- Days of Treasure
resource "Mesh" "Prop_TreasureShovel"			{ source = "Prop_TreasureShovel.fbx", 		computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

resource "Mesh" "Prop_MeteorHeartDown"						{ source = "Prop_MeteorHeartDown.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true, loadLazy = true }
-- Days of Bloom
resource "Mesh" "Prop_LilyUmbrella"				{ source = "Prop_LilyUmbrella.fbx", 		computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = true, stripNormals = true, loadLazy = true } -- Note: compressPositions turned off due to overlapping positions in bind pose
-- Days of Nature
-- Days of Color
-- Sky Anniversary
resource "Mesh" "Prop_JenovaFan"				{ source = "Prop_JenovaFan.fbx", 			computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AnniversaryClapboard"				{ source = "Prop_AnniversaryClapboard.fbx", 			computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Sunlight
resource "Mesh" "Prop_Lantern"      	      	{ source = "Prop_Lantern.fbx", 				computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Moonlight
-- Days of Style
-- Days of Mischief
-- Days of Feast
-- Special
resource "Mesh" "Prop_ScepterWand"				{ source = "Prop_ScepterWand.fbx", 			computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

------------------
-- Placeables

resource "Mesh" "Prop_InstrumentRackBack"		{ source = "Prop_InstrumentRackBack.fbx", 	loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_StoneMannequin"			{ source = "CharSkyKid_Prop_StoneMannequin.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_StupaBell"				{ source = "Prop_StupaBell.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }

-- Days of Fortune
-- Days of Love
resource "Mesh" "Prop_HeartPlush"				{ source = "Prop_HeartPlush.fbx", 			loadAsync = false, registerCollision = false, computeOcclusions = true }
-- Days of Bloom
-- Days of Nature
-- Days of Music
resource "Mesh" "Prop_SequencerBack"			{ source = "Prop_SequencerBack.fbx", 		computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_PianoUpright"				{ source = "Prop_PianoUpright.fbx", 	loadAsync = false, registerCollision = true, computeOcclusions = true, loadLazy = true }
resource "Mesh" "Prop_PianoUprightBack"			{ source = "Prop_PianoUprightBack.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Days of Color
-- Sky Anniversary
resource "Mesh" "Prop_AnniversaryMovieSeats"				{ source = "Prop_AnniversaryMovieSeats.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_AnniversaryMovieSeats_Backpack"				{ source = "Prop_AnniversaryMovieSeats_Backpack.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_AnniversaryCarpet"				{ source = "Prop_AnniversaryCarpet.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_SkyBalloon"				{ source = "Prop_SkyBalloon.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_BalloonArch"				{ source = "Prop_BalloonArch.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
-- Days of Sunlight
resource "Mesh" "Prop_MantaFloat"				{ source = "Prop_MantaFloat.fbx", 			loadAsync = false, registerCollision = true, computeOcclusions = true }
-- Days of Moonlight
resource "Mesh" "Prop_MoonlightLantern"			{ source = "Prop_MoonlightLantern.fbx", 	loadAsync = false, registerCollision = true, computeOcclusions = true }
-- Days of Style
-- Days of Mischief
resource "Mesh" "Prop_MischiefBroom"				{ source = "Prop_MischiefBroom.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true, copyFrameDelay = true }
resource "Mesh" "Prop_MischiefCauldron"				{ source = "Prop_MischiefCauldron.fbx", 	loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_MischiefCauldronCup"			{ source = "Prop_MischiefCauldronCup.fbx", 	loadAsync = false, registerCollision = false }
-- Days of Feast
resource "Mesh" "Prop_TeaBath"					{ source = "Prop_TeaBath.fbx", 	loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_TeaBathSmallWater"			{ source = "P_TeaBathSmallWater.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_CrabbitPortal"                    { source = "Prop_CrabbitPortal.fbx",     loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_CrabbitPortalDoor"                { source = "Prop_CrabbitPortalDoor.fbx",     loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_CrabbitPortalFrame"               { source = "Prop_CrabbitPortalFrame.fbx",     loadAsync = false, registerCollision = true, computeOcclusions = true }
-- Days of Style
-- Special

resource "Mesh" "CharSkyKid_Prop_Chair"					{ source = "CharSkyKid_Prop_Chair.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_StarJar"               { source = "CharSkyKid_Prop_StarJar_A.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_ChairXmas"				{ source = "CharSkyKid_Prop_ChairXmas.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_Swing"					{ source = "CharSkyKid_Prop_Swing.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_Seesaw"				{ source = "CharSkyKid_Prop_Seesaw.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_Cannon_01"       		{ source = "CharSkyKid_Prop_Cannon_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Prop_Bookshelf"						{ source = "CharSkyKid_Prop_AP10Bookshelf_02.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Hammock"							{ source = "CharSkyKid_Prop_AP10Hammock_02.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "Torch"									{ source = "CharSkyKid_Prop_AP10Torch_01.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Tent"								{ source = "CharSkyKid_Prop_AP10Tent_02.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "Spotlight"								{ source = "CharSkyKid_Prop_AP10Spotlight_01.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_Hoop"								{ source = "CharSkyKid_Prop_AP10Hoop_02.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "Prop_Brazier"							{ source = "CharSkyKid_Prop_AP10Brazier_01.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Jar"								{ source = "CharSkyKid_Prop_AP10Jar_01.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Pillow"							{ source = "CharSkyKid_Prop_AP10Pillow_01.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_PillowXmas_Persistent"			{ source = "Prop_WinterPillow_01.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }

resource "Mesh" "CharSkyKid_Prop_MarshmallowBundle"     { source = "CharSkyKid_Prop_MarshmallowBundle.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true, copyFrameDelay = true}
resource "Mesh" "CharSkyKid_Prop_MarshmallowStick"      { source = "CharSkyKid_Prop_MarshmallowStick.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_TeaTable_01"			{ source = "CharSkyKid_Prop_TeaTable_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_PicnicBlanket_01"		{ source = "CharSkyKid_Prop_PicnicBlanket.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_FlowerArch"			{ source = "CharSkyKid_Prop_FlowerArch.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_WisteriaTea_01"		{ source = "CharSkyKid_Prop_WisteriaTea_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_SummerUmbrella_01"		{ source = "CharSkyKid_Prop_SummerUmbrella_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true } -- Note: compressPositions turned off due to overlapping positions in bind pose
resource "Mesh" "CharSkyKid_Prop_SummerUmbrella_02"		{ source = "CharSkyKid_Prop_SummerUmbrella_02.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true } -- Note: compressPositions turned off due to overlapping positions in bind pose
resource "Mesh" "CharSkyKid_Prop_MischiefChair"			{ source = "CharSkyKid_Prop_MischiefChair.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_VelvetBag_01"			{ source = "CharSkyKid_Prop_VelvetBag_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_FeastBall"				{ source = "CharSkyKid_Prop_FeastBall.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_Gondola_01"			{ source = "CharSkyKid_Prop_Gondola_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_Shield_01"				{ source = "CharSkyKid_Prop_Shield_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_Snowman"               { source = "CharSkyKid_Prop_Snowman.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_AP19Camera"            { source = "CharSkyKid_Prop_Camera.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_AP19UltimateCamera"    { source = "CharSkyKid_Prop_AP19Camera.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_CompetitionTorch"      { source = "CharSkyKid_Prop_CompetitionTorch.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }

------------------
-- Instruments
resource "Mesh" "CharSkyKid_Prop_Harp"					{ source = "CharSkyKid_Prop_Harp.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_Harp_02"				{ source = "CharSkyKid_Prop_Harp_02.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_Bass"					{ source = "CharSkyKid_Prop_Bass.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP04Guitar_01"			{ source = "CharSkyKid_Prop_AP04Guitar_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP04Guitar_02"			{ source = "CharSkyKid_Prop_AP04Guitar_02.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false, copyFrameDelay = true }
resource "Mesh" "CharSkyKid_Prop_AP04Ukulele_01"		{ source = "CharSkyKid_Prop_AP04Ukulele_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP09Lute_01"			{ source = "CharSkyKid_Prop_AP09Lute_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP14Guitar_01"			{ source = "CharSkyKid_Prop_AP14Guitar_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false, copyFrameDelay = true }
resource "Mesh" "CharSkyKid_Prop_AP14Guitar_02"			{ source = "CharSkyKid_Prop_AP14Guitar_02.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false, copyFrameDelay = true }
resource "Mesh" "CharSkyKid_Prop_Piano"					{ source = "CharSkyKid_Prop_Piano.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_APPiano_01"			{ source = "CharSkyKid_Prop_APPiano_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_APPiano_02"			{ source = "CharSkyKid_Prop_APPiano_02.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false, copyFrameDelay = true }
resource "Mesh" "CharSkyKid_Prop_AP05Xylophone_01"		{ source = "CharSkyKid_Prop_AP05Xylophone_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP12Kalimba_01"		{ source = "CharSkyKid_Prop_AP12Kalimba_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_Horn"					{ source = "CharSkyKid_Prop_Horn.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP03Flute_01"			{ source = "CharSkyKid_Prop_AP03Flute_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP03PanFlute_01"		{ source = "CharSkyKid_Prop_AP03PanFlute_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP10Bugle_01"			{ source = "CharSkyKid_Prop_AP10Bugle_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP10Bugle_02"			{ source = "CharSkyKid_Prop_AP10Bugle_02.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false, copyFrameDelay = true }
resource "Mesh" "CharSkyKid_Prop_Ocarina_01"            { source = "CharSkyKid_Prop_Ocarina_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_Drums"					{ source = "CharSkyKid_Prop_Drums.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP02Bell_01"			{ source = "CharSkyKid_Prop_AP02Bell_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP02Bell_02"			{ source = "CharSkyKid_Prop_AP02Bell_02.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP07HandPan"			{ source = "CharSkyKid_Prop_AP07HandPan_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP07HandPan_02"		{ source = "CharSkyKid_Prop_AP07HandPan_02.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false, copyFrameDelay = true }
resource "Mesh" "CharSkyKid_Prop_AP08Dundun"            { source = "CharSkyKid_Prop_AP08Dundun.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_AP08Dundun_02"         { source = "CharSkyKid_Prop_AP08Dundun_02.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false, copyFrameDelay = true }
resource "Mesh" "CharSkyKid_Prop_AP16Microphone"		{ source = "CharSkyKid_Prop_AP16Microphone.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false, copyFrameDelay = true }
resource "Mesh" "CharSkyKid_Prop_AP18Ocarina"			{ source = "CharSkyKid_Prop_AP18Ocarina.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_Violin"				{ source = "CharSkyKid_Prop_Violin.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_Saxophone"				{ source = "CharSkyKid_Prop_Saxophone.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "CharSkyKid_Prop_FortuneDrumSticks"     { source = "CharSkyKid_Prop_FortuneDrumSticks.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }


-- Days of Fortune
resource "Mesh" "CharSkyKid_Prop_FortuneDrumStick"      { source = "Prop_FortuneDrumStick.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "CharSkyKid_Prop_FortuneDrum"         	{ source = "CharSkyKid_Prop_FortuneDrum.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
-- Days of Love
-- Days of Bloom
-- Days of Nature
-- Days of Color
resource "Mesh" "CharSkyKid_Prop_JarBubbleMachine"		{ source = "CharSkyKid_Prop_JarBubbleMachine.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
-- Sky Anniversary
-- Days of Sunlight
-- Days of Moonlight
-- Days of Style
-- Days of Mischief
-- Days of Feast
-- Special

-- AP02 Gratitude Meshes
resource "Mesh" "Neck_AP02Pendant"					{ source = "Neck_AP02Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP02Fur"						{ source = "Wing_AP02Fur.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP02Tail"						{ source = "Wing_AP02Tail.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP02Stupa"					{ source = "Hair_AP02Stupa.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP02Bhutan"					{ source = "Hair_AP02Bhutan.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP02Cone"						{ source = "Hair_AP02Cone.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP02Bird"						{ source = "Mask_AP02Bird.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP02Bull"						{ source = "Mask_AP02Bull.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP02Crab"						{ source = "Mask_AP02Crab.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP02Deer"						{ source = "Mask_AP02Deer.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP02Fox"						{ source = "Mask_AP02Fox.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP02Weasel"					{ source = "Mask_AP02Weasel.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP03 Lightseeker Meshes
resource "Mesh" "Neck_AP03Pendant"					{ source = "Neck_AP03Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP03BiolumBlue"				{ source = "Wing_AP03BiolumBlue.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP03BiolumGlow"				{ source = "Wing_AP03BiolumGlow.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP03Petal"					{ source = "Wing_AP03Petal.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP03Victorian"				{ source = "Hair_AP03Victorian.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP03Samurai"					{ source = "Hair_AP03Samurai.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP03Barrette"					{ source = "Hair_AP03Barrette.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP03Upstyle"					{ source = "Hair_AP03Upstyle.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP03Umbrella"					{ source = "Hair_AP03Umbrella.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP03MaskA"					{ source = "Mask_AP03MaskA.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP03MaskB"					{ source = "Mask_AP03MaskB.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP03MaskC"					{ source = "Mask_AP03MaskC.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP03MaskD"					{ source = "Mask_AP03MaskD.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP03MaskE"					{ source = "Mask_AP03MaskE.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP03MaskF"					{ source = "Mask_AP03MaskF.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP03MaskG"					{ source = "Mask_AP03MaskG.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
-- Umbrella note: compressPositions turned off due to overlapping positions in bind pose
resource "Mesh" "Prop_AP03UmbrellaPurple"			{ source = "Prop_AP03UmbrellaPurple.fbx", 	computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AP03UmbrellaTeal" 			{ source = "Prop_AP03UmbrellaTeal.fbx", 	computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP04 Belonging Meshes
resource "Mesh" "Neck_AP04Pendant"					{ source = "Neck_AP04Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP04Child"					{ source = "Wing_AP04Child.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP04Adult"					{ source = "Wing_AP04Adult.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP04Elder"					{ source = "Wing_AP04Elder.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP04CozyPants"				{ source = "Body_AP04CozyPants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP04Ribbon"					{ source = "Hair_AP04Ribbon.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP04WavyBob"					{ source = "Hair_AP04WavyBob.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP04Child"					{ source = "Mask_AP04Child.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP04Adult"					{ source = "Mask_AP04Adult.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP04Mustache"					{ source = "Mask_AP04Mustache.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP04Beard"					{ source = "Mask_AP04Beard.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_AP04EarMuffs"					{ source = "Horn_AP04EarMuffs.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AP04BonfireBack"				{ source = "Prop_AP04BonfireBack.fbx", 		computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP05 Rhythm Meshes
resource "Mesh" "Neck_AP05Pendant"					{ source = "Neck_AP05Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP05Juggler"					{ source = "Wing_AP05Juggler.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP05Director"					{ source = "Wing_AP05Director.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP05MerchantPants"			{ source = "Body_AP05MerchantPants.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP05DancerPants"				{ source = "Body_AP05DancerPants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP05ActorPants"				{ source = "Body_AP05ActorPants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP05JugglerPants"				{ source = "Body_AP05JugglerPants.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP05Director"					{ source = "Hair_AP05Director.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP05Dancer"					{ source = "Hair_AP05Dancer.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP05Juggler"					{ source = "Hair_AP05Juggler.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP05Musician"					{ source = "Hair_AP05Musician.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP05Default"					{ source = "Mask_AP05Default.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP05Musician"					{ source = "Mask_AP05Musician.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP05Merchant"					{ source = "Mask_AP05Merchant.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP05Actor"					{ source = "Mask_AP05Actor.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP05Director"					{ source = "Mask_AP05Director.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP06 Enchantment Meshes
resource "Mesh" "Neck_AP06Pendant"					{ source = "Neck_AP06Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP06Trim"						{ source = "Wing_AP06Trim.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP06Tassel"					{ source = "Wing_AP06Tassel.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP06LayeredPurple"			{ source = "Wing_AP06LayeredPurple.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP06LayeredYellow"			{ source = "Wing_AP06LayeredYellow.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP06Turban"					{ source = "Hair_AP06Turban.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP06Pigtails"					{ source = "Hair_AP06Pigtails.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP06WizardHat"				{ source = "Hair_AP06WizardHat.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP06ScoutHat"					{ source = "Hair_AP06ScoutHat.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP06WizardHair"				{ source = "Hair_AP06WizardHair.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP06BunRound"					{ source = "Hair_AP06BunRound.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP06ConeHat"					{ source = "Hair_AP06ConeHat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP06VeilPurple"				{ source = "Mask_AP06VeilPurple.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP06VeilGold"					{ source = "Mask_AP06VeilGold.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP06WizardBeard"				{ source = "Mask_AP06WizardBeard.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP06Scarf"					{ source = "Mask_AP06Scarf.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_AP06Tassel"					{ source = "Horn_AP06Tassel.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP07 Sanctuary Meshes
resource "Mesh" "Neck_AP07Pendant"					{ source = "Neck_AP07Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP07Aloha"					{ source = "Wing_AP07Aloha.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP07Shell"					{ source = "Wing_AP07Shell.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP07Butterfly"				{ source = "Wing_AP07Butterfly.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP07Manta"					{ source = "Wing_AP07Manta.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP07Jumpsuits"				{ source = "Body_AP07Jumpsuit.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP07CargoPants"				{ source = "Body_AP07CargoPants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP07BowTie"					{ source = "Neck_AP07BowTie.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP07Jellyfish"				{ source = "Hair_AP07Jellyfish.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP07Braid"					{ source = "Hair_AP07Braid.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP07BowlCut"					{ source = "Hair_AP07BowlCut.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP07Balding"					{ source = "Hair_AP07Balding.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP07Undercut"					{ source = "Hair_AP07Undercut.fbx",			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP07StrawHat"  		    	{ source = "Hat_AP07StrawHat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP07ThickBrows"				{ source = "Mask_AP07ThickBrows.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_AP07Sunglasses"				{ source = "Face_AP07Sunglasses.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP08 Prophecy Meshes
resource "Mesh" "Neck_AP08Pendant"					{ source = "Neck_AP08Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP08Bat"						{ source = "Wing_AP08Bat.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP08Turtle"					{ source = "Wing_AP08Turtle.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP08Spider"					{ source = "Wing_AP08Spider.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP08BaggyPants"				{ source = "Body_AP08BaggyPants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP08ShortDreads"				{ source = "Hair_AP08ShortDreads.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP08Ponytail"					{ source = "Hair_AP08Ponytail.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP08Braid"					{ source = "Hair_AP08Braid.fbx",			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP08DoubleBun"				{ source = "Hair_AP08DoubleBun.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP08Turtle"					{ source = "Mask_AP08Turtle.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP08Wolf"						{ source = "Mask_AP08Wolf.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP08Bat"						{ source = "Mask_AP08Bat.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP08Spider"					{ source = "Mask_AP08Spider.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP08Lion"						{ source = "Mask_AP08Lion.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP09 Dreams Meshes
resource "Mesh" "Neck_AP09Pendant"					{ source = "Neck_AP09Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP09Waves"					{ source = "Wing_AP09Waves.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP09Robe"						{ source = "Wing_AP09Robe.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP09Fur"						{ source = "Wing_AP09Fur.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP09Phoenix"					{ source = "Wing_AP09Phoenix.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP09Yeti"						{ source = "Body_AP09Yeti.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP09Uniform"					{ source = "Body_AP09Uniform.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Feet_AP09UniformBoots"				{ source = "Feet_AP09UniformBoots.fbx",		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP09Hat"						{ source = "Hair_AP09Hat.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP09Yeti"						{ source = "Hair_AP09Yeti.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP09MultiBuns"				{ source = "Hair_AP09MultiBuns.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP09BambooHat"				{ source = "Hair_AP09BambooHat.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP09Rabbit"					{ source = "Mask_AP09Rabbit.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP09Phoenix"					{ source = "Mask_AP09Phoenix.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP09Pigeon"					{ source = "Mask_AP09Pigeon.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP09Quail"					{ source = "Mask_AP09Quail.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_AP09Yeti"						{ source = "Horn_AP09Yeti.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP10 Assembly Meshes
resource "Mesh" "Neck_AP10Pendant"					{ source = "Neck_AP10Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP10YellowCape"				{ source = "Wing_AP10YellowCape.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP10GreenCape"				{ source = "Wing_AP10GreenCape.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP10Overalls"					{ source = "Body_AP10Overalls.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Feet_AP10Overalls"            		{ source = "Feet_AP10Overalls.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP10PotHat"					{ source = "Hair_AP10PotHat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP10StrawCrown"				{ source = "Hair_AP10StrawCrown.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP10Bandana"					{ source = "Hair_AP10Bandana.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP10PonytailDreads"			{ source = "Hair_AP10PonytailDreads.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP10LongBangs"				{ source = "Hair_AP10LongBangs.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP10FrontBraids"				{ source = "Hair_AP10FrontBraids.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP10MaskA"					{ source = "Mask_AP10MaskA.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP10MaskB"					{ source = "Mask_AP10MaskB.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP10MaskC"					{ source = "Mask_AP10MaskC.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP10MaskD"					{ source = "Mask_AP10MaskD.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP10QuestGiver"				{ source = "Mask_AP10QuestGiver.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP10Eyepatch"					{ source = "Mask_AP10Eyepatch.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP10Sticks"					{ source = "Mask_AP10Sticks.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

resource "Mesh" "CharSkyKid_Prop_AP10Hammock_01" 		{ source = "CharSkyKid_Prop_AP10Hammock_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_AP10Tent_01"			{ source = "CharSkyKid_Prop_AP10Tent_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_AP10Tent_03"			{ source = "CharSkyKid_Prop_AP10Tent_03.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyKid_Prop_AP10Hoop_01"			{ source = "CharSkyKid_Prop_AP10Hoop_01.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }

-- AP11 The Little Prince Meshes
resource "Mesh" "Neck_AP11Pendant"					{ source = "Neck_AP11Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP11Tattered"					{ source = "Wing_AP11Tattered.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP11HeavyFur"					{ source = "Wing_AP11HeavyFur.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP11Wrinkled"					{ source = "Wing_AP11Wrinkled.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP11Uniform"					{ source = "Wing_AP11Uniform.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP11GreenCoat"				{ source = "Wing_AP11GreenCoat.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP11Scarf"					{ source = "Wing_AP11Scarf.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP11Ancestor"					{ source = "Body_AP11Ancestor.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP11Sword"					{ source = "Body_AP11Sword.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP11GreenPajama"				{ source = "Body_AP11GreenPajama.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP11Ascot"					{ source = "Neck_AP11Ascot.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP11ConeHat"					{ source = "Hair_AP11ConeHat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP11Messy"					{ source = "Hair_AP11Messy.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP11LongWavy"					{ source = "Hair_AP11LongWavy.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP11Crown"					{ source = "Hair_AP11Crown.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP11UniformHat"				{ source = "Hair_AP11UniformHat.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP11Prince"					{ source = "Hair_AP11Prince.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP11Frog"						{ source = "Mask_AP11Frog.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AP11Fox"						{ source = "Prop_AP11Fox.fbx", 				loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_AP11FoxBack"					{ source = "Prop_AP11FoxBack.fbx", 			computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, copyFrameDelay = true }

-- AP12 Flight Meshes
resource "Mesh" "Neck_AP12Pendant"					{ source = "Neck_AP12Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP12Scales"					{ source = "Neck_AP12Scales.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP12BlueWing"					{ source = "Wing_AP12BlueWing.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP12TwoTone"					{ source = "Wing_AP12TwoTone.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP12GradientTunic"			{ source = "Body_AP12GradientTunic.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP12DarkTunic"				{ source = "Body_AP12DarkTunic.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP12YellowTunic"				{ source = "Body_AP12YellowTunic.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP12BlueTunic"				{ source = "Body_AP12BlueTunic.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP12FeatherHat"				{ source = "Hair_AP12FeatherHat.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP12RuffledLong"				{ source = "Hair_AP12RuffledLong.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP12RuffledShort"				{ source = "Hair_AP12RuffledShort.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP12Goggles"					{ source = "Hair_AP12Goggles.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP12Dove"						{ source = "Hat_AP12Dove.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP12SideFeather"				{ source = "Hat_AP12SideFeather.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP12DoubleFeather"				{ source = "Hat_AP12DoubleFeather.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP12DeluxeFeather"				{ source = "Hat_AP12DeluxeFeather.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP13 Abyss Meshes
resource "Mesh" "Neck_AP13Pendant"					{ source = "Neck_AP13Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP13Coat"						{ source = "Wing_AP13Coat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP13Shawl"					{ source = "Wing_AP13Shawl.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP13Shoulder"					{ source = "Wing_AP13Shoulder.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP13NobleCloak"				{ source = "Wing_AP13NobleCloak.fbx",		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP13LeatherScales"			{ source = "Wing_AP13LeatherScales.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP13Tunic_01"					{ source = "Body_AP13Tunic.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP13BucketHat"				{ source = "Hair_AP13BucketHat.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP13LongBraids" 		    	{ source = "Hair_AP13LongBraids.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP13TattooBraids"  			{ source = "Hair_AP13TattooBraids.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP13AcornHat"    		 		{ source = "Hat_AP13AcornHat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP13FullBeard"				{ source = "Mask_AP13FullBeard.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP13Cracked"     				{ source = "Mask_AP13Cracked.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP13BraidedBeard"  			{ source = "Mask_AP13BraidedBeard.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP13Scar"     				{ source = "Mask_AP13Scar.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP13SnorkelLite"    			{ source = "Mask_AP13SnorkelLite.fbx",		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP13Snorkel"     				{ source = "Mask_AP13Snorkel.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_AP13Braids"					{ source = "Horn_AP13Braids.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP14 Performance Meshes
resource "Mesh" "Neck_AP14Pendant"					{ source = "Neck_AP14Pendant.fbx",			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP14Jester"					{ source = "Wing_AP14Jester.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP14Tuxedo"					{ source = "Wing_AP14Tuxedo.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP14TatteredScarf"			{ source = "Wing_AP14TatteredScarf.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP14ShadowPants"				{ source = "Body_AP14ShadowPants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP14DancerSkirt"				{ source = "Body_AP14DancerSkirt.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP14JesterPants"				{ source = "Body_AP14JesterPants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP14JesterHood"				{ source = "Hair_AP14JesterHood.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP14ShadowHood"				{ source = "Hair_AP14ShadowHood.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP14HeadWrap"					{ source = "Hair_AP14HeadWrap.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP14CurlyLong"				{ source = "Hair_AP14CurlyLong.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP14TuftedDirector"			{ source = "Hair_AP14TuftedDirector.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP14LongTufts"    		 	{ source = "Mask_AP14LongTufts.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP14Determined"				{ source = "Mask_AP14Determined.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP14Surprised"				{ source = "Mask_AP14Surprised.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP14Focused"					{ source = "Mask_AP14Focused.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP14Happy"					{ source = "Mask_AP14Happy.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP14Sad"						{ source = "Mask_AP14Sad.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AP14VaseBouquet"				{ source = "Prop_AP14VaseBouquet.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }

-- AP15 Shattering Meshes
resource "Mesh" "Neck_AP15Pendant"					{ source = "Neck_AP15Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP15Crab"						{ source = "Neck_AP15Crab.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP15Krill"					{ source = "Wing_AP15Krill.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP15BigManta"					{ source = "Wing_AP15BigManta.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP15BabyManta"				{ source = "Wing_AP15BabyManta.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP15DarkPlant"				{ source = "Wing_AP15DarkPlant.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP15Jellyfish"				{ source = "Wing_AP15Jellyfish.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP15LightCreature"			{ source = "Body_AP15LightCreature.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP15Krill"					{ source = "Hair_AP15Krill.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP15Manta"					{ source = "Hair_AP15Manta.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP15Jellyfish"				{ source = "Hair_AP15Jellyfish.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP15DarkPlant"					{ source = "Hat_AP15DarkPlant.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP15Butterfly"					{ source = "Hat_AP15Butterfly.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP15DarkPlant"				{ source = "Mask_AP15DarkPlant.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AP15DarkHorn"					{ source = "Prop_AP15DarkHorn.fbx", 		computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP16 Aurora Meshes
resource "Mesh" "Neck_AP16Pendant"					{ source = "Neck_AP16Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP16Fire"						{ source = "Wing_AP16Fire.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP16Wind"						{ source = "Wing_AP16Wind.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP16Water"					{ source = "Wing_AP16Water.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP16Earth"					{ source = "Wing_AP16Earth.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP16OrangeLove"				{ source = "Wing_AP16OrangeLove.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP16ButterflyBlue"			{ source = "Wing_AP16ButterflyBlue.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP16ButterflyYellow"			{ source = "Wing_AP16ButterflyYellow.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP16WhiteCropTop"				{ source = "Body_AP16WhiteCropTop.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP16SlateRunaway"				{ source = "Body_AP16SlateRunaway.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP16OrangeLove"				{ source = "Body_AP16OrangeLove.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP16BlueSeed"					{ source = "Body_AP16BlueSeed.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP16GreenCure"				{ source = "Body_AP16GreenCure.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP16Fire"						{ source = "Hair_AP16Fire.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP16Water"					{ source = "Hair_AP16Water.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP16Wind"						{ source = "Hair_AP16Wind.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP16Earth"					{ source = "Hair_AP16Earth.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP16RunawayBob"				{ source = "Hair_AP16RunawayBob.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP16ClassicAurora"			{ source = "Hair_AP16ClassicAurora.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP16Fire"						{ source = "Mask_AP16Fire.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP16Water"					{ source = "Mask_AP16Water.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP16Wind"						{ source = "Mask_AP16Wind.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP16Earth"					{ source = "Mask_AP16Earth.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP16CureForMe"				{ source = "Mask_AP16CureForMe.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_AP16MoonStar"   		 		{ source = "Horn_AP16MoonStar.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP17 Remembrance Meshes
resource "Mesh" "Neck_AP17Pendant"					{ source = "Neck_AP17Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP17TiedShawl"				{ source = "Wing_AP17TiedShawl.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP17UniformCloak"				{ source = "Wing_AP17UniformCloak.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP17InjuredSoldier"			{ source = "Wing_AP17InjuredSoldier.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP17Injured"					{ source = "Body_AP17Injured.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP17Apron"					{ source = "Body_AP17Apron.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP17RaggedTunic"				{ source = "Body_AP17RaggedTunic.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Feet_AP17RaggedTunic"				{ source = "Feet_AP17RaggedTunic.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP17Scarf"					{ source = "Neck_AP17Scarf.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP17Sash"						{ source = "Neck_AP17Sash.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP17PaperboyCap"				{ source = "Hair_AP17PaperboyCap.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP17Genius"					{ source = "Hair_AP17Genius.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP17BandanaBraid"				{ source = "Hair_AP17BandanaBraid.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP17PuffyBeard"				{ source = "Mask_AP17PuffyBeard.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP17Injured"					{ source = "Mask_AP17Injured.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

resource "Mesh" "Prop_AP17Chimes"						{ source = "CharSkyKid_Prop_AP17Chimes.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_AP17Plants"						{ source = "CharSkyKid_Prop_AP17Plants.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_AP17Kettle"						{ source = "CharSkyKid_Prop_AP17Kettle.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "CharSkyKid_Prop_AP17Chimes_01" 	    { source = "WindChime_01.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_AP17Crab"							{ source = "CharSkyKid_Prop_AP17Crab.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_AP17Manta"						{ source = "CharSkyKid_Prop_AP17Manta.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }

-- AP18 Passage Meshes
resource "Mesh" "Neck_AP18Pendant"					{ source = "Neck_AP18Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP18FauxPelt"					{ source = "Wing_AP18FauxPelt.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP18FurryGuard"				{ source = "Wing_AP18FurryGuard.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP18RaccoonTail"				{ source = "Wing_AP18RaccoonTail.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP18LightRobe"				{ source = "Body_AP18LightRobe.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP18DarkRobe"					{ source = "Body_AP18DarkRobe.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP18FluffyRuff"				{ source = "Neck_AP18FluffyRuff.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP18Spiky"					{ source = "Hair_AP18Spiky.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP18MediumBob"				{ source = "Hair_AP18MediumBob.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP18AtlasPony"				{ source = "Hair_AP18AtlasPony.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP18SideFade"					{ source = "Hair_AP18SideFade.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP18Bear"						{ source = "Mask_AP18Bear.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP18Serow"					{ source = "Mask_AP18Serow.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP18Boar"						{ source = "Mask_AP18Boar.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP18Raccoon"					{ source = "Mask_AP18Raccoon.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP18Monkey"					{ source = "Mask_AP18Monkey.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_AP18Tusk"						{ source = "Horn_AP18Tusk.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_AP18FabricStrip"				{ source = "Horn_AP18FabricStrip.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AP18Ball"						{ source = "Prop_AP18Ball.fbx", 			loadAsync = false, registerCollision = false, computeOcclusions = true }

-- AP19 Moments Meshes
resource "Mesh" "Neck_AP19Pendant"					{ source = "Neck_AP19Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP19Poncho"					{ source = "Wing_AP19Poncho.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP19MonkRobe"					{ source = "Body_AP19MonkRobe.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP19CargoShorts"				{ source = "Body_AP19CargoShorts.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Feet_AP19CargoShorts"				{ source = "Feet_AP19CargoShorts.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP19Skull"					{ source = "Hair_AP19Skull.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP19HeadTattoo"				{ source = "Hair_AP19HeadTattoo.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP19DoubleBraidBack"			{ source = "Hair_AP19DoubleBraidBack.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP19Dew"						{ source = "Hat_AP19Dew.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, copyFrameDelay = true }
resource "Mesh" "Hat_AP19TriangleHat"				{ source = "Hat_AP19TriangleHat.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP19WesternHat"				{ source = "Hat_AP19WesternHat.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP19Scruffy"					{ source = "Mask_AP19Scruffy.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP19Blindfold"				{ source = "Mask_AP19Blindfold.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_AP19Glasses"					{ source = "Face_AP19Glasses.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_AP19Straw"					{ source = "Face_AP19Straw.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, copyFrameDelay = true }
resource "Mesh" "Face_AP19SkullJaw"					{ source = "Face_AP19SkullJaw.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

resource "Mesh" "Prop_AP19CrystalJar"				{ source = "Prop_AP19CrystalJar.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }

-- AP20 Revival Meshes
resource "Mesh" "Neck_AP20Pendant"					{ source = "Neck_AP20Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP20SlickBowlCut"				{ source = "Hair_AP20SlickBowlCut.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP20Beads"					{ source = "Hair_AP20Beads.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP20Maypole"					{ source = "Hair_AP20Maypole.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP20MaypoleNoRibbons"			{ source = "Hair_AP20MaypoleNoRibbons.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP20MaypoleScarf"				{ source = "Neck_AP20MaypoleScarf.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Feet_AP20RobeSandals"				{ source = "Feet_AP20RobeSandals.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Feet_AP20ShortStraps"				{ source = "Feet_AP20ShortStraps.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Feet_AP20LongStraps"				{ source = "Feet_AP20LongStraps.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP20Robe"						{ source = "Body_AP20Robe.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP20MessageBoat"				{ source = "Hat_AP20MessageBoat.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP20Ribbon"					{ source = "Hat_AP20Ribbon.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP20Rhythm"					{ source = "Wing_AP20Rhythm.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP20Gratitude"				{ source = "Wing_AP20Gratitude.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP20Enchantment"				{ source = "Wing_AP20Enchantment.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP20Abyss"					{ source = "Wing_AP20Abyss.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP20MaypoleScarf"				{ source = "Wing_AP20MaypoleScarf.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP21 Deer Meshes
resource "Mesh" "NPC_AP21SilkRaiment"				{ source = "NPC_AP21SilkRaiment.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP21RoyalDress"				{ source = "NPC_AP21RoyalDress.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP21Coat"						{ source = "NPC_AP21Coat.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP21LinenPants"				{ source = "NPC_AP21LinenPants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

resource "Mesh" "Neck_AP21Pendant"					{ source = "Neck_AP21Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP21FancyUpdo"				{ source = "Hair_AP21FancyUpdo.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP21Turban"					{ source = "Hair_AP21Turban.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP21RoyalBun"					{ source = "Hair_AP21RoyalBun.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP21HunterBun"				{ source = "Hair_AP21HunterBun.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP21SilkRaiment"				{ source = "Body_AP21SilkRaiment.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP21LinenPants"				{ source = "Body_AP21LinenPants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP21RoyalDress"				{ source = "Body_AP21RoyalDress.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP21Coat"						{ source = "Body_AP21Coat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_AP21Deer"						{ source = "Horn_AP21Deer.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Hat_AP21Lotus"						{ source = "Hat_AP21Lotus.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP21Crown"						{ source = "Hat_AP21Crown.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP21Deer"						{ source = "Mask_AP21Deer.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP21Crescent"					{ source = "Mask_AP21Crescent.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP21PaintMakeup"				{ source = "Mask_AP21PaintMakeup.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP21Eyebrows"					{ source = "Mask_AP21Eyebrows.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP21SilkSash"					{ source = "Wing_AP21SilkSash.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP21Deer"						{ source = "Wing_AP21Deer.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP21SilkShawl"				{ source = "Wing_AP21SilkShawl.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP21LinenScarf"				{ source = "Wing_AP21LinenScarf.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP21KingCloak"				{ source = "Wing_AP21KingCloak.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AP21Basket"					{ source = "Prop_AP21Basket.fbx", 			loadAsync = false, registerCollision = true, computeOcclusions = true }

-- AP22 Nesting Meshes
resource "Mesh" "NPC_AP22Designer"					{ source = "NPC_AP22Designer.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

resource "Mesh" "Body_AP22Designer"					{ source = "Body_AP22Designer.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP22Pendant"					{ source = "Neck_AP22Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP22Pigtail"					{ source = "Hair_AP22Pigtail.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP22Pencil"					{ source = "Hat_AP22Pencil.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP22Designer"					{ source = "Wing_AP22Designer.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

resource "Mesh" "Prop_AP22HangingLightBack"			{ source = "Prop_AP22HangingLightBack.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AP22FigurineBack"				{ source = "Prop_AP22FigurineBack.fbx", 	computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP23 Duet Meshes
resource "Mesh" "NPC_AP23CellistDress"				{ source = "NPC_AP23CellistDress.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "NPC_AP23CellistBasic"				{ source = "NPC_AP23CellistBasic.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "NPC_AP23PianistBasic"				{ source = "NPC_AP23PianistBasic.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "NPC_AP23PianistSuit"				{ source = "NPC_AP23PianistSuit.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }

resource "Mesh" "Neck_AP23Pendant"					{ source = "Neck_AP23Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP23CellistBun"				{ source = "Hair_AP23CellistBun.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP23PianistKnot"				{ source = "Hair_AP23PianistKnot.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP23Seahorse"					{ source = "Mask_AP23Seahorse.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_AP23Filigree"					{ source = "Face_AP23Filigree.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP23PianistBasic"				{ source = "Body_AP23PianistBasic.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP23PianistSuit"				{ source = "Body_AP23PianistSuit.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP23CellistBasic"				{ source = "Body_AP23CellistBasic.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP23CellistDress"				{ source = "Body_AP23CellistDress.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Feet_AP23WrapSandals"				{ source = "Feet_AP23WrapSandals.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP23PianistShawl"				{ source = "Wing_AP23PianistShawl.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP23PianistCloak"				{ source = "Wing_AP23PianistCloak.fbx",		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP23CellistShawl"				{ source = "Wing_AP23CellistShawl.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP23CellistCloak"				{ source = "Wing_AP23CellistCloak.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

resource "Mesh" "Prop_AP23PianoBasicBack"			{ source = "Prop_AP23PianoBasicBack.fbx", 	computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AP23PianoUprightBack"			{ source = "Prop_AP23PianoUprightBack.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AP23PianoFancyBack"			{ source = "Prop_AP23PianoFancyBack.fbx", 	computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

resource "Mesh" "Prop_AP23CelloBasic"				{ source = "Prop_AP23CelloBasic.fbx", 		computeOcclusions = true, computeEdges = false, loadLazy = true }
resource "Mesh" "Prop_AP23CelloFancy"				{ source = "Prop_AP23CelloFancy.fbx", 		computeOcclusions = true, computeEdges = false, loadLazy = true }
resource "Mesh" "Prop_AP23CelloBowBasic"			{ source = "Prop_AP23CelloBowBasic.fbx", 	loadAsync = false, registerCollision = false, loadLazy = true }
resource "Mesh" "Prop_AP23CelloBowFancy"			{ source = "Prop_AP23CelloBowFancy.fbx", 	loadAsync = false, registerCollision = false, loadLazy = true }

resource "Mesh" "Prop_AP23PianoBasic"				{ source = "Prop_AP23PianoBasic.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true, loadLazy = true }
resource "Mesh" "Prop_AP23PianoUpright"				{ source = "Prop_AP23PianoUpright.fbx", 	loadAsync = false, registerCollision = true, computeOcclusions = true, loadLazy = true }
resource "Mesh" "Prop_AP23PianoBasicSeat"			{ source = "Prop_AP23PianoBasicSeat.fbx", 	loadAsync = false, registerCollision = true, loadLazy = true }
resource "Mesh" "Prop_AP23PianoFancy"				{ source = "Prop_AP23PianoFancy.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true, loadLazy = true }
resource "Mesh" "Prop_AP23PianoFancySeat"			{ source = "Prop_AP23PianoFancySeat.fbx", 	loadAsync = false, registerCollision = true, loadLazy = true}
resource "Mesh" "Prop_RugSmallSolid_AP23Pianist"	{ source = "P_AP23RugPianist.fbx", 			loadAsync = false, registerCollision = false, loadLazy = false }
resource "Mesh" "Prop_RugSmallSolid_AP23Cellist"	{ source = "P_AP23RugCellist.fbx", 			loadAsync = false, registerCollision = false, loadLazy = false }



-- AP24 Moomin Meshes
resource "Mesh" "NPC_AP24Classic"					{ source = "NPC_AP24Classic.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP24Stripes"					{ source = "NPC_AP24Stripes.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP24Apron"						{ source = "NPC_AP24Apron.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP24TopHat"					{ source = "NPC_AP24TopHat.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP24Triangle"					{ source = "NPC_AP24Triangle.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP24Ears"						{ source = "NPC_AP24Ears.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP24Onion"						{ source = "NPC_AP24Onion.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP24BellOnly"					{ source = "NPC_AP24BellOnly.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP24BellShoes"					{ source = "NPC_AP24BellShoes.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP24BellShoesCham"					{ source = "NPC_AP24BellShoesCham.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP24BellDress"					{ source = "NPC_AP24BellDress.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP24BellFull"					{ source = "NPC_AP24BellFull.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

resource "Mesh" "Neck_AP24Pendant"					{ source = "Neck_AP24Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP24OnionRibbon"				{ source = "Neck_AP24OnionRibbon.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP24Bell"						{ source = "Neck_AP24Bell.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP24TriangleScarf"			{ source = "Neck_AP24TriangleScarf.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP24StripesScarf"				{ source = "Neck_AP24StripesScarf.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP24Arms"						{ source = "Neck_AP24Arms.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP24Onion"					{ source = "Hair_AP24Onion.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP24Triangle"					{ source = "Hair_AP24Triangle.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP24Classic"					{ source = "Body_AP24Classic.fbx",	 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP24Triangle"					{ source = "Body_AP24Triangle.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP24Invisible"				{ source = "Body_AP24Invisible.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP24Bell"						{ source = "Body_AP24Bell.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Feet_AP24BellShoes"				{ source = "Feet_AP24BellShoes.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Tail_AP24Classic"					{ source = "Tail_AP24Classic.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP24ClassicEars"				{ source = "Hat_AP24ClassicEars.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP24BellRibbon"				{ source = "Hat_AP24BellRibbon.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP24TriangleHat"				{ source = "Hat_AP24TriangleHat.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP24Wreath"					{ source = "Hat_AP24Wreath.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP24Bell"						{ source = "Wing_AP24Bell.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP24Triangle"					{ source = "Wing_AP24Triangle.fbx", 	    sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP24Arms"						{ source = "Wing_AP24Arms.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

resource "Mesh" "Prop_AP24ClassicPlush"				{ source = "Prop_AP24ClassicPlush.fbx", 	loadAsync = false, registerCollision = true }
resource "Mesh" "Prop_AP24ClassicPlushBack"			{ source = "Prop_AP24ClassicPlushBack.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Prop_AP24Tent"						{ source = "Prop_AP24Tent.fbx", 			loadAsync = false, registerCollision = true }
resource "Mesh" "Prop_AP24TentCollision"			{ source = "Prop_AP24TentCollision.fbx", 	loadAsync = false, registerCollision = true }
resource "Mesh" "Prop_AP24TentBack"					{ source = "Prop_AP24TentBack.fbx", 		computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Prop_AP24Harmonica"				{ source = "Prop_AP24Harmonica.fbx", 		computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false }
resource "Mesh" "Prop_AP24Umbrella"					{ source = "Prop_AP24Umbrella.fbx", 		computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true } -- Note: compressPositions turned off due to overlapping positions in bind pose


-- AP25 Meshes
resource "Mesh" "NPC_AP25BigPants"				{ source = "NPC_AP25BigPants.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP25Tunic"					{ source = "NPC_AP25Tunic.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP25Wrap"					{ source = "NPC_AP25Wrap.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP25DyeCloth"				{ source = "NPC_AP25DyeCloth.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP25BigPants"					{ source = "Body_AP25BigPants.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP25RolledSleeve"			{ source = "Body_AP25RolledSleeve.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP25Wrap"						{ source = "Body_AP25Wrap.fbx",	 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP25Tunic"					{ source = "Body_AP25Tunic.fbx",	 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Feet_AP25BootTall"					{ source = "Feet_AP25BootTall.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Feet_AP25BootShort"				{ source = "Feet_AP25BootShort.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP25BlueRibbon"				{ source = "Hat_AP25BlueRibbon.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP25Bob"						{ source = "Hair_AP25Bob.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP25BluePaint"				{ source = "Hair_AP25BluePaint.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_AP25YellowPaint"				{ source = "Horn_AP25YellowPaint.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP25Gazelle"					{ source = "Mask_AP25Gazelle.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP25Detached"					{ source = "Wing_AP25Detached.fbx", 	    sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP25Ribbons"					{ source = "Wing_AP25Ribbons.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP25DyeCloth"					{ source = "Wing_AP25DyeCloth.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AP25Cymbals"			{ source = "Prop_AP25Cymbals.fbx", computeOcclusions = true, computeEdges = false, compressPositions = false, compressUvs = false, stripNormals = false, loadLazy = true, stripUv13 = false, copyFrameDelay = true }
resource "Mesh" "Prop_AP25ClothDivider"			{ source = "Prop_AP25ClothDivider.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = false, copyFrameDelay = true }
resource "Mesh" "Neck_AP25Pendant"					{ source = "Neck_AP25Pendant.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- AP26 Meshes
resource "Mesh" "NPC_AP26Lumberjack"			{ source = "NPC_AP26Lumberjack.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true  }
resource "Mesh" "NPC_AP26Royal"					{ source = "NPC_AP26Royal.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true  }
resource "Mesh" "NPC_AP26Gown"					{ source = "NPC_AP26Gown.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true  }
resource "Mesh" "Body_AP26Royal"				{ source = "Body_AP26Royal.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP26Lumberjack"			{ source = "Body_AP26Lumberjack.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Horn_AP26EarMuff"				{ source = "Horn_AP26EarMuff.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP26Heuke"				{ source = "Wing_AP26Heuke.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP26Hourglass"			{ source = "Wing_AP26Hourglass.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP26MoonCloak"			{ source = "Wing_AP26MoonCloak.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_AP26BlueBird"				{ source = "Wing_AP26BlueBird.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Feet_AP26LumberjackBoots"		{ source = "Feet_AP26LumberjackBoots.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Neck_AP26Pendant"				{ source = "Neck_AP26Pendant.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP26RedBow"				{ source = "Hat_AP26RedBow.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hair_AP26LowHat"				{ source = "Hair_AP26LowHat.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Hat_AP26FeatherClip"			{ source = "Hat_AP26FeatherClip.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_AP26Plume"				{ source = "Face_AP26Plume.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_AP26Gown"					{ source = "Body_AP26Gown.fbx",	 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Face_AP26BlueWings"			{ source = "Face_AP26BlueWings.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Mask_AP26Peacock"					{ source = "Mask_AP26Peacock.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_AP26TreePerch"			{ source = "Prop_AP26TreePerch.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = false, copyFrameDelay = true }


-- Mischief 2.0 Meshes
resource "Mesh" "CharSkyKid_Prop_MischiefCat"   { source = "CharSkyKid_Prop_MischiefCat.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Prop_MischiefCat"              { source = "Prop_MischiefCat.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }

resource "Mesh" "CurrencyCandy"                	{ source = "CurrencyCandy.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }

-- Cafe Meshes

resource "Mesh" "CharSkyKid_Prop_PastryBackpack"    { source = "CharSkyKid_Prop_PastryBackpack.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true, copyFrameDelay = true }
resource "Mesh" "Prop_PastryPlush"                  { source = "Prop_PastryPlush.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true, copyFrameDelay = true }

resource "Mesh" "Wing_PastryCloud"				    { source = "Wing_PastryCloud.fbx", 			    sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyKid_Prop_PastryTeaTable"	{ source = "CharSkyKid_Prop_PastryTeaTable.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Prop_PastryTeaTable"				{ source = "Prop_PastryTeaTable.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "Prop_PastryTeaTable_Cup"			{ source = "Prop_PastryTeaTable_Cup.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_PastryTeaTable_Saucer"		{ source = "Prop_PastryTeaTable_Saucer.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_PastryTeaTable_Food_Blue"		{ source = "Prop_PastryTeaTable_Food_Blue.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_PastryTeaTable_Food_Yellow"	{ source = "Prop_PastryTeaTable_Food_Yellow.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_PastryTeaTable_Food_Red"		{ source = "Prop_PastryTeaTable_Food_Red.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_PastryTeaTable_Tea"			{ source = "Prop_PastryTeaTable_Tea.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Horn_PastryRoll"             		{ source = "Hat_PastryRoll.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }



-- Anniversary4 Meshes
resource "Mesh" "Prop_BirthdayOreo"         { source = "Prop_BirthdayOreo.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_OreoPlush"            { source = "Prop_OreoPlush.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_StarJar"              { source = "CharSkyKid_Prop_StarJar_B.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_StarJarC"             { source = "CharSkyKid_Prop_StarJar_C.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_CupGlass"            	{ source = "Prop_CupGlass.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_CupUmbrella"          { source = "UmbrellaPick_01.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_CupDrink"            	{ source = "Prop_CupDrink.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_CocoaCup"            	{ source = "Prop_CocoaCup.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_DiscoLight"           { source = "Prop_DiscoLight.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_Anni4BirthdayCakeS"	{ source = "Prop_Anni4BirthdayCakeS.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_AnniversaryPopcorn"   { source = "Prop_AnniversaryPopcorn.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true, copyFrameDelay = true }
resource "Mesh" "Prop_AnniversaryPopcornKernel"   { source = "Prop_AnniversaryPopcornKernel.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true, copyFrameDelay = true }
resource "Mesh" "Prop_AnniversaryTrophy"	{ source = "Prop_AnniversaryTrophy.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
-- NPC MESHES --
resource "Mesh" "NPC_KidLongPantsBody"				{ source = "NPC_KidLongPantsBody.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }

resource "Mesh" "NPC_CivilianMaleBody"				{ source = "NPC_CivilianMaleBody.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "NPC_YoungFemaleBody"				{ source = "NPC_YoungFemaleBody.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "NPC_CivilianMaleShoulder"			{ source = "NPC_CivilianMaleShoulder.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "NPC_CivilianFemaleBody"			{ source = "NPC_CivilianFemaleBody.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "NPC_CivilianFemaleShoulder"		{ source = "NPC_CivilianFemaleShoulder.fbx", 	sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "NPC_CivilianShoes"					{ source = "NPC_CivilianShoes.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "NPC_LaborerMaleBody"				{ source = "NPC_LaborerMaleBody.fbx", 			sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "NPC_LaborerMaleShoulder"			{ source = "NPC_LaborerMaleShoulder.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "NPC_LaborerMaleHeadwrap"			{ source = "NPC_LaborerMaleHeadwrap.fbx", 		sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "NPC_LaborerShoes"					{ source = "NPC_LaborerShoes.fbx", 				sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }

resource "Mesh" "CharSkyNPC_Body_FatLabor"				{ source = "CharSkyNPC_Body_FatLabor.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_FatLaborWave"			{ source = "CharSkyNPC_Body_FatLaborWave.fbx", sharedSkeleton = "CharSkyNPC_Body_FatLaborWave.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_StrongLabor"			{ source = "CharSkyNPC_Body_StrongLabor.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_StrongLaborHammer"		{ source = "CharSkyNPC_Body_StrongLaborHammer.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_FatLaborChild"			{ source = "CharSkyNPC_Body_FatLaborChild.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_FatLaborStaff"			{ source = "CharSkyNPC_Body_FatLaborStaff.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_FemaleCivilian"		{ source = "CharSkyNPC_Body_FemaleCivilian.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_MaleCivilian"			{ source = "CharSkyNPC_Body_MaleCivilian.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_ShadowChildren"		{ source = "CharSkyNPC_Body_ShadowChildren.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_SkinnyIntellectual"	{ source = "CharSkyNPC_Body_SkinnyIntellectual.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_StrongKnight"			{ source = "CharSkyNPC_Body_StrongKnight.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_MerchantRig"			{ source = "CharSkyNPC_Body_MerchantRig.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_ActorRig"				{ source = "CharSkyNPC_Body_ActorRig.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_DirectorRig"			{ source = "CharSkyNPC_Body_DirectorRig.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_DancerRig"				{ source = "CharSkyNPC_Body_DancerRig.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_JugglerRig"			{ source = "CharSkyNPC_Body_JugglerRig.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_MusicianRig"			{ source = "CharSkyNPC_Body_MusicianRig.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP07CargoPants_01"		{ source = "CharSkyNPC_Body_AP07CargoPants_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP07Jumpsuits_01"		{ source = "CharSkyNPC_Body_AP07Jumpsuits_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP08BaggyPants_01"		{ source = "CharSkyNPC_Body_AP08BaggyPants_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_YoungFemaleRig"		{ source = "CharSkyNPC_Body_YoungFemaleRig.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP09Yeti_01"        	{ source = "CharSkyNPC_Body_AP09Yeti_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_RobedLadyRig"			{ source = "CharSkyNPC_Body_RobedLadyRig.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_YoungChubbyRig"		{ source = "CharSkyNPC_Body_YoungChubbyRig.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP11Kid_01"			{ source = "CharSkyNPC_Body_AP11Kid_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP11KidSpirit_01"		{ source = "CharSkyNPC_Body_AP11KidSpirit_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP11Narcissist"		{ source = "CharSkyNPC_Body_AP11Narcissist.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_FatLaborDress"			{ source = "CharSkyNPC_Body_FatLaborDress.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP12YellowTunic_01"    { source = "CharSkyNPC_Body_AP12YellowTunic_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP12BlueTunic_01"      { source = "CharSkyNPC_Body_AP12BlueTunic_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP12GradientTunic_01"  { source = "CharSkyNPC_Body_AP12GradientTunic_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP12DarkTunic_01"      { source = "CharSkyNPC_Body_AP12DarkTunic_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP13Tunic_01"        	{ source = "CharSkyNPC_Body_AP13Tunic_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP14ShadowPants_01"    { source = "CharSkyNPC_Body_AP14ShadowPants_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP14DancerSkirt_01"    { source = "CharSkyNPC_Body_AP14DancerSkirt_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP14JesterPants_01"    { source = "CharSkyNPC_Body_AP14JesterPants_01.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP16WhiteCropTop"		{ source = "CharSkyNPC_Body_AP16WhiteCropTop.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP16BlueSeed"			{ source = "CharSkyNPC_Body_AP16BlueSeed.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = false, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP16SlateRunaway"		{ source = "CharSkyNPC_Body_AP16SlateRunaway.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = false, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP16GreenCure"			{ source = "CharSkyNPC_Body_AP16GreenCure.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = false, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP16OrangeLove"		{ source = "CharSkyNPC_Body_AP16OrangeLove.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = false, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP17Apron"				{ source = "CharSkyNPC_Body_AP17Apron.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = false, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP17Injured"			{ source = "CharSkyNPC_Body_AP17Injured.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = false, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP18LightRobe"			{ source = "CharSkyNPC_Body_AP18LightRobe.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = false, compresfsUvs = true, stripNormals = true, loadLazy = true }
--resource "Mesh" "CharSkyNPC_Body_AP18DarkRobe"		{ source = "CharSkyNPC_Body_AP18LDarkRobe.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = false, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_AP19MonkRobe"			{ source = "CharSkyNPC_Body_AP19MonkRobe.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = false, compresfsUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Wing_Director"				{ source = "CharSkyNPC_Wing_Director.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "NPC_AP21KingCloak"						{ source = "NPC_AP21KingCloak.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Body_Moonlight"				{ source = "CharSkyNPC_Body_Moonlight.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = false, compresfsUvs = true, stripNormals = true, loadLazy = true }

-- Hair
resource "Mesh" "CharSkyNPC_Hair_FatLaborBun"				{ source = "CharSkyNPC_Hair_FatLaborBun.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyNPC_Hair_SkinnyIntellectualCrown"	{ source = "CharSkyNPC_Hair_SkinnyIntellectualCrown.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyNPC_Horn_SkinnyIntellectualCrown"	{ source = "CharSkyNPC_Horn_SkinnyIntellectualCrown.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyNPC_Horn_FatLaborChains"			{ source = "CharSkyNPC_Horn_FatLaborChains.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Horn_MCivilianChains"			{ source = "CharSkyNPC_Horn_MCivilianChains.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Horn_FatLaborChains_02"			{ source = "CharSkyNPC_Horn_FatLaborChains_02.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Horn_SkinnyIntellectualChains"	{ source = "CharSkyNPC_Horn_SkinnyIntellectualChains.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Horn_StrongLaborChains"			{ source = "CharSkyNPC_Horn_StrongLaborChains.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }


-- Mask
resource "Mesh" "CharSkyKid_Mask_NPC"					{ source = "CharSkyKid_Mask_NPC.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyNPC_Mask_KnightHelmet"			{ source = "CharSkyNPC_Mask_KnightHelmet.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "CharSkyNPC_Mask_FatLaborMask"			{ source = "CharSkyNPC_Mask_FatLaborMask.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }

-- Prop
resource "Mesh" "CharSkyNPC_Prop_Book"					{ source = "CharSkyNPC_Prop_Book.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Prop_Booze"					{ source = "CharSkyNPC_Prop_Booze.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Prop_ButterflyNet"			{ source = "CharSkyNPC_Prop_ButterflyNet.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Prop_Clipboard"				{ source = "CharSkyNPC_Prop_Clipboard.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Prop_FireStick"				{ source = "CharSkyNPC_Prop_FireStick.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Prop_Flag"					{ source = "CharSkyNPC_Prop_Flag.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Prop_Horn"					{ source = "CharSkyNPC_Prop_Horn.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Prop_Jar"					{ source = "CharSkyNPC_Prop_Jar.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, registerCollision = true }
resource "Mesh" "CharSkyNPC_Prop_Oar"					{ source = "CharSkyNPC_Prop_Oar.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Prop_PickAxe"				{ source = "CharSkyNPC_Prop_PickAxe.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Prop_PowerGlove"			{ source = "CharSkyNPC_Prop_PowerGlove.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Prop_Shield"				{ source = "CharSkyNPC_Prop_Shield.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Prop_Spear"					{ source = "CharSkyNPC_Prop_Spear.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "CharSkyNPC_Prop_Sword"					{ source = "CharSkyNPC_Prop_Sword.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = false, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

-- Event Meshes
resource "Mesh" "UnitDisc"							{ source = "UnitDisc.fbx", registerCollision = true }
resource "Mesh" "UnitCube"							{ source = "UnitCube.fbx", registerCollision = true, computeOcclusions = true }
resource "Mesh" "UnitCylinder"						{ source = "UnitCylinder.fbx", computeOcclusions = true }
resource "Mesh" "UnitPlane"							{ source = "UnitPlane.fbx", computeOcclusions = true }
resource "Mesh" "SpUnitBall"						{ source = "SpUnitBall.fbx", computeOcclusions = true }
resource "Mesh" "UnitSphereFlipped"					{ source = "UnitSphereFlipped.fbx", loadAsync = false, registerCollision = false, computeOcclusions = false }

resource "Mesh" "FxFlameRingBase"					{ source = "FxFlameRingBase.fbx", loadAsync = false, registerCollision = false } -- Gift Aura
resource "Mesh" "SecretObject_Persistent"			{ source = "SecretObject_01.fbx" } -- Mario Star
resource "Mesh" "CharFlyBeingMiniAAnim"				{ source = "CharFlyBeingMiniAAnim.fbx" } -- Butterfly

resource "Mesh" "SpTableA"							{ source = "SpTableA.fbx", loadAsync = false, registerCollision = true } -- Picnic Table
resource "Mesh" "SpChairA"							{ source = "SpChairA.fbx", loadAsync = false, registerCollision = true } -- Picnic Chair

resource "Mesh" "SpTableXmas"						{ source = "SpTableXmas.fbx", loadAsync = false, registerCollision = true } -- Picnic Table
resource "Mesh" "SpChairXmas"						{ source = "SpChairXmas.fbx", loadAsync = false, registerCollision = true } -- Picnic Chair

resource "Mesh" "Prop_SequencerLight_01"			{ source = "Prop_SequencerLight_01.fbx", loadAsync = false, registerCollision = false } -- Sequencer Seats
resource "Mesh" "Prop_SequencerLight_02"			{ source = "Prop_SequencerLight_02.fbx", loadAsync = false, registerCollision = false } -- Sequencer Seats
resource "Mesh" "Prop_SequencerLight_03"			{ source = "Prop_SequencerLight_03.fbx", loadAsync = false, registerCollision = false } -- Sequencer Seats
resource "Mesh" "Prop_SequencerLight_04"			{ source = "Prop_SequencerLight_04.fbx", loadAsync = false, registerCollision = false } -- Sequencer Seats

resource "Mesh" "Prop_SequencerLightAnni_01"		{ source = "Prop_SequencerLightAnni_01.fbx", loadAsync = false, registerCollision = false } -- Sequencer Seats
resource "Mesh" "Prop_SequencerLightAnni_02"		{ source = "Prop_SequencerLightAnni_02.fbx", loadAsync = false, registerCollision = false } -- Sequencer Seats
resource "Mesh" "Prop_SequencerLightAnni_03"		{ source = "Prop_SequencerLightAnni_03.fbx", loadAsync = false, registerCollision = false } -- Sequencer Seats
resource "Mesh" "Prop_SequencerLightAnni_04"		{ source = "Prop_SequencerLightAnni_04.fbx", loadAsync = false, registerCollision = false } -- Sequencer Seats

resource "Mesh" "Prop_SequencerStation"				{ source = "CharSkyKid_Prop_SequencerStation.fbx", loadAsync = false, registerCollision = true } -- Sequencer Table Harmony
resource "Mesh" "Prop_SequencerAnni"				{ source = "CharSkyKid_Prop_SequencerAnni.fbx", loadAsync = false, registerCollision = true } -- Sequencer Table Anniversary

resource "Mesh" "Prop_BigMantaPlush"				{ source = "Prop_BigMantaPlush.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true, copyFrameDelay = true }

resource "Mesh" "Bonfire"							{ source = "CharSkyKid_Prop_AP04Bonfire_01.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "BonfireSeat"						{ source = "CharSkyKid_Prop_AP04BonfireSeat_01.fbx", loadAsync = false, registerCollision = true }

resource "Mesh" "Swing"								{ source = "SpSwingSetFrame.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "SpSwingSetSeatAnim"				{ source = "SpSwingSetSeatAnim.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "SeesawAnim"						{ source = "SeesawAnim.fbx", loadAsync = false, registerCollision = true }


resource "Mesh" "RainbowSpell"						{ source = "RainbowSpell.fbx", loadAsync = false, registerCollision = true }

resource "Mesh" "DOSLightBoat_01"            		{ source = "DOSLightBoat_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "MessageLantern"            		{ source = "MessageLantern.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "AnniversaryBoat"                   { source = "AnniversaryBoat.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "MessageLotus"            			{ source = "MessageLotus.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "MessageGondola"            		{ source = "MessageGondola.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "MessageCranePersistent"            { source = "MessageCrane.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "FortuneLanternPersistent"          { source = "FortuneLantern.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "SpringFestivalDragon_Decoration"   { source = "SpringFestivalDragon_Decoration.fbx",  loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "MessageCairn"            			{ source = "MessageStoneCairn01.fbx", loadAsync = false, registerCollision = false }

resource "Mesh" "Firecracker"            			{ source = "Firecracker.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Firecracker_big"            		{ source = "Firecracker_big.fbx", loadAsync = false, registerCollision = false }

resource "Mesh" "WingBuffChild_05"					{ source = "WingBuffChild_05.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "CShrineCivilian_01"				{ source = "CShrineCivilian_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "MiniAncestorStatue_01_Persistent"	{ source = "MiniAncestorStatue_01.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "FriendshipStatue_01_Persistent"	{ source = "FriendshipStatue_01.fbx", loadAsync = false, registerCollision = true }

resource "Mesh" "Prop_TeaSet"						{ source = "Prop_TeaSet.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "Prop_TeaSet_Cup"					{ source = "Prop_TeaSet_Cup.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_TeaSet_Tea"					{ source = "Prop_TeaSet_Tea.fbx", loadAsync = false, registerCollision = false }

resource "Mesh" "Prop_MusicShell"					{ source = "Prop_MusicShell.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_ShellMusicBox"				{ source = "Prop_ShellMusicBox.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_MusicShellOffice"				{ source = "Prop_MusicShellOffice.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_PicnicBlanket"				{ source = "Prop_PicnicBlanket.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "Prop_PicnicBlanketFood"			{ source = "Prop_PicnicBlanketFood.fbx", loadAsync = false, registerCollision = true }

resource "Mesh" "Archway_DoL_01"					{ source = "Archway_DoL_01.fbx", loadAsync = false, computeOcclusions = true, registerCollision = false }

resource "Mesh" "Prop_ButterflyFountain"			{ source = "Prop_ButterflyFountain.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_ButterflyFountain_Lights"		{ source = "Prop_ButterflyFountain_Lights.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_ButterflyFountain_Petals"		{ source = "Prop_ButterflyFountain_Petals.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }

resource "Mesh" "CharSkyKid_Prop_ButterflyFountain"	{ source = "CharSkyKid_Prop_ButterflyFountain.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }

resource "Mesh" "Prop_WisteriaTea_01"				{ source = "Prop_WisteriaTea_01.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "Prop_WisteriaTea_Cup_01"			{ source = "Prop_WisteriaTea_Cup_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_WisteriaTea_Saucer_01"		{ source = "Prop_WisteriaTea_Saucer_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_WisteriaTea_Food_01"			{ source = "Prop_WisteriaTea_Food_01.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_WisteriaTea_Tea_01"			{ source = "Prop_WisteriaTea_Tea_01.fbx", loadAsync = false, registerCollision = false }

resource "Mesh" "Prop_Pinwheel"						{ source = "Prop_Pinwheel.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_Pinwheel_Handle"				{ source = "Prop_Pinwheel_Handle.fbx", loadAsync = false, registerCollision = false }

resource "Mesh" "Prop_BirthdayHat"					{ source = "Hat_BirthdayHat_01.fbx", loadAsync = false, registerCollision = false  }
resource "Mesh" "Prop_Rose"							{ source = "Prop_Rose.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "MessageRose"						{ source = "MessageRose.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_RoseGlass"					{ source = "Prop_RoseGlass.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_RoseJar"						{ source = "Prop_RoseJar.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_StarLamp"						{ source = "CharSkyKid_Prop_AP11Star_01.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_SnowGlobe"					{ source = "Prop_SnowGlobe_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_SnowGlobeFlake"				{ source = "Prop_SnowGlobeFlake_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_SnowGlobeGlass"				{ source = "Prop_SnowGlobeGlass_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_MuralElement"					{ source = "DecalStar_02.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }

resource "Mesh" "Prop_BirthdayCakeS"				{ source = "PropBirthdayCakeS.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_BirthdayCakeM"				{ source = "PropBirthdayCakeM.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_BirthdayCakeL"				{ source = "PropBirthdayCakeL.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_BirthdayFlags"				{ source = "PropBirthdayFlags.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_BirthdayFlagPoles"			{ source = "PropBirthdayFlagPoles.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_BeachBall"					{ source = "SummerBeachBall.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_SnowBall"						{ source = "Snowball_02.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_BeachRecliner"				{ source = "Prop_BeachRecliner.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_BeachChairWood"				{ source = "Prop_BeachChairWood.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_BeachChairCloth"				{ source = "Prop_BeachChairCloth.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Brazier2"						{ source = "Prop_Brazier2.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Brazier3"						{ source = "StoneBrazier_01.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Spell"						{ source = "SphereCheap_01.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_Pipe"							{ source = "Prop_Pipe.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_PipeMotif"					{ source = "Prop_PipeMotif.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_MischiefChair"				{ source = "Prop_MischiefChair.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_MischiefTable"				{ source = "Prop_MischiefTable.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "Prop_MischiefPumpkin"				{ source = "Prop_MischiefPumpkin.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Gondola_01"					{ source = "Prop_Gondola_01.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "Prop_Marshmallow_01"      			{ source = "Prop_Marshmallow_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Prop_Tent_01"      			    { source = "Prop_Tent_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "FeastBall"      					{ source = "FeastBall.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "FeastBallGateBlue"      			{ source = "FeastBallGateBlue.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "FeastBallWoodRed"      			{ source = "FeastBallWoodRed.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "FeastBallWoodBlue"      			{ source = "FeastBallWoodBlue.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "FeastBallScore_01"      			{ source = "FeastBallScore_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "FeastBallScore_02"      			{ source = "FeastBallScore_02.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "FeastBallScore_03"      			{ source = "FeastBallScore_03.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "FeastBallScore_04"      			{ source = "FeastBallScore_04.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Feast_RacingArch"      			{ source = "Feast_RacingArch.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Feast_RacingStart"      			{ source = "Feast_RacingStart.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Feast_RacingFinish"      			{ source = "Feast_RacingFinish.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Feast_RacingFinishFlag"      		{ source = "Feast_RacingFinishFlag.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Feast_RacingRibbon"      			{ source = "Feast_RacingRibbon.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_SunlightBoard"                { source = "Prop_SunlightBoard.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_Snowboard"             		{ source = "Prop_Snowboard.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_CompanionCube"				{ source = "Prop_CompanionCube.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "DOCBoostArrow"                     { source = "DOCBoostArrow.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }

resource "Mesh" "ConstellationAchievementFriendsMadeCenter"     { source = "ConstellationAchievementFriendsMadeCenter.fbx", loadAsync = false, registerCollision = false, loadLazy = true }
resource "Mesh" "ConstellationAchievementBoatCenter"      		{ source = "ConstellationAchievementBoatCenter.fbx", loadAsync = false, registerCollision = false, loadLazy = true }
resource "Mesh" "ConstellationAchievementFlameTouchedCenter"    { source = "ConstellationAchievementFlameTouchedCenter.fbx", loadAsync = false, registerCollision = false, loadLazy = true }
resource "Mesh" "ConstellationAchievementHeartCenter"      		{ source = "ConstellationAchievementHeartCenter.fbx", loadAsync = false, registerCollision = false, loadLazy = true }
resource "Mesh" "ConstellationAchievementHugsCenter"      		{ source = "ConstellationAchievementHugsCenter.fbx", loadAsync = false, registerCollision = false, loadLazy = true }
resource "Mesh" "ConstellationAchievementCrabCenter"      		{ source = "ConstellationAchievementCrabCenter.fbx", loadAsync = false, registerCollision = false, loadLazy = true }
resource "Mesh" "ConstellationAchievementJellyfishCenter"      	{ source = "ConstellationAchievementJellyfishCenter.fbx", loadAsync = false, registerCollision = false, loadLazy = true }
resource "Mesh" "JellyFishPose_03"      						{ source = "JellyFishPose_03.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "Crab_03"      									{ source = "Crab_03.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "CrabCenter_03"      							{ source = "CrabCenter_03.fbx", loadAsync = false, registerCollision = false, loadLazy = true }
resource "Mesh" "MantaA_Rotated"      							{ source = "MantaA_Rotated.fbx", loadAsync = false, registerCollision = false, loadLazy = true }
resource "Mesh" "Prop_AP16Symbol"      							{ source = "Prop_AP16Symbol.fbx", loadAsync = false, registerCollision = false, loadLazy = true }
resource "Mesh" "DarkDragonSideMesh"      						{ source = "Krill_Firework_01.fbx", loadAsync = false, registerCollision = false, loadLazy = true }

-- Camping Event Meshes
resource "Mesh" "PropScreenRed"						{ source = "PropScreenRed.fbx", loadAsync = false, registerCollision = true, loadLazy = true }
resource "Mesh" "PropScreenYellow"					{ source = "PropScreenYellow.fbx", loadAsync = false, registerCollision = true, loadLazy = true }
resource "Mesh" "PropScreenBlue"					{ source = "PropScreenBlue.fbx", loadAsync = false, registerCollision = true, loadLazy = true }
resource "Mesh" "PropScreenGreen"					{ source = "PropScreenGreen.fbx", loadAsync = false, registerCollision = true, loadLazy = true }
resource "Mesh" "PropCeilingYellow"                 { source = "PropCeilingYellow.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true}
resource "Mesh" "PropCurtainDoorYellow"             { source = "PropCurtainDoorYellow.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true}
resource "Mesh" "PropWindowYellow"                  { source = "PropWindowYellow.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true}
resource "Mesh" "SummerLemonadeStand02"				{ source = "SummerLemonadeStand02.fbx", loadAsync = false, registerCollision = true, loadLazy = true }
resource "Mesh" "SummerLemonadeGlass02"				{ source = "SummerLemonadeGlass02.fbx", loadAsync = false, registerCollision = true, loadLazy = true }
resource "Mesh" "LargeBonfireStone"					{ source = "LargeBonfireStones.fbx", loadAsync = false, registerCollision = true, loadLazy = true }
resource "Mesh" "LargeBonfireWood"					{ source = "LargeBonfireWood.fbx", loadAsync = false, registerCollision = true, loadLazy = true }
resource "Mesh" "Bloom_Sapling"						{ source = "Bloom_Sapling.fbx", loadAsync = false, registerCollision = false, loadLazy = true }
-- resource "Mesh" "Bloom_Tree"						{ source = "Bloom_Tree.fbx", loadAsync = false, registerCollision = false, loadLazy = true }

-- Constellation Progress Mesh (Constellation Gate)
resource "Mesh" "ConstellationDawn_01"				{ source = "ConstellationDawn_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "ConstellationDay_01"				{ source = "ConstellationDay_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "ConstellationRain_01"				{ source = "ConstellationRain_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "ConstellationSunset_01"			{ source = "ConstellationSunset_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "ConstellationDusk_01"				{ source = "ConstellationDusk_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "ConstellationNight_01"				{ source = "ConstellationNight_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "ConstellationStorm_01"				{ source = "ConstellationStorm_01.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "ConstellationWingBuff_01"			{ source = "ConstellationWingBuff_01.fbx", loadAsync = false, registerCollision = false }

-- AP Constellation Progress Mesh (Constellation Gate)
resource "Mesh" "ConstellationAP"					{ source = "ConstellationAP_06.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "ConstellationAP02"					{ source = "ConstellationAP_02.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "ConstellationAP03"					{ source = "ConstellationAP_03.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "ConstellationAP04"					{ source = "ConstellationAP_04.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "ConstellationAP06"					{ source = "ConstellationAP_06.fbx", loadAsync = false, registerCollision = false }

resource "Mesh" "ConstellationGateMesh"				{ source = "ForceFieldUnit.fbx", loadAsync = false, registerCollision = true }

resource "Mesh" "DarkstoneGib"						{ source = "DarkstoneGib.fbx", loadAsync = false, registerCollision = false }

-- Procedurally-generated darkstone crystals
resource "Mesh" "DarkstoneMeteorSpiked01"			{ source = "DarkStoneMeteorSpiked_01Persistent.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "DarkStoneGroundRubble01"			{ source = "DarkStoneGroundRubble_01Persistent.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "DarkStoneCrystal03"				{ source = "DarkStoneCrystal_03.fbx", loadAsync = false, registerCollision = true }

resource "Mesh" "DarkStoneMeteor04"					{ source = "DarkStoneMeteor_04Persistent.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "DarkStoneMeteorDestroyed01"		{ source = "DarkStoneMeteorDestroyed_01Persistent.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "DarkStoneMeteorInner01"			{ source = "DarkStoneMeteorInner_01Persistent.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "DarkStoneMeteor05"					{ source = "DarkStoneMeteor_05Persistent.fbx", loadAsync = false, registerCollision = true }

resource "Mesh" "FlyingRockA"						{ source = "SpRockA_Persistent.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "FlyingRockB"						{ source = "SpRockB_Persistent.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "FlyingRockC"						{ source = "SpRockC_Persistent.fbx", loadAsync = false, registerCollision = false }

-- Procedurally-generated darkstone plants
resource "Mesh" "DarkshroomPlantA01"				{ source = "Darkshroom_PlantA_01.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "DarkshroomSporeA01lo"				{ source = "Darkshroom_SporeA_01_lo.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "DarkshroomPlantASpore01"			{ source = "Darkshroom_PlantA_Spore_01.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "Darkseed"							{ source = "Darkseed_01.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "DarkshroomLilyPad02"				{ source = "Darkshroom_LilyPad_02.fbx", registerCollision = true }
resource "Mesh" "DarkshroomRadiantSpore01"			{ source = "Darkshroom_SporeA_01_lo_Radiance.fbx", registerCollision = true }
resource "Mesh" "DarkshroomRadiantSporeLarge"		{ source = "Darkshroom_SporeA_01_Large_Radiance.fbx", registerCollision = true }

resource "Mesh" "DarkStoneRainDrop"					{ source = "DarkStoneRainDrop.fbx", loadAsync = false, registerCollision = false }
resource "Mesh" "StupaBellCham"						{ source = "StupaBellCham.fbx", loadAsync = false, registerCollision = false }

resource "Mesh" "PropChestAnim"						{ source = "PropChestAnim.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "PropLoot"							{ source = "Prop_APLootBox_01.fbx", loadAsync = false }

resource "Mesh" "PremiumCandleShaft"				{ source = "PremiumCandleShaft.fbx", loadAsync = false, registerCollision = false } -- Gift Light Shaft
resource "Mesh" "GodLightItem"						{ source = "GodLightItem.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false } -- Collectible drop beam
resource "Mesh" "GodLight3b"						{ source = "GodLight3b.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false } -- Collectible drop beam
resource "Mesh" "GodLightNetease"               	{ source = "GodLightNetease.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false }

-- Crab
resource "Mesh" "CharCrabBAnimPersistent"			{ source = "CharCrabBAnim.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }
resource "Mesh" "CrabRock_01Persistent"				{ source = "CrabRock_01.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }

-- Lurker
resource "Mesh" "LurkerHeadPersistent"				{ source = "Lurker_Head.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }
resource "Mesh" "LurkerWhiskerPersistent"			{ source = "Lurker_Antennae.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }
resource "Mesh" "LurkerMandiblePersistent"			{ source = "Lurker_Grasper.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }
resource "Mesh" "LurkerMandibleBPersistent"			{ source = "Lurker_GrasperReversed.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }
resource "Mesh" "LurkerBodyPersistent"				{ source = "Lurker_Body01.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }
resource "Mesh" "LurkerBody2Persistent"				{ source = "Lurker_Body02.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }
resource "Mesh" "LurkerSpikePersistent"				{ source = "Lurker_Spike.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }
resource "Mesh" "LurkerTailPersistent"				{ source = "Lurker_Tail.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }

-- Light shroom
resource "Mesh" "CharEnvMushroomPersistent"			{ source = "CharEnvMushroom.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = true }

-- Season Meditation Shrine
resource "Mesh" "PropSpiritBackpackPersistent"		{ source = "PropSpiritBackpack.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = true }
resource "Mesh" "PropAPShrineTop"					{ source = "PropAP02ShrineTop.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = true }
resource "Mesh" "PropAP10ShrineTop"					{ source = "PropAP10ShrineTop.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = true }
resource "Mesh" "MemoryShrine"						{ source = "MemoryShrine.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = true }
resource "Mesh" "MapShrine_01"						{ source = "MapShrine_01.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = true }
resource "Mesh" "MapShrine_02"						{ source = "MapShrine_02.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = true }
resource "Mesh" "MapShrineSymbol"					{ source = "MapShrineSymbol.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }
resource "Mesh" "SharedShrine"						{ source = "DiamondStone.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = true }
resource "Mesh" "SharedLantern"						{ source = "SharedLantern.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = true }
resource "Mesh" "MemoryLantern"						{ source = "MemoryLantern.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = true }

-- Creature quest husk
resource "Mesh" "CShrineManta_01_Persistent"		{ source = "CShrineManta_01.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }
resource "Mesh" "CharSkyRayCAnim_Persistent" 		{ source = "CharSkyRayCAnim.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }
resource "Mesh" "CharEnvJellyfishAnim_Persistent" 	{ source = "CharEnvJellyfishAnim.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }

-- Core meshes
resource "Mesh" "ElderMaskB"						{ source = "ElderMaskB.fbx", registerCollision = false }

-- Storm void mesh
resource "Mesh" "StormEndStarBroken_02Anim"			{ source = "StormEndStarBroken_02Anim.fbx", loadAsync = false, computeOcclusions = true, computeEdges = false, registerCollision = false }

-- UI Tutorial Hand
resource "Mesh" "HandyAnim"							{ source = "HandyAnim.fbx", loadAsync = false, registerCollision = false }

-- Spirit ball mesh
resource "Mesh" "SpiritBall"						{ source = "Geosphere.fbx", registerCollision = false }

-- UI Constellation
resource "Mesh" "GUICylinder"						{ source = "UICylinder.fbx", registerCollision = false }

-- UI Social Feed
resource "Mesh" "UiMiscStarLarge_Mesh"				{ source = "UiMiscStarLarge_Mesh.fbx", registerCollision = false }
resource "Mesh" "UiMenuFriends_Mesh"				{ source = "UiMenuFriends_Mesh.fbx", registerCollision = false }
resource "Mesh" "UiSocialFeedSubscribe_Mesh"		{ source = "UiSocialFeedSubscribe_Mesh.fbx", registerCollision = false }

-- Placeable Props
resource "Mesh" "Prop_APFlagAnim_Persistent" 		{ source = "Prop_APFlagAnim_Persistent.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "NightBook_01_Persistent" 			{ source = "NightBook_01_Persistent.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "IslandUmbrella_01_Persistent" 		{ source = "IslandUmbrella_01.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Balloon_01_Persistent"        { source = "Prop_Balloon_01_Persistent.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_LightFence_Persistent"        { source = "Prop_LightFence_Persistent.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_Cannon_01_Persistent"         { source = "Prop_Cannon_01_Persistent.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "Prop_JarBubbleMachine"				{ source = "Prop_JarBubbleMachine.fbx", loadAsync = false, registerCollision = true }
resource "Mesh" "Prop_MarshmallowSet_01" 			{ source = "Prop_MarshmallowSet_01.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Snowman"						{ source = "Prop_Snowman.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_SnowCrab"						{ source = "Prop_SnowCrab.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_SnowHermit"					{ source = "Prop_SnowHermit.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_BreakedSnowman"				{ source = "Prop_BreakedSnowman.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_JarRound"						{ source = "CharSkyKid_Prop_JarRound.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Ladder"						{ source = "CharSkyKid_Prop_Ladder.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_LanternPost"					{ source = "CharSkyKid_Prop_LanternPost.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Brick"						{ source = "CharSkyKid_Prop_Brick.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_JarTall"						{ source = "CharSkyKid_Prop_JarTall.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Stool"						{ source = "CharSkyKid_Prop_Stool.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_MemoryBook"					{ source = "CharSkyKid_Prop_AP17UltimateMemoryBook.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_AP19Camera"					{ source = "Prop_Camera.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_AP19UltimateCamera"			{ source = "Prop_AP19Camera.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_HangingLights"				{ source = "Prop_HangingLights.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "Prop_Bucket"						{ source = "Prop_Bucket.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }

-- Stone Sets
resource "Mesh" "P_StoneStool"						{ source = "P_StoneStool.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneBenchSingle"				{ source = "P_StoneBenchSingle.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneBoxEmpty"					{ source = "P_StoneBoxEmpty.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneBoxClosed"					{ source = "P_StoneBoxClosed.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneLoveseat"					{ source = "P_StoneLoveseat.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneArmchair"					{ source = "P_StoneArmchair.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneDiningTableSquare"			{ source = "P_StoneDiningTableSquare.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneDiningTableLong"			{ source = "P_StoneDiningTableLong.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneChair"						{ source = "P_StoneChair.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneTableSmall"					{ source = "P_StoneTableSmall.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneDesk"						{ source = "P_StoneDesk.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneBench"						{ source = "P_StoneBench.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneDiningTableRound"			{ source = "P_StoneDiningTableRound.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneWallPotRack"				{ source = "P_StoneWallPotRack.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StonePlantStand"					{ source = "P_StonePlantStand.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneKitchenCabinet"				{ source = "P_StoneKitchenCabinet.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneKitchenStove"				{ source = "P_StoneKitchenStove.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneKitchenDrawers"				{ source = "P_StoneKitchenDrawers.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneKitchenOven"				{ source = "P_StoneKitchenOven.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneWallMugRack"				{ source = "P_StoneWallMugRack.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneWallTowelRack"				{ source = "P_StoneWallTowelRack.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneDresserLong"				{ source = "P_StoneDresserLong.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneBathtubLarge"				{ source = "P_StoneBathtubLarge.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneBathtubLargeWater"			{ source = "P_StoneBathtubLargeWater.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneBathtubSmall"				{ source = "P_StoneBathtubSmall.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneBathtubSmallWater"			{ source = "P_StoneBathtubSmallWater.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneSink"						{ source = "P_StoneSink.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneSinkWater"					{ source = "P_StoneSinkWater.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneWallMirror"					{ source = "P_StoneWallMirror.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneSofaCorner"					{ source = "P_StoneSofaCorner.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneSofaSide"					{ source = "P_StoneSofaSide.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneDresserTall"				{ source = "P_StoneDresserTall.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneBedSingle"					{ source = "P_StoneBedSingle.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneCoffeeTable"				{ source = "P_StoneCoffeeTable.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneKitchenSink"				{ source = "P_StoneKitchenSink.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneKitchenSinkWater"			{ source = "P_StoneKitchenSinkWater.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneConsoleTable"				{ source = "P_StoneConsoleTable.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneMannequin"					{ source = "P_StoneMannequin.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneCubeWide"					{ source = "P_StoneCubeWide.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneCubeTall"					{ source = "P_StoneCubeTall.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneCubeSmall"					{ source = "P_StoneCubeSmall.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_DecorPillowB"					{ source = "P_DecorPillowB.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_DecorPillowA"					{ source = "P_DecorPillowA.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneCandleLight"				{ source = "P_StoneCandleLight.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneWallShelf"					{ source = "P_StoneWallShelf.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneCandleHolder"				{ source = "P_StoneCandleHolder.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_DecorFoldedCloth"				{ source = "P_DecorFoldedCloth.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_StoneWallSconce"					{ source = "P_StoneWallSconce.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }

-- Testing dupe
resource "Mesh" "P_StoneCoffeeTableNew"				{ source = "P_StoneCoffeeTableNew.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }

-- Rugs
resource "Mesh" "P_RugSmallClassic"					{ source = "P_RugSmallClassic.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_RugSmallSolid"					{ source = "P_RugSmallSolid.fbx", 			loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_RugSmallStripes"					{ source = "P_RugSmallStripes.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_RugSmallHalfCircle"				{ source = "P_RugSmallHalfCircle.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_RugMediumSolid"					{ source = "P_RugMediumSolid.fbx", 			loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_RugMediumStripes"				{ source = "P_RugMediumStripes.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_RugMediumDiamonds"				{ source = "P_RugMediumDiamonds.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_RugMediumArgyle"					{ source = "P_RugMediumArgyle.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_RugMediumCircle"					{ source = "P_RugMediumCircle.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_RugLargeSolid"					{ source = "P_RugLargeSolid.fbx", 			loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_RugLargeCircle"					{ source = "P_RugLargeCircle.fbx", 			loadAsync = false, registerCollision = true, computeOcclusions = true }

-- AP22 Wood Sets
resource "Mesh" "P_AP22BedSingle"					{ source = "P_AP22BedSingle.fbx", 			loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22Chair"						{ source = "P_AP22Chair.fbx", 				loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22DiningTable"					{ source = "P_AP22DiningTable.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22Loveseat"					{ source = "P_AP22Loveseat.fbx",	 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22PendantLight"				{ source = "P_AP22PendantLight.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22BathTub"						{ source = "P_AP22BathTub.fbx", 			loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22BathTubWater"				{ source = "P_AP22BathTubWater.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22StepStool"					{ source = "P_AP22StepStool.fbx", 			loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22HangingLight"				{ source = "P_AP22HangingLight.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22WallPaintingSet"				{ source = "P_AP22WallPaintingSet.fbx", 	loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22WallPainting"				{ source = "P_AP22WallPainting.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22WallSpiceRack"				{ source = "P_AP22WallSpiceRack.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22HangingPlanter"				{ source = "P_AP22HangingPlanter.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22Lamp"						{ source = "P_AP22Lamp.fbx", 				loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP22Figurine"					{ source = "P_AP22Figurine.fbx", 			loadAsync = false, registerCollision = true, computeOcclusions = true }

-- AP23
resource "Mesh" "P_AP23WallPosterDuet"				{ source = "P_AP23WallPosterDuet.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP23WallPosterPiano"				{ source = "P_AP23WallPosterPiano.fbx", 	loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP23WallPosterCello"				{ source = "P_AP23WallPosterCello.fbx", 	loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP23WallPosterConch"				{ source = "P_AP23WallPosterConch.fbx", 	loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP23WallPosterPianoKeys"			{ source = "P_AP23WallPosterPianoKeys.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP23Vanity"						{ source = "P_AP23Vanity.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP23ClothDivider"				{ source = "P_AP23ClothDivider.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP23Curtain"			        	{ source = "P_AP23Curtain.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP23HalfRug"			        	{ source = "P_AP23HalfRug.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP23Vase"				    	{ source = "P_AP23Vase.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP23DecorCup"					{ source = "P_AP23DecorCup.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP23Cup"					        { source = "P_AP23Cup.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP23Bench"						{ source = "P_AP23Bench.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }

-- AP24
resource "Mesh" "Prop_AP24EmoteBook"				{ source = "Prop_AP24EmoteBook.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP24Portrait"				{ source = "P_AP24Portrait.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP24WallPhotos_01"				{ source = "P_AP24WallPhotos_01.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP24WallPhotos_02"				{ source = "P_AP24WallPhotos_02.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP24Chandelier"				{ source = "P_AP24Chandelier.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP24Clock"				{ source = "P_AP24Clock.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "P_AP24ClockFace"				{ source = "P_AP24ClockFace.fbx", 		loadAsync = false, registerCollision = true, computeOcclusions = true }

-- AP25
resource "Mesh" "P_AP25ClothDivider"				{ source = "P_AP25ClothDivider.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }

-- AP26
resource "Mesh" "P_AP26TreePerch"				{ source = "P_AP26TreePerch.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }



-- Misc Furniture
resource "Mesh" "BubbleBeanBag"						{ source = "BeanBag_High.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }

-- Fish School
resource "Mesh" "Cone_01"							{ source = "Cone_01.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "FishH"								{ source = "FishH.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "BirdA"								{ source = "BirdA.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "CrabA"								{ source = "CrabA.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "MantaA"							{ source = "MantaA.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "ButterflyA"						{ source = "ButterflyA.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "JellyfishA"						{ source = "JellyfishA.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "SkyKidFlyingA"						{ source = "SkyKidFlyingA.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "SkyKidAbstractA"					{ source = "SkyKidAbstractA.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "NightMantaLite"					{ source = "NightMantaLite.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP18SerowAbstract"					{ source = "AP18SerowAbstract.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP18BoarAbstract"					{ source = "AP18BoarAbstract.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP18BearAbstract"					{ source = "AP18BearAbstract.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP18MonkeyAbstract"				{ source = "AP18MonkeyAbstract.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP18RaccoonAbstract"				{ source = "AP18RaccoonAbstract.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "BroomstickAbstract"				{ source = "BroomstickAbstract.fbx", registerCollision = false, loadLazy = true }

resource "Mesh" "DragonDanceHead_Black"				{ source = "DragonDanceHead_Black.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "DragonDanceHead_White"				{ source = "DragonDanceHead_White.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "DragonDanceBody_Black"				{ source = "DragonDanceBody_Black.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "DragonDanceBody_White"				{ source = "DragonDanceBody_White.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "DragonDanceTail_Black"				{ source = "DragonDanceTail_Black.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "DragonDanceTail_White"				{ source = "DragonDanceTail_White.fbx", registerCollision = false, loadLazy = true }

resource "Mesh" "Neck_SnakeGameTail"                { source = "SnakeGameTail.fbx", registerCollision = false, loadLazy = false }
resource "Mesh" "Neck_SnakeGameBody"                { source = "SnakeGameBody.fbx", registerCollision = false, loadLazy = false }

resource "Mesh" "BloomLilyPad_01"					{ source = "BloomLilyPad_01.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "BloomLilyStem_01"					{ source = "BloomLilyStem_01.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "BloomLilyStem_02"					{ source = "BloomLilyStem_02.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "BloomKelp_01"						{ source = "BloomKelp_01.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "BloomKelp_02"						{ source = "BloomKelp_02.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "BloomKelp_03"						{ source = "BloomKelp_03.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "BloomCallaBlossom_01"				{ source = "BloomCallaBlossom_01.fbx", registerCollision = false, loadLazy = true }

-- Season 24
resource "Mesh" "AP24Bush_01"						{ source = "AP24FoliageBush_01_Leaves.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Tree_01_Trunk"					{ source = "AP24FoliageTree_01_Trunk.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Tree_01_Canopy"				{ source = "AP24FoliageTree_01.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Tree_02_Trunk"					{ source = "AP24FoliageTree_02_Trunk.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Tree_02_Canopy"				{ source = "AP24FoliageTree_02.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Tree_03_Trunk"					{ source = "AP24FoliageTree_02_Trunk.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Tree_03_Canopy"				{ source = "AP24FoliageTree_02.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24PineTree_01_Trunk"				{ source = "AP24FoliagePineTree_01_Trunk.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24PineTree_01_Canopy"			{ source = "AP24FoliagePineTree_01.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24PineTree_02_Trunk"				{ source = "AP24FoliagePineTree_02_Trunk.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24PineTree_02_Canopy"			{ source = "AP24FoliagePineTree_02.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24PineTree_03_Trunk"				{ source = "AP24FoliagePineTree_02_Trunk.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24PineTree_03_Canopy"			{ source = "AP24FoliagePineTree_02.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Plant_01"						{ source = "AP24Plant_01.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Plant_02a"						{ source = "AP24Plant_02a.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Plant_02b"						{ source = "AP24Plant_02b.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Plant_02c"						{ source = "AP24Plant_02c.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Plant_03a"						{ source = "AP24Plant_03a.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Plant_03b"						{ source = "AP24Plant_03b.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Plant_03c"						{ source = "AP24Plant_03c.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "AP24Arms_01"						{ source = "AP24Arms_v03.fbx", registerCollision = false, loadLazy = true }

-- Days of Bloom 2025
resource "Mesh" "WildBushS_01"						{ source = "DoB_WildBush_S_01.fbx",		 registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushS_01_Rose"					{ source = "DoB_WildBushRose_S_01.fbx",	 registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushM_01"						{ source = "DoB_WildBush_M_01.fbx",		 registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushM_01_RoseA"				{ source = "DoB_WildBushRose_M_01a.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushM_01_RoseB"				{ source = "DoB_WildBushRose_M_01b.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushM_01_RoseC"				{ source = "DoB_WildBushRose_M_01c.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushL_01"						{ source = "DoB_WildBush_L_01.fbx",		 registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushL_01_RoseA"				{ source = "DoB_WildBushRose_L_01a.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushL_01_RoseB"				{ source = "DoB_WildBushRose_L_01b.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushL_01_RoseC"				{ source = "DoB_WildBushRose_L_01c.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushL_02"						{ source = "DoB_WildBush_L_02.fbx",		 registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushL_02_RoseA"				{ source = "DoB_WildBushRose_L_02a.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushL_02_RoseB"				{ source = "DoB_WildBushRose_L_02b.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "WildBushL_02_RoseC"				{ source = "DoB_WildBushRose_L_02c.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "DoB_FoliageRose_01"				{ source = "DoB_FoliageRose_01.fbx", registerCollision = false, loadLazy = true }
resource "Mesh" "RosePetal"				            { source = "RosePetal.fbx", registerCollision = false, loadLazy = true }

resource "Mesh" "DarkshroomLeaf01"					{ source = "Darkshroom_PlantB_01.fbx", registerCollision = false, loadLazy = true }

-- Season 27
resource "Mesh" "S27HouseLong_01"					{ source = "S27HouseLong_01.fbx",		 registerCollision = false, loadLazy = true }
resource "Mesh" "S27HouseLong_01a"					{ source = "S27HouseLong_01a.fbx",		 registerCollision = false, loadLazy = true }
resource "Mesh" "S27HouseLong_01b"					{ source = "S27HouseLong_01b.fbx",		 registerCollision = false, loadLazy = true }
resource "Mesh" "S27HouseSquare_01"					{ source = "S27HouseSquare_01.fbx",		 registerCollision = false, loadLazy = true }
resource "Mesh" "S27HouseLShape_01"					{ source = "S27HouseLShape_01.fbx",		 registerCollision = false, loadLazy = true }
resource "Mesh" "S27HouseLarge_01"					{ source = "S27HouseLarge_01.fbx",		 registerCollision = false, loadLazy = true }
resource "Mesh" "S27HouseLarge_01a"					{ source = "S27HouseLarge_01a.fbx",		 registerCollision = false, loadLazy = true }

resource "Mesh" "S27_MarketTent_01"					{ source = "S27_MarketTent_01.fbx",		 registerCollision = false, loadLazy = false }
resource "Mesh" "S27_MarketTent_02"					{ source = "S27_MarketTent_02.fbx",		 registerCollision = false, loadLazy = false }
resource "Mesh" "S27_CivilianTent_01"				{ source = "S27_CivilianTent_01.fbx",	registerCollision = false, loadLazy = false }
resource "Mesh" "S27_CivilianTent_02"				{ source = "S27_CivilianTent_02.fbx",	registerCollision = false, loadLazy = false }
resource "Mesh" "S27_CivilianTent_03"				{ source = "S27_CivilianTent_03.fbx",	registerCollision = false, loadLazy = false }
resource "Mesh" "S27_CivilianTent_04"				{ source = "S27_CivilianTent_04.fbx",	registerCollision = false, loadLazy = false }

-- Test Art Book
resource "Mesh" "CharSkyKid_Prop_SkyArtBook01_Closed"						{ source = "Prop_SkyArtBook01_Closed.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }
resource "Mesh" "CharSkyKid_Prop_SkyArtBook01_Open"						{ source = "Prop_SkyArtBook01_Open.fbx", loadAsync = false, registerCollision = true, computeOcclusions = true }

-- Instrument extras
resource "Mesh" "Prop_ViolinBow"							{ source = "Prop_ViolinBow.fbx", loadAsync = false, registerCollision = false }

-------------------------------------------------------------------------------
-- ANIMATION
-------------------------------------------------------------------------------

-- Make animation list
resource "CompiledAnimationList" "AnimationList" { noPack = true }

-- Avatar Animation
resource "AnimationPack" "CharKidAnimFlyState"				{}
resource "AnimationPack" "CharKidAnimAdd"					{ additive = true }
resource "AnimationPack" "CharKidAnimBlink"					{ additive = true }
resource "AnimationPack" "CharKidAnimGroundAct"				{}
resource "AnimationPack" "CharKidAnimFlyAct"				{}
resource "AnimationPack" "CharKidAnimSceneAct"				{}
resource "AnimationPack" "CharKidAnimSceneAct_A"			{}
resource "AnimationPack" "CharKidAnimEmote_B"				{}
resource "AnimationPack" "CharKidAnimEmote_D"				{}
resource "AnimationPack" "CharKidAnimEmote_E"				{}
resource "AnimationPack" "CharKidAnimEmote_F"				{}
resource "AnimationPack" "CharKidAnimEmote_G"				{}
resource "AnimationPack" "CharKidAnimEmote_H"				{}
resource "AnimationPack" "CharKidAnimWeakNav"				{}
resource "AnimationPack" "CineCharBirthDawn"					{}
resource "AnimationPack" "CineCharGongDawn"					{}
resource "AnimationPack" "CineCharStormWakeup"				{}
resource "AnimationPack" "CharKidAnimOrbitFlyAct"			{}
resource "AnimationPack" "CharSpiritAnimOrbit"				{}
resource "AnimationPack" "CharKidAnimProps"					{}
resource "AnimationPack" "CharKidAnimProps_B"				{}
resource "AnimationPack" "CharKidAnimProps_External"			{}
resource "AnimationPack" "CineDeathStormEndAvatar"			{}
resource "AnimationPack" "CineDeathStormEndAvatarApproach"	{}
resource "AnimationPack" "CineCandleSpaceEndAvatar"			{}
resource "AnimationPack" "CineAncestorRainAvatar"			{}
resource "AnimationPack" "CineAncestorDuskSkyKid"			{}
resource "AnimationPack" "CineAncestorNightSkyKid"			{}
resource "AnimationPack" "CineAncestorSunsetSkykid"			{}
resource "AnimationPack" "SpiritFatLaborEmotes"				{}
resource "AnimationPack" "SpiritKnightEmotes"				{}
resource "AnimationPack" "SpiritCivFEmotes"					{}
resource "AnimationPack" "SpiritCivMEmotes"					{}
resource "AnimationPack" "SpiritIntellectualEmotes"			{}

-- Skeletons
resource "AnimationPack" "CharSkyKid_Skeleton"				{}
resource "AnimationPack" "CharSkyNPC_Skeleton_Actor"		{}
resource "AnimationPack" "CharSkyNPC_Skeleton_Director"		{}
resource "AnimationPack" "CharSkyNPC_Skeleton_Dancer"		{}
resource "AnimationPack" "CharSkyNPC_Skeleton_Juggler"		{}
resource "AnimationPack" "CharSkyNPC_Skeleton_Musician"		{}
resource "AnimationPack" "CharSkyNPC_Skeleton_YoungFemale"	{}
resource "AnimationPack" "NPC_Skeleton_YoungFemale"			{}
resource "AnimationPack" "CharSkyNPC_Skeleton_RobedLady"	{}
resource "AnimationPack" "CharSkyNPC_Skeleton_AP24Classic"	{}
resource "AnimationPack" "CharSkyNPC_Skeleton_AP24Triangle"	{}
resource "AnimationPack" "CharSkyNPC_Skeleton_AP24Ears"		{}
resource "AnimationPack" "CharSkyNPC_Skeleton_AP24Stripes"	{}
resource "AnimationPack" "CharSkyNPC_Skeleton_AP24Onion"	{}
resource "AnimationPack" "CharSkyNPC_Skeleton_AP24Bell"		{}


-------------------------------------------------------------------------------
-- IMAGES
-------------------------------------------------------------------------------

-- Logos
resourceref "Image" "AWSLogoLight"
resourceref "Image" "FMODLogoLight"
resourceref "Image" "AMBERLogo"
resourceref "Image" "FacebookLogo"
resourceref "Image" "MirrativLogo"
resourceref "Image" "Funtap18plus"
resourceref "Image" "RolandTR909Logo"

-- Diffuse Textures
resourceref "Image" "CharRampAvatar"
resourceref "Image" "CharRampSpirit"

resourceref "Image" "CharRampMono"
resourceref "Image" "CharRampWarm"
resourceref "Image" "CharRampCool"

resourceref "Image" "CharRampS2"
resourceref "Image" "CharRampS3"
resourceref "Image" "CharRampS4"
resourceref "Image" "CharRampS6"
resourceref "Image" "CharRampS7"
resourceref "Image" "CharRampS8"
resourceref "Image" "CharRampS9"
resourceref "Image" "CharRampS10"
resourceref "Image" "CharRampS11"
resourceref "Image" "CharRampS12"
resourceref "Image" "CharRampS13"
resourceref "Image" "CharRampS14"
resourceref "Image" "CharRampS16"
resourceref "Image" "CharRampS16Aurora"
resourceref "Image" "CharRampAuroraNPC"
resourceref "Image" "CharRampAuroraNPC2"
resourceref "Image" "CharRampS16Misc"
resourceref "Image" "CharRampS17"
resourceref "Image" "CharRampS18"
resourceref "Image" "CharRampS19"
resourceref "Image" "CharRampS20"
resourceref "Image" "CharRampS21"
resourceref "Image" "CharRampS21Deer"
resourceref "Image" "CharRampS23"
resourceref "Image" "CharRampS24"
resourceref "Image" "CharRampS26"
resourceref "Image" "CharRampS27"

resourceref "Image" "CharRampCustom01"
resourceref "Image" "CharRampCustom02"


resourceref "Image" "CharRampAlpha1"
resourceref "Image" "CharRampAlpha2"
resourceref "Image" "CharRampEvents"
resourceref "Image" "CharRampEvents2"
resourceref "Image" "CharRampEvents3"
resourceref "Image" "CharRampRainbow"
resourceref "Image" "CharRampKizunaAi"
resourceref "Image" "CharRampXmas_Tex"
resourceref "Image" "CharRampXmas_Att"
resourceref "Image" "CharRampLNY"
resourceref "Image" "CharRampLNY1"
resourceref "Image" "CharRampLNY2"
resourceref "Image" "CharRampMisc1"
resourceref "Image" "CharRampCrabLace"
resourceref "Image" "CharRampStarJar"
resourceref "Image" "CharRampGray"

resourceref "Image" "SkyRayCTex"


resourceref "Image" "PropRampStoneTint"
resourceref "Image" "PropRampStoneGrey"
resourceref "Image" "PropRampStoneBlue"
resourceref "Image" "PropRampStoneOrange"
resourceref "Image" "PropRampStonePurple"

resourceref "Image" "PropRampWoodOrange"

resourceref "Image" "PropRampAntiqueTint"

resourceref "Image" "PropRampS25"

-- Attribute Textures
resourceref "Image" "Attrib_General"
resourceref "Image" "Attrib_GlowRamp"
resourceref "Image" "Attrib_GlossRamp"
resourceref "Image" "Attrib_Fabric"
resourceref "Image" "Attrib_Leather"
resourceref "Image" "Attrib_Scales"
resourceref "Image" "Attrib_CrabLace"
resourceref "Image" "Attrib_ScalesIridescent"
resourceref "Image" "Attrib_MetalBeaten"

resourceref "Image" "CharSkyKid_General_Att" -- replaced with AttribGeneral, remove when all assets have been updated

-- Masking Textures
resourceref "Image" "Mask_General"
resourceref "Image" "Mask_Wing"
resourceref "Image" "Mask_Ramp"

-- Fabric Pattern Textures
resourceref "Image" "Pattern_Checker"
resourceref "Image" "Pattern_Plaid"
resourceref "Image" "Pattern_Aloha"

-- Creature ramps
resourceref "Image" "CreatureRamp"
resourceref "Image" "GhostCreatureRamp"



resourceref "Image" "Noise2Ch"
resourceref "Image" "DeerSpotSDF"
resourceref "Image" "FeatherAlpha"

-- ENVIRONMENT --

resourceref "Image" "CreatureMotif"
resourceref "Image" "CloudThinTex"
resourceref "Image" "ThreeDee"
resourceref "Image" "ThreeDeeCauliflower"

resourceref "Image" "CloudFinTex"
resourceref "Image" "MetalBeatenSh"
resourceref "Image" "FabricSh"
resourceref "Image" "WoodBase"
resourceref "Image" "WoodBaseLight"
resourceref "Image" "WoodBaseSh"
resourceref "Image" "WoodPlankSh"
resourceref "Image" "Leaves"
resourceref "Image" "Petals"
resourceref "Image" "FoliageTintColor"

resourceref "Image" "ConstellationImageDawn"
resourceref "Image" "ConstellationImageDay"
resourceref "Image" "ConstellationImageRain"
resourceref "Image" "ConstellationImageSunset"
resourceref "Image" "ConstellationImageDusk"
resourceref "Image" "ConstellationImageNight"
resourceref "Image" "ConstellationImageStorm"
resourceref "Image" "ConstellationImageFriendButterflies"
resourceref "Image" "ConstellationImageFriendCrab"
resourceref "Image" "ConstellationImageFriendCrown"
resourceref "Image" "ConstellationImageFriendDrum"
resourceref "Image" "ConstellationImageFriendManta"
resourceref "Image" "ConstellationImageFriendUmbrella"
resourceref "Image" "ConstellationImageFriendKids"
resourceref "Image" "ConstellationImageFriendHarp"
resourceref "Image" "ConstellationImageFriendMonument"
resourceref "Image" "ConstellationImageFriendJellyfish"
resourceref "Image" "ConstellationImageAP"
resourceref "Image" "ConstellationImageAP02"
resourceref "Image" "ConstellationImageAP03"
resourceref "Image" "ConstellationImageAP04"
resourceref "Image" "ConstellationImageAP05"
resourceref "Image" "ConstellationImageAP06"
resourceref "Image" "ConstellationImageAP07"
resourceref "Image" "ConstellationImageAP08"
resourceref "Image" "ConstellationImageAP09"
resourceref "Image" "ConstellationImageAP10"
resourceref "Image" "ConstellationImageAP11"
resourceref "Image" "ConstellationImageAP12"
resourceref "Image" "ConstellationImageAP13"
resourceref "Image" "ConstellationImageAP14"
resourceref "Image" "ConstellationImageAP15"
resourceref "Image" "ConstellationImageAP16"
resourceref "Image" "ConstellationImageAP17"
resourceref "Image" "ConstellationImageAP18"
resourceref "Image" "ConstellationImageAP19"
resourceref "Image" "ConstellationImageAP21"
resourceref "Image" "ConstellationImageAP22"
resourceref "Image" "ConstellationImageAP23"
resourceref "Image" "ConstellationImageAP24"
resourceref "Image" "ConstellationImageAP25"
resourceref "Image" "ConstellationImageAP26"
resourceref "Image" "UIRing"
resourceref "Image" "UIRingBloom"
resourceref "Image" "UIRingBigThin"
resourceref "Image" "UIRingBigThinner"
resourceref "Image" "UIRingBigMedium"
resourceref "Image" "UIRingBigThick"
resourceref "Image" "UIBorderThin"
resourceref "Image" "UIBorderThinFill"
resourceref "Image" "UIStepHoop"
resourceref "Image" "ShoutRingBloom"
resourceref "Image" "UIArrowUp"
resourceref "Image" "UIEye"
resourceref "Image" "UIFingerSingle"
resourceref "Image" "UIFingerSingleShadow"
resourceref "Image" "UIFingerDouble"
resourceref "Image" "UIBar"
resourceref "Image" "UIFade"
resourceref "Image" "UIFadeLine"
resourceref "Image" "UISphereFade"
resourceref "Image" "UiButtonGlow"
resourceref "Image" "UiBorderGlowSoft"
resourceref "Image" "UiBorderGlowHard"
resourceref "Image" "UiBorderGlowThinSoft"
resourceref "Image" "UiBorderGlowThinHard"
resourceref "Image" "UiBorderGlowThickSoft"
resourceref "Image" "UiBorderGlowThickHard"
resourceref "Image" "UiRadialSliceGlowSoft"
resourceref "Image" "UiBubbleButtonBorder"
resourceref "Image" "UiButtonBorderThin"
resourceref "Image" "UiMenuTabHighlight"
resourceref "Image" "UiButtonToggledEdge"
resourceref "Image" "UiMenuGradientEdge"
resourceref "Image" "UiMenuGradientLinear"
resourceref "Image" "UiRadialCursorBg"
resourceref "Image" "UiMiscGradientNineSlice"
resourceref "Image" "UiMenuShadowLeft"
resourceref "Image" "UiMapTintOverlay"
resourceref "Image" "UiVignette"
resourceref "Image" "UiGradientShout_Quarter"
resourceref "Image" "UiMiscDropShadowCircle"
resourceref "Image" "UiMiscDropShadowCircleSmall"
resourceref "Image" "UiMaskCircleGlow"
resourceref "Image" "UiMiscHeartGlow"
resourceref "Image" "UiMiscTrustTierShadow"
resourceref "Image" "UiMapCloud_Tile"
resourceref "Image" "UiMapInkblot"
resourceref "Image" "UiAlbumAurora"
resourceref "Image" "DarkstoneNorTex"
resourceref "Image" "Wisteria"
resourceref "Image" "FlowerTex"

resourceref "Image" "Portal"
resource "ImageRegion" "PortalDawn"			{ image = "Portal", uv = { 0/3, 0/3, 1/3, 1/3 } }
resource "ImageRegion" "PortalDay"			{ image = "Portal", uv = { 1/3, 0/3, 2/3, 1/3 } }
resource "ImageRegion" "PortalRain"			{ image = "Portal", uv = { 2/3, 0/3, 3/3, 1/3 } }
resource "ImageRegion" "PortalSunset"		{ image = "Portal", uv = { 0/3, 1/3, 1/3, 2/3 } }
resource "ImageRegion" "PortalDusk"			{ image = "Portal", uv = { 1/3, 1/3, 2/3, 2/3 } }
resource "ImageRegion" "PortalNight"		{ image = "Portal", uv = { 2/3, 1/3, 3/3, 2/3 } }
resource "ImageRegion" "PortalStorm"		{ image = "Portal", uv = { 0/3, 2/3, 1/3, 3/3 } }
resource "ImageRegion" "PortalAP"			{ image = "Portal", uv = { 1/3, 2/3, 2/3, 3/3 } }
resource "ImageRegion" "PortalPrairie"		{ image = "Portal", uv = { 2/3, 2/3, 3/3, 3/3 } }
resource "ImageRegion" "PortalCandleSpace"	{ image = "Portal", uv = { 2/3, 2/3, 3/3, 3/3 } }
resource "ImageRegion" "PortalWhite"		{ image = "Portal", uv = { 0.5, 0, 0.6, 0.1 } }

-- COLOR TEX -- Note : Red and OrangeL1 are in boot.lua for Candlespace release loading

resourceref "Image" "GreenGray"
resourceref "Image" "AncestorBlueD1"
resourceref "Image" "AncestorBlueL1"
resourceref "Image" "Magenta"
resourceref "Image" "MagentaD3"
resourceref "Image" "MagentaD2"
resourceref "Image" "MagentaD1"
resourceref "Image" "MagentaL3"
resourceref "Image" "MagentaL2"
resourceref "Image" "MagentaL1"
resourceref "Image" "OrangeD3"
resourceref "Image" "OrangeD2"
resourceref "Image" "OrangeD1"
resourceref "Image" "OrangeL3"
resourceref "Image" "PurpleD3"
resourceref "Image" "Yellow"
resourceref "Image" "YellowD3"
resourceref "Image" "YellowD1"
resourceref "Image" "YellowL3"
resourceref "Image" "YellowL2"
resourceref "Image" "YellowL1"
resourceref "Image" "Cyan"
resourceref "Image" "CyanD3"
resourceref "Image" "CyanD2"
resourceref "Image" "CyanD1"
resourceref "Image" "CyanL3"
resourceref "Image" "CyanL2"
resourceref "Image" "CyanL1"
resourceref "Image" "Lime"
resourceref "Image" "LimeD3"
resourceref "Image" "LimeD2"
resourceref "Image" "LimeD1"
resourceref "Image" "LimeL3"
resourceref "Image" "LimeL2"
resourceref "Image" "LimeL1"
resourceref "Image" "Blue"
resourceref "Image" "BlueD3"
resourceref "Image" "BlueD2"
resourceref "Image" "BlueD1"
resourceref "Image" "BlueL3"
resourceref "Image" "BlueL1"
resourceref "Image" "Brown"
resourceref "Image" "Green"
resourceref "Image" "GreenD3"
resourceref "Image" "GreenD2"
resourceref "Image" "GreenD1"
resourceref "Image" "GreenL3"
resourceref "Image" "GreenL2"
resourceref "Image" "GreenL1"
resourceref "Image" "RedD5"
resourceref "Image" "RedD4"
resourceref "Image" "RedD2"
resourceref "Image" "RedD1"
resourceref "Image" "RedL3"
resourceref "Image" "RedL1"
resourceref "Image" "GrayD2"
resourceref "Image" "GrayL1"

resourceref "Image" "PaintBlue"
resourceref "Image" "PaintBlueL1"
resourceref "Image" "PaintBlueL2"
resourceref "Image" "PaintBlueL3"
resourceref "Image" "PaintBlueD1"
resourceref "Image" "PaintBlueD2"
resourceref "Image" "PaintBlueD3"
resourceref "Image" "StoneBlue"
resourceref "Image" "StoneBlueL2"
resourceref "Image" "StoneBlueL3"
resourceref "Image" "StoneBlueD1"
resourceref "Image" "StoneBlueD2"

resourceref "Image" "ColElementWater"
resourceref "Image" "ColElementEarth"
resourceref "Image" "ColElementAir"
resourceref "Image" "ColElementFire"

resourceref "Image" "ElementWater"
resourceref "Image" "ElementEarth"
resourceref "Image" "ElementAir"
resourceref "Image" "ElementFire"
resourceref "Image" "ElementVoid"
resourceref "Image" "ElementMind"

resourceref "Image" "RainbowBelt"
resourceref "Image" "RainbowBeltStraight"

-- UI COLOR TEX --

resourceref "Image" "UiOrangeL3"
resourceref "Image" "UiGrayL1"

-- PARTICLES --

resourceref "Image" "ParticleAtlas"
resourceref "Image" "ParticleAtlas02"
resourceref "Image" "AudienceEmotesAtlas"

-- format is { lower left u, lower left v, upper right u, upper right v }
-- 1st row, left to right
resource "ImageRegion" "crl1"	{ image = "ParticleAtlas02", uv = { 0, 0, 2/8, 2/8 } }
resource "ImageRegion" "crl2"	{ image = "ParticleAtlas02", uv = { 2/8, 0, 4/8, 2/8 } }
resource "ImageRegion" "dot1"	{ image = "ParticleAtlas02", uv = { 4/8, 0, .75, 2/8 } }
resource "ImageRegion" "dot2"	{ image = "ParticleAtlas02", uv = { 6/8, 0, 1, 2/8 } }
-- 2nd row, left to right
resource "ImageRegion" "sqr1"	{ image = "ParticleAtlas02", uv = { 0, 2/8, 2/8, 4/8 } }
resource "ImageRegion" "sqr2"	{ image = "ParticleAtlas02", uv = { 2/8, 2/8, 4/8, 4/8 } }
resource "ImageRegion" "dmd1"	{ image = "ParticleAtlas02", uv = { 4/8, 2/8, .75, 4/8 } }
resource "ImageRegion" "tri1"	{ image = "ParticleAtlas02", uv = { 6/8, 2/8, 1, 4/8 } }
-- 3rd row, left to right
resource "ImageRegion" "dst1"	{ image = "ParticleAtlas02", uv = { 0, 4/8, 2/8, 6/8 } }
resource "ImageRegion" "dst2"	{ image = "ParticleAtlas02", uv = { 2/8, 4/8, 4/8, 6/8 } }
resource "ImageRegion" "cld1"	{ image = "ParticleAtlas02", uv = { 4/8, 4/8, .75, 6/8 } }
resource "ImageRegion" "cld2"	{ image = "ParticleAtlas02", uv = { 6/8, 4/8, 1, 6/8 } }
-- 4th row, left to right
resource "ImageRegion" "clrH"	{ image = "ParticleAtlas02", uv = { 0, 6/8, 2/8, 1 } }
resource "ImageRegion" "dmdH"	{ image = "ParticleAtlas02", uv = { 2/8, 6/8, 4/8, 1 } }
resource "ImageRegion" "sqrH"	{ image = "ParticleAtlas02", uv = { 4/8, 6/8, .75, 1 } }
resource "ImageRegion" "triH"	{ image = "ParticleAtlas02", uv = { 6/8, 6/8, 1, 1 } }

-- AVATAR --

resourceref "Image" "HandyTex"
resourceref "Image" "HairNormal"
resourceref "Image" "FeatherNoise"
resourceref "Image" "GlitterNoiseBlue"
resourceref "Image" "CoinNoise"
resourceref "Image" "HeartNoise"
resourceref "Image" "TGCWireframeNoise"
resourceref "Image" "CapeIntegrity"

resourceref "Image" "AvatarChamBodyTex"

-- Avatar body
resourceref "Image" "SpiritAtlas"

-- Avatar hair/mask/horn/neck
resourceref "Image" "CharSkyKid_All_Grad_Tex"

-- Avatar attribute textures
resourceref "Image" "CharSkyKid_Mask_Simple_Att"

-- UI ATLASES --

-- UIAtlas3
resourceref "Image" "UIAtlas3"
resource "ImageRegion" "UIShopButtonCircle1"			{ image = "UIAtlas3", uv = { 0/3, 0/3, 1/3, 1/3 } }
resource "ImageRegion" "UIShopButtonCircle2"			{ image = "UIAtlas3", uv = { 1/3, 0/3, 2/3, 1/3 } }
resource "ImageRegion" "UIShopButtonCircle3"			{ image = "UIAtlas3", uv = { 2/3, 0/3, 3/3, 1/3 } }
--resource "ImageRegion" "UIShopButtonCircle4"			{ image = "UIAtlas3", uv = { 0/3, 1/3, 1/3, 2/3 } }
--resource "ImageRegion" "UIShopButtonCircle5"			{ image = "UIAtlas3", uv = { 1/3, 1/3, 2/3, 2/3 } }

-- UIAtlas4
resourceref "Image" "UIAtlas4"
resource "ImageRegion" "UIRainbowHeart"					{ image = "UIAtlas4", uv = { 0/2, 0/2, 1/2, 1/2 } }
resource "ImageRegion" "UIRainbowGift"					{ image = "UIAtlas4", uv = { 1/2, 0/2, 2/2, 1/2 } }

-- UITutorialAtlases
resourceref "Image" "UITutorialAtlasAP"
resource "ImageRegion" "UISeasonPassPromoAP"			{ image = "UITutorialAtlasAP", uv = { 0/3, 1/3, 1/3, 2/3 } }
resource "ImageRegion" "UISeasonPassPromo2AP"			{ image = "UITutorialAtlasAP", uv = { 2/3, 0/3, 3/3, 1/3 } }
resource "ImageRegion" "UISeasonPassPromo3AP"			{ image = "UITutorialAtlasAP", uv = { 1/3, 1/3, 2/3, 2/3 } }
resource "ImageRegion" "UISeasonPassPromo4AP"			{ image = "UITutorialAtlasAP", uv = { 1/3, 0/3, 2/3, 1/3 } }
resource "ImageRegion" "UISeasonPassPromo5AP"			{ image = "UITutorialAtlasAP", uv = { 0/3, 0/3, 1/3, 1/3 } }
resource "ImageRegion" "UITutorialUnravelMystery"		{ image = "UITutorialAtlasAP", uv = { 2/3, 1/3, 3/3, 2/3 } }
resource "ImageRegion" "UITutorialSaveSpirits"			{ image = "UITutorialAtlasAP", uv = { 0/3, 2/3, 1/3, 3/3 } }
resource "ImageRegion" "UITutorialFlyHigher"			{ image = "UITutorialAtlasAP", uv = { 1/3, 2/3, 2/3, 3/3 } }
resource "ImageRegion" "UITutorialAscendToStorm"		{ image = "UITutorialAtlasAP", uv = { 2/3, 2/3, 3/3, 3/3 } }

resourceref "Image" "UISeasonPassPromoAP15"
resourceref "Image" "UISeasonPassPromoAP16"
resourceref "Image" "UISeasonPassPromoAP17"
resourceref "Image" "UISeasonPassPromoAP18"
resourceref "Image" "UISeasonPassPromoAP19"
resourceref "Image" "UISeasonPassPromoAP20"
resourceref "Image" "UISeasonPassPromoAP21"
resourceref "Image" "UISeasonPassPromoAP22"
resourceref "Image" "UISeasonPassPromoAP23"
resourceref "Image" "UISeasonPassPromoAP24"
resourceref "Image" "UISeasonPassPromoAP25"
resourceref "Image" "UISeasonPassPromoAP26"

--temporal fix for spellshop tutorial
resourceref "Image" "UISeasonPassPreoderPromoAP06"

-- UITutorialAtlases - SharedSpace
resourceref "Image" "UITutorialAtlasSharedSpaces"
resource "ImageRegion" "UISharedSpacesShareMagic"		{ image = "UITutorialAtlasSharedSpaces", uv = { 0/3, 0/3, 1/3, 1/3 } }
resource "ImageRegion" "UISharedSpacesExploreWorld"		{ image = "UITutorialAtlasSharedSpaces", uv = { 1/3, 0/3, 2/3, 1/3 } }
resource "ImageRegion" "UISharedSpacesUniqueItems"		{ image = "UITutorialAtlasSharedSpaces", uv = { 2/3, 0/3, 3/3, 1/3 } }
resource "ImageRegion" "UISharedSpacesBeCreative"		{ image = "UITutorialAtlasSharedSpaces", uv = { 0/3, 1/3, 1/3, 2/3 } }
resource "ImageRegion" "UISharedSpacesShareTutorial1"	{ image = "UITutorialAtlasSharedSpaces", uv = { 1/3, 1/3, 2/3, 2/3 } }
resource "ImageRegion" "UISharedSpacesShareTutorial2"	{ image = "UITutorialAtlasSharedSpaces", uv = { 2/3, 1/3, 3/3, 2/3 } }
resource "ImageRegion" "UISharedSpacesShareTutorial3"	{ image = "UITutorialAtlasSharedSpaces", uv = { 0/3, 2/3, 1/3, 3/3 } }
resource "ImageRegion" "UISharedSpacesShareTutorial4"	{ image = "UITutorialAtlasSharedSpaces", uv = { 1/3, 2/3, 2/3, 3/3 } }
-- UITutorialAtlases - Penpal
resource "ImageRegion" "UITutorialPenpal"				{ image = "UITutorialAtlasSharedSpaces", uv = { 2/3, 2/3, 3/3, 3/3 } }

resourceref "Image" "UITutorialAtlas02"
resource "ImageRegion" "UITutorialHeal"					{ image = "UITutorialAtlas02", uv = { 0/3, 0/3, 1/3, 1/3 } }
resource "ImageRegion" "UITutorialBetterTogether"		{ image = "UITutorialAtlas02", uv = { 1/3, 0/3, 2/3, 1/3 } }
resource "ImageRegion" "UITutorialGrowCloser"			{ image = "UITutorialAtlas02", uv = { 2/3, 0/3, 3/3, 1/3 } }
resource "ImageRegion" "UITutorialStayInTouch"			{ image = "UITutorialAtlas02", uv = { 0/3, 1/3, 1/3, 2/3 } }
resource "ImageRegion" "UITutorialShowAppreciation"		{ image = "UITutorialAtlas02", uv = { 1/3, 1/3, 2/3, 2/3 } }
resource "ImageRegion" "UITutorialExpressYourself"		{ image = "UITutorialAtlas02", uv = { 2/3, 1/3, 3/3, 2/3 } }
resource "ImageRegion" "UITutorialUnlockGates"			{ image = "UITutorialAtlas02", uv = { 0/3, 2/3, 1/3, 3/3 } }
resource "ImageRegion" "UITutorialFindAll"				{ image = "UITutorialAtlas02", uv = { 1/3, 2/3, 2/3, 3/3 } }
resource "ImageRegion" "UITutorialAscendFriendship"		{ image = "UITutorialAtlas02", uv = { 2/3, 2/3, 3/3, 3/3 } }

resourceref "Image" "UITutorialAtlas03"
resource "ImageRegion" "UITutorialEnhanceExpressions"	{ image = "UITutorialAtlas03", uv = { 0/3, 0/3, 1/3, 1/3 } }
resource "ImageRegion" "UITutorialReceiveBlessing"		{ image = "UITutorialAtlas03", uv = { 1/3, 0/3, 2/3, 1/3 } }
resource "ImageRegion" "UITutorialCompleteConstellation"{ image = "UITutorialAtlas03", uv = { 2/3, 0/3, 3/3, 1/3 } }
resource "ImageRegion" "UITutorialDressUp"				{ image = "UITutorialAtlas03", uv = { 0/3, 1/3, 1/3, 2/3 } }
resource "ImageRegion" "UITutorialAdventureAwaits"		{ image = "UITutorialAtlas03", uv = { 1/3, 1/3, 2/3, 2/3 } }
resource "ImageRegion" "UITutorialEachKingdom"			{ image = "UITutorialAtlas03", uv = { 2/3, 1/3, 3/3, 2/3 } }
resource "ImageRegion" "UITutorialFindSpirits"			{ image = "UITutorialAtlas03", uv = { 0/3, 2/3, 1/3, 3/3 } }
resource "ImageRegion" "UITutorialOfferHearts"			{ image = "UITutorialAtlas03", uv = { 1/3, 2/3, 2/3, 3/3 } }
resource "ImageRegion" "UITutorialDressUp2"				{ image = "UITutorialAtlas03", uv = { 2/3, 2/3, 3/3, 3/3 } }

resourceref "Image" "UITutorialAtlas04"
resource "ImageRegion" "UITutorialVisitingSpirits"      { image = "UITutorialAtlas04", uv = { 0/3, 0/3, 1/3, 1/3 } }
resource "ImageRegion" "UITutorialPerformTogether"      { image = "UITutorialAtlas04", uv = { 1/3, 0/3, 2/3, 1/3 } }
resource "ImageRegion" "UITutorialUnlockRewards"        { image = "UITutorialAtlas04", uv = { 2/3, 0/3, 3/3, 1/3 } }
resource "ImageRegion" "UITutorialFindSpirits2"         { image = "UITutorialAtlas04", uv = { 0/3, 1/3, 1/3, 2/3 } }
resource "ImageRegion" "UITutorialRequirePass"          { image = "UITutorialAtlas04", uv = { 1/3, 1/3, 2/3, 2/3 } }
resource "ImageRegion" "UITutorialPreview"              { image = "UITutorialAtlas04", uv = { 2/3, 1/3, 3/3, 2/3 } }
resource "ImageRegion" "UITutorialVariousForms"         { image = "UITutorialAtlas04", uv = { 0/3, 2/3, 1/3, 3/3 } }
resource "ImageRegion" "UITutorialEventCurrency"        { image = "UITutorialAtlas04", uv = { 1/3, 2/3, 2/3, 3/3 } }
--resource "ImageRegion" ""                             { image = "UITutorialAtlas04", uv = { 2/3, 2/3, 3/3, 3/3 } }

resourceref "Image" "UICollectible_Day01_"
resource "ImageRegion" "UICollectible_Day02"			{ image = "UICollectible_Day01_", uv = { 0, 0, 1, 1/2 } }
resource "ImageRegion" "UICollectibleLine"				{ image = "UICollectible_Day01_", uv = { 0, 1/2, 1, 5/8 } }
resource "ImageRegion" "UICollectibleStarFx"			{ image = "UICollectible_Day01_", uv = { 0, 5/8, 3/8, 1 } }
resource "ImageRegion" "UICollectibleStar"				{ image = "UICollectible_Day01_", uv = { 3/8, 5/8, 4/8, 6/8 } }
resource "ImageRegion" "UICollectibleStarGlow"			{ image = "UICollectible_Day01_", uv = { 3/8, 6/8, 5/8, 8/8 } }

-- UiMiscCircle being used here is temporary, we'll add an actual atlas soon!
resourceref "Image" "UiMiscCircle"
resource "ImageRegion" "TguiMaskWhite"					{ image = "UiMiscCircle", uv = { 1/3, 1/3, 2/3, 2/3 } }
resource "ImageRegion" "TguiMaskCircle"					{ image = "UiMiscCircle", uv = { 0, 0, 1, 1 } }

-- UiMiscCircle being used here is temporary, we'll add an actual atlas soon!
resourceref "Image" "UIPremulAtlas1"
resourceref "Image" "UIPremulAtlas2"
resourceref "Image" "UIPremulAtlas3"
resourceref "Image" "UIPremulAtlas4"
resource "ImageRegion" "S26SilenceCardRibbon" { image = "UIPremulAtlas4", uv = { 0, 3/4, 3/4, 1 } }
resource "ImageRegion" "S26SilenceCardStar"	{ image = "UIPremulAtlas4", uv = { 3/4, 3/4, 1, 1 } }
resource "ImageRegion" "UiMenuDialGradient" { image = "UIPremulAtlas4", uv = { 0/512, 78/512, (0+422)/512, (78+78)/512 } }
resource "ImageRegion" "UiMenuDialLine" { image = "UIPremulAtlas4", uv = { 0/512, 0/512, (0+422)/512, (0+78)/512 } }
resource "ImageRegion" "UiMenuSpeechBg" { image = "UIPremulAtlas1", uv = { 193/512, 303/512, (193+82)/512, (303+82)/512 } }
resource "ImageRegion" "UiMenuSpeechOutline" { image = "UIPremulAtlas1", uv = { 193/512, 221/512, (193+82)/512, (221+82)/512 } }
resource "ImageRegion" "UiMenuSpeechShadow" { image = "UIPremulAtlas1", uv = { 275/512, 221/512, (275+86)/512, (221+82)/512 } }
resource "ImageRegion" "UiMenuSpinner" { image = "UIPremulAtlas1", uv = { 254/512, 85/512, (254+64)/512, (85+64)/512 } }
resource "ImageRegion" "UiMenuSpinnerThin" { image = "UIPremulAtlas1", uv = { 190/512, 85/512, (190+64)/512, (85+64)/512 } }
resource "ImageRegion" "UiMenuSpinner_Small" { image = "UIPremulAtlas1", uv = { 0/512, 16/512, (0+32)/512, (16+32)/512 } }
resource "ImageRegion" "UiMenuStar" { image = "UIPremulAtlas1", uv = { 126/512, 149/512, (126+67)/512, (149+67)/512 } }
resource "ImageRegion" "UiMenuStarHeartBg" { image = "UIPremulAtlas1", uv = { 193/512, 149/512, (193+78)/512, (149+72)/512 } }
resource "ImageRegion" "UiMenuStarHeartFg" { image = "UIPremulAtlas1", uv = { 126/512, 85/512, (126+64)/512, (85+64)/512 } }
resource "ImageRegion" "UiMenuStarOutlineSmall" { image = "UIPremulAtlas1", uv = { 66/512, 85/512, (66+60)/512, (85+60)/512 } }
resource "ImageRegion" "UiMiscCircleShadow" { image = "UIPremulAtlas1", uv = { 66/512, 49/512, (66+36)/512, (49+36)/512 } }
resource "ImageRegion" "UiMiscCircleShadowSmall" { image = "UIPremulAtlas1", uv = { 32/512, 49/512, (32+34)/512, (49+34)/512 } }
resource "ImageRegion" "UiMiscCircleShadowSmallFaint" { image = "UIPremulAtlas1", uv = { 32/512, 16/512, (32+33)/512, (16+33)/512 } }
resource "ImageRegion" "UiMiscCircleShadowVerySmall" { image = "UIPremulAtlas1", uv = { 0/512, 0/512, (0+16)/512, (0+16)/512 } }
resource "ImageRegion" "UiMiscParticleFuzzy" { image = "UIPremulAtlas1", uv = { 16/512, 0/512, (16+17)/512, (0+16)/512 } }
resource "ImageRegion" "UiMiscR2Shadow" { image = "UIPremulAtlas1", uv = { 0/512, 48/512, (0+32)/512, (48+32)/512 } }
resource "ImageRegion" "UiMiscRTShadow" { image = "UIPremulAtlas1", uv = { 0/512, 80/512, (0+32)/512, (80+32)/512 } }
resource "ImageRegion" "UiStarBg" { image = "UIPremulAtlas1", uv = { 275/512, 303/512, (275+174)/512, (303+174)/512 } }
resource "ImageRegion" "UiStarBgLarge" { image = "UIPremulAtlas3", uv = { 256/512, 0/512, (256+256)/512, (0+256)/512 } }
resource "ImageRegion" "UiStarFg" { image = "UIPremulAtlas2", uv = { 0/512, 0/512, (0+174)/512, (0+174)/512 } }
resource "ImageRegion" "UiStarFgLarge" { image = "UIPremulAtlas2", uv = { 174/512, 174/512, (174+256)/512, (174+256)/512 } }
resource "ImageRegion" "UiStarLitBg" { image = "UIPremulAtlas2", uv = { 0/512, 174/512, (0+174)/512, (174+175)/512 } }
resource "ImageRegion" "UiStarLitBgLarge" { image = "UIPremulAtlas3", uv = { 0/512, 0/512, (0+256)/512, (0+256)/512 } }
resource "ImageRegion" "UiStarLitFg" { image = "UIPremulAtlas2", uv = { 174/512, 0/512, (174+174)/512, (0+174)/512 } }
resource "ImageRegion" "UiStarLitFgLarge" { image = "UIPremulAtlas3", uv = { 0/512, 256/512, (0+256)/512, (256+256)/512 } }

-- UIFullLumAtlas (doesn't stomp our luminance) ( coord order goes left, top, right, bottom )
resourceref "Image" "UIFullLumAtlas1"
resourceref "Image" "UIFullLumAtlas2"
resource "ImageRegion" "UIBorderFilledSmall" { image = "UIFullLumAtlas1", uv = { 0/1024, 0/1024, (0+10)/1024, (0+10)/1024 } }
resource "ImageRegion" "UIRingThick" { image = "UIFullLumAtlas2", uv = { 0/1024, 256/1024, (0+128)/1024, (256+128)/1024 } }
resource "ImageRegion" "UiAnalogLeftPushDownNx" { image = "UIFullLumAtlas1", uv = { 826/1024, 652/1024, (826+128)/1024, (652+128)/1024 } }
resource "ImageRegion" "UiAnalogLeftPushLeftNx" { image = "UIFullLumAtlas1", uv = { 570/1024, 652/1024, (570+128)/1024, (652+128)/1024 } }
resource "ImageRegion" "UiAnalogLeftPushRightNx" { image = "UIFullLumAtlas1", uv = { 570/1024, 268/1024, (570+128)/1024, (268+128)/1024 } }
resource "ImageRegion" "UiAnalogLeftPushUpNx" { image = "UIFullLumAtlas1", uv = { 698/1024, 268/1024, (698+128)/1024, (268+128)/1024 } }
resource "ImageRegion" "UiAnalogRightPushDownNx" { image = "UIFullLumAtlas1", uv = { 314/1024, 396/1024, (314+128)/1024, (396+128)/1024 } }
resource "ImageRegion" "UiAnalogRightPushLeftNx" { image = "UIFullLumAtlas1", uv = { 314/1024, 652/1024, (314+128)/1024, (652+128)/1024 } }
resource "ImageRegion" "UiAnalogRightPushRightNx" { image = "UIFullLumAtlas1", uv = { 442/1024, 396/1024, (442+128)/1024, (396+128)/1024 } }
resource "ImageRegion" "UiAnalogRightPushUpNx" { image = "UIFullLumAtlas1", uv = { 570/1024, 396/1024, (570+128)/1024, (396+128)/1024 } }
resource "ImageRegion" "UiBorderFlatBottom" { image = "UIFullLumAtlas2", uv = { 128/1024, 0/1024, (128+128)/1024, (0+128)/1024 } }
resource "ImageRegion" "UiBorderThickSmall" { image = "UIFullLumAtlas1", uv = { 16/1024, 226/1024, (16+32)/1024, (226+32)/1024 } }
resource "ImageRegion" "UiBorderThinLarge" { image = "UIFullLumAtlas2", uv = { 256/1024, 0/1024, (256+128)/1024, (0+128)/1024 } }
resource "ImageRegion" "UiBorderThinMedium" { image = "UIFullLumAtlas2", uv = { 512/1024, 0/1024, (512+128)/1024, (0+128)/1024 } }
resource "ImageRegion" "UiBorderThinSmall" { image = "UIFullLumAtlas2", uv = { 640/1024, 0/1024, (640+128)/1024, (0+128)/1024 } }
resource "ImageRegion" "UiButtonANx" { image = "UIFullLumAtlas1", uv = { 16/1024, 66/1024, (16+32)/1024, (66+32)/1024 } }
resource "ImageRegion" "UiButtonANxSmall" { image = "UIFullLumAtlas1", uv = { 0/1024, 10/1024, (0+16)/1024, (10+16)/1024 } }
resource "ImageRegion" "UiButtonBNx" { image = "UIFullLumAtlas1", uv = { 16/1024, 290/1024, (16+32)/1024, (290+32)/1024 } }
resource "ImageRegion" "UiButtonBNxSmall" { image = "UIFullLumAtlas1", uv = { 0/1024, 42/1024, (0+16)/1024, (42+16)/1024 } }
resource "ImageRegion" "UiButtonDownNx" { image = "UIFullLumAtlas1", uv = { 352/1024, 204/1024, (352+64)/1024, (204+64)/1024 } }
resource "ImageRegion" "UiButtonL3Nx" { image = "UIFullLumAtlas1", uv = { 96/1024, 140/1024, (96+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiButtonLeftNx" { image = "UIFullLumAtlas1", uv = { 96/1024, 204/1024, (96+64)/1024, (204+64)/1024 } }
resource "ImageRegion" "UiButtonMinusNx" { image = "UIFullLumAtlas1", uv = { 96/1024, 268/1024, (96+64)/1024, (268+64)/1024 } }
resource "ImageRegion" "UiButtonPlusNx" { image = "UIFullLumAtlas1", uv = { 96/1024, 332/1024, (96+64)/1024, (332+64)/1024 } }
resource "ImageRegion" "UiButtonR3Nx" { image = "UIFullLumAtlas1", uv = { 96/1024, 396/1024, (96+64)/1024, (396+64)/1024 } }
resource "ImageRegion" "UiButtonRightNx" { image = "UIFullLumAtlas1", uv = { 96/1024, 460/1024, (96+64)/1024, (460+64)/1024 } }
resource "ImageRegion" "UiButtonUpNx" { image = "UIFullLumAtlas1", uv = { 96/1024, 524/1024, (96+64)/1024, (524+64)/1024 } }
resource "ImageRegion" "UiButtonXNx" { image = "UIFullLumAtlas1", uv = { 16/1024, 130/1024, (16+32)/1024, (130+32)/1024 } }
resource "ImageRegion" "UiButtonXNxSmall" { image = "UIFullLumAtlas1", uv = { 0/1024, 58/1024, (0+16)/1024, (58+16)/1024 } }
resource "ImageRegion" "UiButtonYNx" { image = "UIFullLumAtlas1", uv = { 16/1024, 194/1024, (16+32)/1024, (194+32)/1024 } }
resource "ImageRegion" "UiButtonYNxSmall" { image = "UIFullLumAtlas1", uv = { 16/1024, 162/1024, (16+32)/1024, (162+32)/1024 } }
resource "ImageRegion" "UiCandleGlow" { image = "UIFullLumAtlas1", uv = { 698/1024, 652/1024, (698+128)/1024, (652+128)/1024 } }
resource "ImageRegion" "UiCandleGlowMasked" { image = "UIFullLumAtlas1", uv = { 570/1024, 780/1024, (570+128)/1024, (780+128)/1024 } }
resource "ImageRegion" "UiCandleLensFlare" { image = "UIFullLumAtlas1", uv = { 442/1024, 652/1024, (442+128)/1024, (652+128)/1024 } }
resource "ImageRegion" "UiGradientShout" { image = "UIFullLumAtlas1", uv = { 224/1024, 268/1024, (224+90)/1024, (268+90)/1024 } }
resource "ImageRegion" "UiGradientShout_Large" { image = "UIFullLumAtlas2", uv = { 128/1024, 128/1024, (128+256)/1024, (128+256)/1024 } }
resource "ImageRegion" "UiHudChevronBroken" { image = "UIFullLumAtlas1", uv = { 288/1024, 140/1024, (288+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiHudChevronBrokenPartial" { image = "UIFullLumAtlas1", uv = { 352/1024, 140/1024, (352+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiHudChevronGlow" { image = "UIFullLumAtlas1", uv = { 698/1024, 396/1024, (698+128)/1024, (396+128)/1024 } }
resource "ImageRegion" "UiHudChevronGlowLvl1" { image = "UIFullLumAtlas1", uv = { 140/1024, 34/1024, (140+46)/1024, (34+46)/1024 } }
resource "ImageRegion" "UiHudChevronGlowLvl2" { image = "UIFullLumAtlas1", uv = { 48/1024, 34/1024, (48+46)/1024, (34+46)/1024 } }
resource "ImageRegion" "UiHudChevronGlowLvl3" { image = "UIFullLumAtlas1", uv = { 94/1024, 34/1024, (94+46)/1024, (34+46)/1024 } }
resource "ImageRegion" "UiHudChevronMed" { image = "UIFullLumAtlas1", uv = { 672/1024, 140/1024, (672+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiHudChevronPulse" { image = "UIFullLumAtlas1", uv = { 314/1024, 524/1024, (314+128)/1024, (524+128)/1024 } }
resource "ImageRegion" "UiHudChevronSmall" { image = "UIFullLumAtlas1", uv = { 16/1024, 10/1024, (16+24)/1024, (10+24)/1024 } }
resource "ImageRegion" "UiHudDiamondFill" { image = "UIFullLumAtlas1", uv = { 864/1024, 140/1024, (864+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiHudDiamondOutline" { image = "UIFullLumAtlas1", uv = { 928/1024, 140/1024, (928+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiHudShatterTri" { image = "UIFullLumAtlas1", uv = { 16/1024, 34/1024, (16+32)/1024, (34+32)/1024 } }
resource "ImageRegion" "UiLeftButtonNx" { image = "UIFullLumAtlas1", uv = { 160/1024, 268/1024, (160+64)/1024, (268+64)/1024 } }
resource "ImageRegion" "UiLeftTriggerNx" { image = "UIFullLumAtlas1", uv = { 160/1024, 332/1024, (160+64)/1024, (332+64)/1024 } }
resource "ImageRegion" "UiMenuAccountBadge" { image = "UIFullLumAtlas1", uv = { 160/1024, 396/1024, (160+64)/1024, (396+64)/1024 } }
resource "ImageRegion" "UiMenuBadgePen" { image = "UIFullLumAtlas1", uv = { 160/1024, 460/1024, (160+64)/1024, (460+64)/1024 } }
resource "ImageRegion" "UiMenuCandleInnerGlow1" { image = "UIFullLumAtlas1", uv = { 160/1024, 524/1024, (160+64)/1024, (524+64)/1024 } }
resource "ImageRegion" "UiMenuCandleInnerGlow2" { image = "UIFullLumAtlas1", uv = { 160/1024, 588/1024, (160+64)/1024, (588+64)/1024 } }
resource "ImageRegion" "UiMenuCandleInnerGlow3" { image = "UIFullLumAtlas1", uv = { 160/1024, 652/1024, (160+64)/1024, (652+64)/1024 } }
resource "ImageRegion" "UiMenuConstellationArrowRight" { image = "UIFullLumAtlas1", uv = { 48/1024, 80/1024, (48+48)/1024, (80+48)/1024 } }
resource "ImageRegion" "UiMenuDiamondSmall" { image = "UIFullLumAtlas1", uv = { 0/1024, 26/1024, (0+16)/1024, (26+16)/1024 } }
resource "ImageRegion" "UiMenuDivingShadow" { image = "UIFullLumAtlas1", uv = { 442/1024, 268/1024, (442+128)/1024, (268+128)/1024 } }
resource "ImageRegion" "UiMenuFly" { image = "UIFullLumAtlas1", uv = { 314/1024, 268/1024, (314+128)/1024, (268+128)/1024 } }
resource "ImageRegion" "UiMenuFlyShadow" { image = "UIFullLumAtlas2", uv = { 0/1024, 0/1024, (0+128)/1024, (0+128)/1024 } }
resource "ImageRegion" "UiMenuFriendsTab" { image = "UIFullLumAtlas1", uv = { 224/1024, 204/1024, (224+64)/1024, (204+64)/1024 } }
resource "ImageRegion" "UiMenuHover" { image = "UIFullLumAtlas2", uv = { 896/1024, 0/1024, (896+128)/1024, (0+128)/1024 } }
resource "ImageRegion" "UiMenuHoverShadow" { image = "UIFullLumAtlas1", uv = { 442/1024, 524/1024, (442+128)/1024, (524+128)/1024 } }
resource "ImageRegion" "UiMenuInfo" { image = "UIFullLumAtlas1", uv = { 160/1024, 908/1024, (160+64)/1024, (908+64)/1024 } }
resource "ImageRegion" "UiMenuLinkAccount" { image = "UIFullLumAtlas1", uv = { 160/1024, 844/1024, (160+64)/1024, (844+64)/1024 } }
resource "ImageRegion" "UiMenuNewWindow" { image = "UIFullLumAtlas1", uv = { 160/1024, 780/1024, (160+64)/1024, (780+64)/1024 } }
resource "ImageRegion" "UiMenuNextArrow" { image = "UIFullLumAtlas1", uv = { 160/1024, 716/1024, (160+64)/1024, (716+64)/1024 } }
resource "ImageRegion" "UiMenuNx" { image = "UIFullLumAtlas1", uv = { 160/1024, 204/1024, (160+64)/1024, (204+64)/1024 } }
resource "ImageRegion" "UiMenuPerson" { image = "UIFullLumAtlas1", uv = { 800/1024, 140/1024, (800+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiMenuPlus" { image = "UIFullLumAtlas1", uv = { 736/1024, 140/1024, (736+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiMenuQRWhite" { image = "UIFullLumAtlas1", uv = { 608/1024, 140/1024, (608+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiMenuRandomize" { image = "UIFullLumAtlas1", uv = { 544/1024, 140/1024, (544+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiMenuSwimmingShadow" { image = "UIFullLumAtlas1", uv = { 314/1024, 780/1024, (314+128)/1024, (780+128)/1024 } }
resource "ImageRegion" "UiMenuTabArrow" { image = "UIFullLumAtlas1", uv = { 480/1024, 140/1024, (480+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiMenuTabCreateInvite" { image = "UIFullLumAtlas1", uv = { 416/1024, 140/1024, (416+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiMenuTabOnlineFriends" { image = "UIFullLumAtlas1", uv = { 224/1024, 140/1024, (224+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiMenuTabReceivedInvite" { image = "UIFullLumAtlas1", uv = { 160/1024, 140/1024, (160+64)/1024, (140+64)/1024 } }
resource "ImageRegion" "UiMenuTabSentInvite" { image = "UIFullLumAtlas1", uv = { 96/1024, 908/1024, (96+64)/1024, (908+64)/1024 } }
resource "ImageRegion" "UiMenuUnlinkAccount" { image = "UIFullLumAtlas1", uv = { 96/1024, 844/1024, (96+64)/1024, (844+64)/1024 } }
resource "ImageRegion" "UiMessageTypeContent" { image = "UIFullLumAtlas1", uv = { 442/1024, 780/1024, (442+128)/1024, (780+128)/1024 } }
resource "ImageRegion" "UiMessageTypeEvent" { image = "UIFullLumAtlas1", uv = { 570/1024, 524/1024, (570+128)/1024, (524+128)/1024 } }
resource "ImageRegion" "UiMessageTypeMisc" { image = "UIFullLumAtlas1", uv = { 698/1024, 524/1024, (698+128)/1024, (524+128)/1024 } }
resource "ImageRegion" "UiMessageTypeUrgent" { image = "UIFullLumAtlas1", uv = { 826/1024, 524/1024, (826+128)/1024, (524+128)/1024 } }
resource "ImageRegion" "UiMiscCheckSmall" { image = "UIFullLumAtlas1", uv = { 16/1024, 258/1024, (16+32)/1024, (258+32)/1024 } }
resource "ImageRegion" "UiMiscCheckWhite" { image = "UIFullLumAtlas1", uv = { 96/1024, 780/1024, (96+64)/1024, (780+64)/1024 } }
resource "ImageRegion" "UiMiscGradientSlice" { image = "UIFullLumAtlas1", uv = { 40/1024, 10/1024, (40+64)/1024, (10+16)/1024 } }
resource "ImageRegion" "UiMiscInteractOuter" { image = "UIFullLumAtlas1", uv = { 16/1024, 322/1024, (16+32)/1024, (322+32)/1024 } }
resource "ImageRegion" "UiMiscLensFlare" { image = "UIFullLumAtlas1", uv = { 826/1024, 780/1024, (826+128)/1024, (780+128)/1024 } }
resource "ImageRegion" "UiMiscParticle" { image = "UIFullLumAtlas1", uv = { 224/1024, 358/1024, (224+90)/1024, (358+90)/1024 } }
resource "ImageRegion" "UiMiscPhone" { image = "UIFullLumAtlas1", uv = { 96/1024, 716/1024, (96+64)/1024, (716+64)/1024 } }
resource "ImageRegion" "UiMiscXWhite" { image = "UIFullLumAtlas1", uv = { 96/1024, 652/1024, (96+64)/1024, (652+64)/1024 } }
resource "ImageRegion" "UiPulse" { image = "UIFullLumAtlas2", uv = { 384/1024, 0/1024, (384+128)/1024, (0+128)/1024 } }
resource "ImageRegion" "UiRightButtonNx" { image = "UIFullLumAtlas1", uv = { 96/1024, 588/1024, (96+64)/1024, (588+64)/1024 } }
resource "ImageRegion" "UiRightTriggerNx" { image = "UIFullLumAtlas1", uv = { 288/1024, 204/1024, (288+64)/1024, (204+64)/1024 } }
resource "ImageRegion" "UiRingGradientOuter" { image = "UIFullLumAtlas2", uv = { 768/1024, 0/1024, (768+128)/1024, (0+128)/1024 } }
resource "ImageRegion" "UiTagBg" { image = "UIFullLumAtlas1", uv = { 96/1024, 80/1024, (96+60)/1024, (80+60)/1024 } }
resource "ImageRegion" "UiToggleBgShadow" { image = "UIFullLumAtlas1", uv = { 826/1024, 396/1024, (826+128)/1024, (396+128)/1024 } }
resource "ImageRegion" "UiToggleButtonShadow" { image = "UIFullLumAtlas2", uv = { 0/1024, 128/1024, (0+128)/1024, (128+128)/1024 } }

resourceref "Image" "UiMapBgAtlas"
resource "ImageRegion" "UiMap_Pattern_Hills04" { image = "UiMapBgAtlas", uv = {0, 0.749, 0.1787, 1} }
resource "ImageRegion" "UiMapOreo01" { image = "UiMapBgAtlas", uv = {0.7915, 0.8604, 0.9997, 0.9998} }
resource "ImageRegion" "UiMap_Pattern_Mountain03" { image = "UiMapBgAtlas", uv = {0.1914, 0.8765, 0.4424, 1} }
resource "ImageRegion" "UiMapBirdSingle4" { image = "UiMapBgAtlas", uv = {0.3887, 0.7603, 0.409, 0.7723} }
resource "ImageRegion" "UiMapWhale02" { image = "UiMapBgAtlas", uv = {0.8262, 0.6982, 0.9995, 0.8535} }
resource "ImageRegion" "UiMap_Pattern_Waves02" { image = "UiMapBgAtlas", uv = {0.709, 0.7021, 0.8193, 0.8413} }
resource "ImageRegion" "UiMap_Environment_Sunset_Town1" { image = "UiMapBgAtlas", uv = {0.6245, 0.6514, 0.7002, 0.7695} }
resource "ImageRegion" "UiMap_Pattern_PointyMountain05" { image = "UiMapBgAtlas", uv = {0.4502, 0.7827, 0.7012, 1} }
resource "ImageRegion" "UiMap_Pattern_Desert04" { image = "UiMapBgAtlas", uv = {0.1914, 0.7861, 0.4424, 0.8682} }
resource "ImageRegion" "UiMap_Environment_Sunset_FlyRace_City1" { image = "UiMapBgAtlas", uv = {0.1914, 0.749, 0.2144, 0.7778} }
resource "ImageRegion" "UiMap_Environment_Sunset_Town3" { image = "UiMapBgAtlas", uv = {0.3843, 0.7236, 0.4031, 0.75} }
resource "ImageRegion" "UiMapEnvironment_Sunset_Citadel" { image = "UiMapBgAtlas", uv = {0.5269, 0.6528, 0.6157, 0.769} }
resource "ImageRegion" "UiMap_Environment_Sunset_FlyRace_City2" { image = "UiMapBgAtlas", uv = {0.3379, 0.605, 0.4526, 0.687} }
resource "ImageRegion" "UiMap_Environment_Sunset_Race" { image = "UiMapBgAtlas", uv = {0.2271, 0.6992, 0.3748, 0.7712} }
resource "ImageRegion" "UiMapManta07" { image = "UiMapBgAtlas", uv = {0.8745, 0.5693, 0.9998, 0.6415} }
resource "ImageRegion" "UiMapBirdSingle2" { image = "UiMapBgAtlas", uv = {0.8428, 0.6025, 0.8612, 0.6248} }
resource "ImageRegion" "UiMapDuskTriangleCreature" { image = "UiMapBgAtlas", uv = {0.7139, 0.5718, 0.8359, 0.6938} }
resource "ImageRegion" "UiMap_Environment_Night_Desert" { image = "UiMapBgAtlas", uv = {0.5312, 0.5459, 0.6992, 0.6436} }
resource "ImageRegion" "UiMapKrill02" { image = "UiMapBgAtlas", uv = {0.1841, 0.5176, 0.5003, 0.5926} }
resource "ImageRegion" "UiMap_Pattern_Trees01" { image = "UiMapBgAtlas", uv = {0, 0.6006, 0.2134, 0.7373} }
resource "ImageRegion" "UiMapBirdSingle1" { image = "UiMapBgAtlas", uv = {0.8433, 0.5718, 0.8644, 0.5958} }
resource "ImageRegion" "UiMapRainCreature02" { image = "UiMapBgAtlas", uv = {0.186, 0.4507, 0.2671, 0.5112} }
resource "ImageRegion" "UiMapJellyfish05" { image = "UiMapBgAtlas", uv = {0.71, 0.4434, 0.7603, 0.4937} }
resource "ImageRegion" "UiMapManta01" { image = "UiMapBgAtlas", uv = {0.7192, 0.5103, 0.7998, 0.5624} }
resource "ImageRegion" "UiMap_Environment_Sunset_Town2" { image = "UiMapBgAtlas", uv = {0.7681, 0.4438, 0.7938, 0.4873} }
resource "ImageRegion" "UiMapRainCreature01" { image = "UiMapBgAtlas", uv = {0.8076, 0.4414, 0.9997, 0.5621} }
resource "ImageRegion" "UiMapCloud23" { image = "UiMapBgAtlas", uv = {0.4526, 0.1756, 0.6284, 0.4932} }
resource "ImageRegion" "UiMapCloud14" { image = "UiMapBgAtlas", uv = {0.3081, 0.1756, 0.4461, 0.4727} }
resource "ImageRegion" "UiMapKrill04" { image = "UiMapBgAtlas", uv = {0.248, 0.2255, 0.3021, 0.4326} }
resource "ImageRegion" "UiMapManta02" { image = "UiMapBgAtlas", uv = {0.2271, 0.6035, 0.3296, 0.687} }
resource "ImageRegion" "UiMapCloud05" { image = "UiMapBgAtlas", uv = {0, 0.2251, 0.2425, 0.4429} }
resource "ImageRegion" "UiMapCloud20" { image = "UiMapBgAtlas", uv = {0, 0.4507, 0.1752, 0.5878} }
resource "ImageRegion" "UiMapManta04" { image = "UiMapBgAtlas", uv = {0.9116, 0.3442, 0.9995, 0.4321} }
resource "ImageRegion" "UiMapBirdSingle3" { image = "UiMapBgAtlas", uv = {0.4868, 0.7598, 0.4994, 0.7709} }
resource "ImageRegion" "UiMapCrab03" { image = "UiMapBgAtlas", uv = {0.4282, 0.7373, 0.4682, 0.7711} }
resource "ImageRegion" "UiMapCrab02" { image = "UiMapBgAtlas", uv = {0.4238, 0.7021, 0.4735, 0.7289} }
resource "ImageRegion" "UiMap_Environment_Sunset_YetiPark" { image = "UiMapBgAtlas", uv = {0.481, 0.7017, 0.5063, 0.751} }
resource "ImageRegion" "UiMapCloud15" { image = "UiMapBgAtlas", uv = {0.9263, 0.0002, 0.9993, 0.2715} }
resource "ImageRegion" "UiMapManta06" { image = "UiMapBgAtlas", uv = {0.8638, 0.1676, 0.9221, 0.2598} }
resource "ImageRegion" "UiMapCloud17" { image = "UiMapBgAtlas", uv = {0.6367, 0.2637, 0.8999, 0.4375} }
resource "ImageRegion" "UiMapBirdSingle6" { image = "UiMapBgAtlas", uv = {0.6382, 0.1792, 0.6502, 0.209} }
resource "ImageRegion" "UiMapCloud_Small6_Trimmed" { image = "UiMapBgAtlas", uv = {0.8447, 0, 0.9214, 0.1631} }
resource "ImageRegion" "UiMapCloud_Tiny2" { image = "UiMapBgAtlas", uv = {0.8066, 0.0003, 0.8394, 0.126} }
resource "ImageRegion" "UiMapCloud_Tiny1" { image = "UiMapBgAtlas", uv = {0.7656, 0.0007, 0.8012, 0.1245} }
resource "ImageRegion" "UiMapCloud12" { image = "UiMapBgAtlas", uv = {0.686, 0.1318, 0.8407, 0.2406} }
resource "ImageRegion" "UiMapCloud_Tiny4" { image = "UiMapBgAtlas", uv = {0.5508, 0.1172, 0.6504, 0.163} }
resource "ImageRegion" "UiMap_Pattern_Star06" { image = "UiMapBgAtlas", uv = {0.6729, 0.0938, 0.7007, 0.1216} }
resource "ImageRegion" "UiMapJellyfish02" { image = "UiMapBgAtlas", uv = {0.7051, 0.0693, 0.7604, 0.1247} }
resource "ImageRegion" "UiMap_Pattern_Star04" { image = "UiMapBgAtlas", uv = {0.6782, 0.0698, 0.6963, 0.0879} }
resource "ImageRegion" "UiMapCloud_Tiny3" { image = "UiMapBgAtlas", uv = {0.5493, 0.0684, 0.6687, 0.1134} }
resource "ImageRegion" "UiMapCloud_Small5_Trimmed" { image = "UiMapBgAtlas", uv = {0.5498, 0, 0.761, 0.0635} }
resource "ImageRegion" "UiMapCloud09" { image = "UiMapBgAtlas", uv = {0.3062, 0, 0.5444, 0.1699} }
resource "ImageRegion" "UiMapCloud02" { image = "UiMapBgAtlas", uv = {0, 0, 0.3018, 0.2192} }

-- ICONS WITH NO GLOWING OUTLINE --

resourceref "Image" "UiTutorialFootprints"
resourceref "Image" "UiTutorialFogBackdrop"

resourceref "Image" "Icon_discord"
resourceref "Image" "Icon_facebook"
resourceref "Image" "Icon_instagram"
resourceref "Image" "Icon_tiktok"
resourceref "Image" "Icon_twitch"
resourceref "Image" "Icon_twitter"
resourceref "Image" "Icon_youtube"

resourceref "Image" "UiAccountLocal"
resourceref "Image" "UiAccountGameCenter"
resourceref "Image" "UiAccountGoogle"
resourceref "Image" "UiAccountApple"
resourceref "Image" "UiAccountNintendo"
resourceref "Image" "UiAccountHuawei"
resourceref "Image" "UiAccountSony"

resourceref "Image" "UiAccountGameCenterBadge"
resourceref "Image" "UiAccountLocalBadge"
resourceref "Image" "UiAccountGoogleBadge"
resourceref "Image" "UiAccountAppleBadge"
resourceref "Image" "UiAccountNintendoBadge"
resourceref "Image" "UiAccountFacebookBadge"
resourceref "Image" "UiAccountHuaweiBadge"
resourceref "Image" "UiAccountSonyBadge"
resourceref "Image" "UiAccountSteamBadge"
resourceref "Image" "UiAccountTwitchBadge"

resourceref "Image" "UiBrandPlayStationBadge"
resourceref "Image" "UiBrandPlayStationBadge_Small"
resourceref "Image" "UiBrandPlayStationBadgeColor"
resourceref "Image" "UiBrandAppleColor"

resourceref "Image" "UiShopFog"
resourceref "Image" "UiMiscBubbleA"
resourceref "Image" "UiMiscBubbleB"
resourceref "Image" "UiMiscRoundBox"
resourceref "Image" "UiMiscBoxButton"
resourceref "Image" "UiMiscBoxButtonGlow"
resourceref "Image" "UiMiscStarCluster"
resourceref "Image" "UiMiscOneSixth"
--resourceref "Image" "UiMiscCircle"
resourceref "Image" "UiMiscCircleFade"
resourceref "Image" "UiMiscStarFull"
resourceref "Image" "UiMiscTempleDawn"
resourceref "Image" "UiMiscTempleDay"
resourceref "Image" "UiMiscTempleRain"
resourceref "Image" "UiMiscTempleSunset"
resourceref "Image" "UiMiscTempleDusk"
resourceref "Image" "UiMiscTempleNight"
resourceref "Image" "UiMiscTempleStorm"

resourceref "Image" "UiBuddyAsk"
resourceref "Image" "UiBuddyCancel"

resourceref "Image" "UiMaskEdit"

-- ICONS NOT RUN THROUGH UI ATLAS TOOL GOES HERE --

-- AP pendant icons
resourceref "Image" "UiOutfitPendant"
resourceref "Image" "UiOutfitPendantAP02"
resourceref "Image" "UiOutfitPendantAP03"
resourceref "Image" "UiOutfitPendantAP04"
resourceref "Image" "UiOutfitPendantAP05"
resourceref "Image" "UiOutfitPendantAP06"
resourceref "Image" "UiOutfitPendantAP07"
resourceref "Image" "UiOutfitPendantAP08"
resourceref "Image" "UiOutfitPendantAP09"
resourceref "Image" "UiOutfitPendantAP10"
resourceref "Image" "UiOutfitPendantAP11"
resourceref "Image" "UiOutfitPendantAP12"
resourceref "Image" "UiOutfitPendantAP13"
resourceref "Image" "UiOutfitPendantAP14"
resourceref "Image" "UiOutfitPendantAP15"
resourceref "Image" "UiOutfitPendantAP16"
resourceref "Image" "UiOutfitPendantAP17"
resourceref "Image" "UiOutfitPendantAP18"
resourceref "Image" "UiOutfitPendantAP19"
resourceref "Image" "UiOutfitPendantAP20"
resourceref "Image" "UiOutfitPendantAP21"
resourceref "Image" "UiOutfitPendantAP22"
resourceref "Image" "UiOutfitPendantAP23"
resourceref "Image" "UiOutfitPendantAP24"
resourceref "Image" "UiOutfitPendantAP25"
resourceref "Image" "UiOutfitPendantAP26"
-- AP mask icons
resourceref "Image" "UiSeasonMaskAP02"
resourceref "Image" "UiSeasonMaskAP03"
resourceref "Image" "UiSeasonMaskAP04"
resourceref "Image" "UiSeasonMaskAP05"
resourceref "Image" "UiSeasonMaskAP06"
resourceref "Image" "UiSeasonMaskAP07"
resourceref "Image" "UiSeasonMaskAP09"
resourceref "Image" "UiSeasonMaskAP10"
resourceref "Image" "UiSeasonMaskAP11"
resourceref "Image" "UiSeasonMaskAP12"
resourceref "Image" "UiSeasonMaskAP13"
resourceref "Image" "UiSeasonMaskAP14"
-- Snowball prop
resourceref "Image" "GlitterSh"

resourceref "Image" "UIConstellationButtonGlow"
resourceref "Image" "UIStarGlow"
resourceref "Image" "UIBGGalaxy"
resourceref "Image" "UICircleTrailGlow"

resourceref "Image" "UiMiscInteractOutline"
resourceref "Image" "UiMenuCircleShadowHeavy"

-- Markup images
resourceref "Image" "UiAnalogStickLit"
resourceref "Image" "UiButtonLeft"
resourceref "Image" "UiButtonTop"
resourceref "Image" "UiButtonBottom"
resourceref "Image" "UiButtonRight"
resourceref "Image" "UiLeftButton"
resourceref "Image" "UiLeftTrigger"
resourceref "Image" "UiRightButton"
resourceref "Image" "UiSeasonQuest"

-- STILL USED IN GAME/SERVR DATA, TO BE DELETED EVENTUALLY --

resourceref "Image" "UISit" -- to be deleted (UISit still used in levels)
resourceref "Image" "UIGift" -- to be deleted (UIGift in Server Data)
resourceref "Image" "UIHand" -- to be deleted (UIHand still used in levels)
resourceref "Image" "UIHint" -- to be deleted (UIHint in Server Data)
resourceref "Image" "UIChair" -- to be deleted (UIChair in Server Data)

-- ANIMATED ICONS - MUST COME AFTER ICONS --

resource "ImageAnim" "UiEmoteSitAnim"				{ prefix = "UiEmoteSit", frames = "0, 0, 1, 2, 2, 2, 2, 2, 2", frameTime = 0.16 }
resource "ImageAnim" "UiEmoteFlameAnim"				{ prefix = "UiEmoteFlame", frames = "0, 1, 2, 3, 4, 5, 3, 4, 5, 3, 4, 5, 3, 4, 5", frameTime = 0.13 }
resource "ImageAnim" "UiEmoteFlameSmallAnim"		{ prefix = "UiEmoteFlame", frames = "1", frameTime = 0.25 }
resource "ImageAnim" "UiEmoteWaveAnim"				{ prefix = "UiEmoteWave", frames = "0, 1", frameTime = 0.35 }
resource "ImageAnim" "UiMenuPlaceCandleAnim"		{ prefix = "UiMenuPlaceCandle", frames = "2, 2, 2, 2, 0, 0, 1", frameTime = 0.16 }
resource "ImageAnim" "UiSocialReceiveHeartAnim"		{ prefix = "UiSocialReceiveHeart", frames = "0, 0, 1, 2, 2, 2, 2, 2, 2", frameTime = 0.16 }
resource "ImageAnim" "UiSocialOfferCandleAnim"		{ prefix = "UiSocialOfferCandle", frames = "0, 0, 1, 2, 2, 2, 2, 2, 2", frameTime = 0.16 }
resource "ImageAnim" "UIAcceptGiftAnim"				{ prefix = "UiSocialReceiveHeart", frames = "0, 0, 1, 2, 2, 2, 2, 2, 2", frameTime = 0.16 } -- in server data
resource "ImageAnim" "UIOfferGiftAnim"				{ prefix = "UiSocialOfferCandle", frames = "0, 0, 1, 2, 2, 2, 2, 2, 2", frameTime = 0.16 } -- in server data
resource "ImageAnim" "UiEmoteAP06NodAnim"			{ prefix = "UiEmoteAP06Nod", frames = "0, 2, 0, 1, 1", frameTime = 0.16 }
resource "ImageAnim" "UiEmoteAP09ShowDanceAnim"		{ prefix = "UiEmoteAP09ShowDance", frames = "0, 1, 2, 1", frameTime = 0.35 }
resource "ImageAnim" "UiEmoteAP11BeckonAnim"		{ prefix = "UiEmoteAP11Beckon", frames = "1, 0, 1, 0, 0", frameTime = 0.35 }
resource "ImageAnim" "UiEmoteAP13WaitAnim"			{ prefix = "UiEmoteAP13Wait", frames = "1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0", frameTime = 0.16 }
resource "ImageAnim" "UiEmoteAP13EvilLaughAnim"		{ prefix = "UiEmoteAP13EvilLaugh", frames = "1, 0, 1, 0, 1, 0, 0, 0", frameTime = 0.25 }
resource "ImageAnim" "UiEmoteAP14HeadBobAnim"		{ prefix = "UiEmoteAP14HeadBob", frames = "0, 1, 1, 2, 3, 3, 2, 1, 1", frameTime = 0.16 }
resource "ImageAnim" "UiMenuStageCurtainOpenAnim"	{ prefix = "UiMenuStageCurtain", frames = "0, 0, 1, 2, 2, 2, 2, 2, 2", frameTime = 0.16 }
resource "ImageAnim" "UiMenuStageCurtainCloseAnim"	{ prefix = "UiMenuStageCurtain", frames = "2, 2, 1, 0, 0, 0, 0, 0, 0", frameTime = 0.16 }
resource "ImageAnim" "UiOfferHealAnim"				{ prefix = "UiSocialOfferHeal", frames = "0, 1, 2, 3, 4, 5, 3, 4, 5, 3, 4, 5, 3, 4, 5", frameTime = 0.13 }
resource "ImageAnim" "UiHudStarSplitAnim"			{ prefix = "UiHudStarSplit", frames = "0, 1, 1, 2, 3, 4, 5, 6, 7", frameTime = 0.13 }
resource "ImageAnim" "UiHudShieldSplitAnim"			{ prefix = "UiHudShieldSplit", frames = "0, 1, 1, 2, 3, 4, 5, 6, 7", frameTime = 0.13 }
resource "ImageAnim" "UiEmoteAP16ArmWaveAnim"			{ prefix = "UiEmoteAP16ArmWave", frames = "0, 1, 2, 3, 4, 5", frameTime = 0.35 }
resource "ImageAnim" "UiEmoteAP16ConductAnim"			{ prefix = "UiEmoteAP16Conduct", frames = "0, 0, 0, 1, 2, 3, 3, 3, 2, 1", frameTime = 0.16 }
resource "ImageAnim" "UiEmoteAP16RhythmicClapAnim"			{ prefix = "UiEmoteAP16RhythmicClap", frames = "0, 1, 2, 2, 3, 4, 5, 5", frameTime = 0.16 }
resource "ImageAnim" "UiEmoteAP16RaiseTheRoofAnim"			{ prefix = "UiEmoteAP16RaiseTheRoof", frames = "0, 1", frameTime = 0.25 }
resource "ImageAnim" "UiEmoteAP16SilentClapAnim"			{ prefix = "UiEmoteAP16SilentClap", frames = "0, 1, 0, 1, 0, 2, 3, 4, 3, 4, 3, 5", frameTime = 0.16 }
resource "ImageAnim" "UiEmoteAuroraPenguinDanceAnim"			{ prefix = "UiEmoteAuroraPenguinDance", frames = "0, 1, 2, 3, 4, 5, 6, 7", frameTime = 0.25 }
resource "ImageAnim" "UiMenuSnakeGameAnim"            { prefix = "UiMenuSnakeGame", frames = "2,1,0,2,2,2,2,1,0,1,2,2,1,0,1,2", frameTime = 0.20 }
resource "ImageAnim" "UiEmoteAP26CoughAnim"            { prefix = "UiEmoteAP26Cough", frames = "0, 1, 0, 2, 2, 2", frameTime = 0.25 }

-- NETEASE MERGE

resource "Shader" "AP21NineColor"                 { group = "Opaque", vs = "AP21NineColor.vert", fs = "AP21NineColor.frag", toolExport = true, defines="" }
resource "Shader" "AP21DeerShout"                 { group = "BlendedWithBackfaces", vs = "AP21DeerShout.vert", fs = "AP21DeerShout.frag", toolExport = true, defines="" }
resource "Shader" "AvatarChamNineColor"        { group = "Opaque", vs = "Avatar.vert", fs = "Avatar.frag", toolExport = false, defines="CHAM CAPE_INTEGRITY NINECOLOR GLITTER BUTTERFLY" }



-- Tournament of Triumph

resource "Mesh" "CharSkyKid_Prop_CrabOfCompetition_Stone"                { source = "CharSkyKid_Prop_CrabOfCompetition_Stone.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "CharSkyKid_Prop_CrabOfCompetition_Gold"                { source = "CharSkyKid_Prop_CrabOfCompetition_Gold.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }

resource "Mesh" "MoonlightLantern"      		{ source = "MoonlightLantern.fbx", 		loadAsync = false, 		registerCollision = false, 		loadLazy = true }
resource "Mesh" "Placeable_MoonlightLantern"      		{ source = "Placeable_MoonlightLantern.fbx", 		loadAsync = false, 		registerCollision = false, 		loadLazy = true }

resource "Mesh" "Prop_FortunePlant"              { source = "Prop_FortunePlant.fbx",         loadAsync = false,         registerCollision = false,         computeOcclusions = true }
resource "Mesh" "Hair_FortuneSnake"                    { source = "Hair_FortuneSnake.fbx",             sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Body_FortuneSnake"                    { source = "Body_FortuneSnake.fbx",             sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Wing_FortuneSnake"             { source = "Wing_FortuneSnake.fbx",         sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }
resource "Mesh" "Prop_FortuneFan"                        { source = "Prop_FortuneFan.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }
resource "Mesh" "Prop_FortuneCoupletPoster"                    { source = "Prop_FortuneCoupletPoster.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_FortuneCandleFlags"                    { source = "Prop_FortuneCandleFlags.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Prop_FortuneBag"                    { source = "Prop_FortuneBag.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true, copyFrameDelay = true }
resource "Mesh" "Mask_FortuneSnake"                { source = "Mask_FortuneSnake.fbx", sharedSkeleton = "CharSkyKid_Skeleton.fbx", stripAnimation = true, computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true }

resource "Mesh" "Prop_SnakeGameHead"                        { source = "Prop_SnakeGameHead.fbx", computeOcclusions = true, computeEdges = false, compressPositions = true, compressUvs = true, stripNormals = true, loadLazy = true, stripUv13 = true }

-- Two Embers --
resource "Mesh" "CandleFruitAnim"            { source = "CandleFruitAnim.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "Before_FruitOrangePopulate_VistaDemo1Anim"            { source = "Before_FruitOrangePopulate_VistaDemo1Anim.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "FishE"            { source = "FishE.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
resource "Mesh" "PropHammer_01"            { source = "PropHammer_01.fbx", loadAsync = false, registerCollision = false, computeOcclusions = true }
